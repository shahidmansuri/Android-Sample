package com.baseproject.network.listeners;

public interface OnLoadMoreListener {
	 void onLoadMore();
}
