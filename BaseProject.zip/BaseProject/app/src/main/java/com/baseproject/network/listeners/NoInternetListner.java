package com.baseproject.network.listeners;


public interface NoInternetListner {
    void onNoInternet();
}
