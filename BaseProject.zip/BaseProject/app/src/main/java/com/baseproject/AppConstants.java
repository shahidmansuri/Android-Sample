package com.baseproject;

/**
 * Created by Mushahid on 1/8/2018.
 * This class includes the Key and Base Urls to be used in the App for Network call
 */

public class AppConstants {

    public static String BASE_URL = "";
}
