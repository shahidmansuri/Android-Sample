package com.baseproject.utils.pref;

/**
 * Created by Mushahid on 1/8/2018.
 */

public class PreferenceKeys {
    public static String LOGGEDIN ="isLoggedIn";
}
