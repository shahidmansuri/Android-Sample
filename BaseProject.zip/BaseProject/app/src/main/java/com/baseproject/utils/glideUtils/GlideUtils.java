package com.baseproject.utils.glideUtils;


/**
 * Created by Mushahid on 1/8/2018
 */

public class GlideUtils {


    private static GlideRequests glideRequests;
/*
    public static GlideRequests getRequest(Context context) {
        if(glideRequests==null){
            glideRequests = GlideApp.with(context);
        }
        return glideRequests;
    }*/

}
