package com.baseproject.utils.glideUtils;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule(glideName = "ImgurGlide")
public final class MyGlideModule extends AppGlideModule {
  // Intentionally empty.


}