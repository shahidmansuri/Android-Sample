package com.alnahla;

public class AppStrings {
    /*
        Order Status Constants
     */
    public static final String REQUESTED = "Requested";
    public static final String ACCEPTED= "Accepted";
    public static final String REJECTED = "Rejected";
    public static final String ASSIGNED = "Assigned";
    public static final String ON_THE_WAY = "On the way";
    public static final String ARRIVED_tO_RESTAURANT = "Arrived at restaurant";
    public static final String PICKED_UP_FROM_REST = "Picked Up";
    public static final String PICKED_UP = "Picked Up";
    public static final String DELIVER_TO_CUSTOMER = "Deliver to customer";
    public static final String DELIVERED = "Delivered";

    public static final String COMPLETED = "Completed";
    public static final String CANCEL_BY_RESTAURENT = "Cancelled By Restaurant";
    public static final String CANCEL_BY_ADMIN = "Cancelled By Admin";
    public static final String PAYMENT_SUCCESSFUL = "Payment successful";
    public static final String TYPE_CASH = "Cash";
    public static final String TYPE_CARD = "Card";
    public static final String REASON_OTHERS = "Others";
    public static final String MSG_DOUBLE_PRESS_EXIT = "Press again to exit";
    public static final String CLEAR_ALL = "Clear All";

    public static String NOTIFICATION_TITLE = "title";
    public static String NOTIFICATION_TEXT = "text";
    public static String NOTIFICATION_TYPE = "type";
    public static String NOTIFICATION_IMAGE = "image";

    public static String BROADCAST_KEY_ORDER_CANCEL = "orderCancel";
    public static String BROADCAST_KEY_ALARM = "alaramManager";
    public static String BROADCAST_KEY_ALARM_GEOFENCING = "geoFencingUpdated";

    /*
        EditProfileActivity, constants for camera image naming
     */
    public static String PIC_TIMESTAMP_FORMAT = "yyyyMMdd_HHmmss";
    public static String PIC_EXTENSION = ".jpg";
}
