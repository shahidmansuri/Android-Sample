package com.alnahla.model;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.List;
/**
 * Awesome Pojo Generator
 * */
public class EarningData {
  @SerializedName("currency_symbol")
  @Expose
  private String currency_symbol;
  @SerializedName("earning_details")
  @Expose
  private List<Earning_details> earning_details;
  @SerializedName("message")
  @Expose
  private String message;
  public void setCurrency_symbol(String currency_symbol){
   this.currency_symbol=currency_symbol;
  }
  public String getCurrency_symbol(){
   return currency_symbol;
  }
  public void setEarning_details(List<Earning_details> earning_details){
   this.earning_details=earning_details;
  }
  public List<Earning_details> getEarning_details(){
   return earning_details;
  }
  public void setMessage(String message){
   this.message=message;
  }
  public String getMessage(){
   return message;
  }
}