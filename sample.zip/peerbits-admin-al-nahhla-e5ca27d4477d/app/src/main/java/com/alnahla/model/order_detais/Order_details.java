package com.alnahla.model.order_detais;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;
/**
 * Awesome Pojo Generator
 * */
public class Order_details implements Serializable {
  @SerializedName("order_status")
  @Expose
  private List<Order_status> order_status;
  @SerializedName("payment_type")
  @Expose
  private Integer payment_type;
  @SerializedName("customer_details")
  @Expose
  private Customer_details customer_details;
  @SerializedName("status_code")
  @Expose
  private Integer status_code;
  @SerializedName("eta")
  @Expose
  private Integer eta;
  @SerializedName("total_price")
  @Expose
  private String total_price;
  @SerializedName("currency_symbol")
  @Expose
  private String currency_symbol;
  @SerializedName("restaurant_details")
  @Expose
  private Restaurant_details restaurant_details;
  @SerializedName("order_id")
  @Expose
  private Integer order_id;
  @SerializedName("timestamp")
  @Expose
  private String timestamp;
  @SerializedName("status")
  @Expose
  private String status;
  @SerializedName("order_items")
  @Expose
  private List<Order_items> order_items;
  public void setOrder_status(List<Order_status> order_status){
   this.order_status=order_status;
  }
  public List<Order_status> getOrder_status(){
   return order_status;
  }
  public void setPayment_type(Integer payment_type){
   this.payment_type=payment_type;
  }
  public Integer getPayment_type(){
   return payment_type;
  }
  public void setCustomer_details(Customer_details customer_details){
   this.customer_details=customer_details;
  }
  public Customer_details getCustomer_details(){
   return customer_details;
  }
  public void setStatus_code(Integer status_code){
   this.status_code=status_code;
  }
  public Integer getStatus_code(){
   return status_code;
  }
  public void setEta(Integer eta){
   this.eta=eta;
  }
  public Integer getEta(){
   return eta;
  }
  public void setTotal_price(String total_price){
   this.total_price=total_price;
  }
  public String getTotal_price(){
   return total_price;
  }
  public void setCurrency_symbol(String currency_symbol){
   this.currency_symbol=currency_symbol;
  }
  public String getCurrency_symbol(){
   return currency_symbol;
  }
  public void setRestaurant_details(Restaurant_details restaurant_details){
   this.restaurant_details=restaurant_details;
  }
  public Restaurant_details getRestaurant_details(){
   return restaurant_details;
  }
  public void setOrder_id(Integer order_id){
   this.order_id=order_id;
  }
  public Integer getOrder_id(){
   return order_id;
  }
  public void setTimestamp(String timestamp){
   this.timestamp=timestamp;
  }
  public String getTimestamp(){
   return timestamp;
  }
  public void setStatus(String status){
   this.status=status;
  }
  public String getStatus(){
   return status;
  }
  public void setOrder_items(List<Order_items> order_items){
   this.order_items=order_items;
  }
  public List<Order_items> getOrder_items(){
   return order_items;
  }
}