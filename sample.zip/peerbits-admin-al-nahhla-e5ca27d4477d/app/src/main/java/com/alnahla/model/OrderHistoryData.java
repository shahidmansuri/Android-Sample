package com.alnahla.model;
import com.alnahla.model.order_detais.Order_details;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.List;
/**
 * Awesome Pojo Generator
 * */
public class OrderHistoryData {
  @SerializedName("order_history")
  @Expose
  private List<Order_details> order_history;
  @SerializedName("is_last")
  @Expose
  private Integer is_last;
  @SerializedName("message")
  @Expose
  private String message;
  public void setOrder_history(List<Order_details> order_history){
   this.order_history=order_history;
  }
  public List<Order_details> getOrder_history(){
   return order_history;
  }
  public void setIs_last(Integer is_last){
   this.is_last=is_last;
  }
  public Integer getIs_last(){
   return is_last;
  }
  public void setMessage(String message){
   this.message=message;
  }
  public String getMessage(){
   return message;
  }
}