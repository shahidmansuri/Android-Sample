package com.alnahla.model.order_detais;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
/**
 * Awesome Pojo Generator
 * */
public class Data{
  @SerializedName("is_order_running")
  @Expose
  private Integer is_order_running;
  @SerializedName("message")
  @Expose
  private String message;
  @SerializedName("order_details")
  @Expose
  private Order_details order_details;
  public void setIs_order_running(Integer is_order_running){
   this.is_order_running=is_order_running;
  }
  public Integer getIs_order_running(){
   return is_order_running;
  }
  public void setMessage(String message){
   this.message=message;
  }
  public String getMessage(){
   return message;
  }
  public void setOrder_details(Order_details order_details){
   this.order_details=order_details;
  }
  public Order_details getOrder_details(){
   return order_details;
  }
}