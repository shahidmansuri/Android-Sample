package com.alnahla.network.listeners;

import org.json.JSONObject;

import java.util.ArrayList;


public interface RetrofitResponseListener {
    void onPreExecute();
    void onSuccess(int statusCode, JSONObject jsonObject, String response);
    void onError(int statusCode, ArrayList<String> messages);
}
