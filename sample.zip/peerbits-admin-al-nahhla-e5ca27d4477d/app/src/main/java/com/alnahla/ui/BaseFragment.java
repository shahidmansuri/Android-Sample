package com.alnahla.ui;


import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.support.customtabs.CustomTabsIntent;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.alnahla.AppConstants;
import com.alnahla.R;
import com.alnahla.service.PingService;
import com.alnahla.ui.activity.SignInActivity;
import com.alnahla.ui.dialog.MessageDialog;
import com.alnahla.utils.CustomProgressDialog;
import com.alnahla.utils.Logger;
import com.alnahla.utils.glideUtils.GlideLoader;
import com.alnahla.utils.pref.SessionManager;
import com.google.gson.Gson;

import java.util.ArrayList;


/**
 * Each Fragment must extends BaseFragment.
 * Also each fragment must used the mainView already declared in BaseFragment for Container View.
 */
public class BaseFragment extends Fragment {


    protected Context mContext;
    private CustomProgressDialog progressDialog;
    public BaseActivity mActivity;

    // Preference Handling
    protected SessionManager session;
    public GlideLoader glideLoader;
    public Gson gson;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;

        if (context instanceof Activity) {
            mActivity = (BaseActivity) context;

        }
        session = new SessionManager(mContext);
        glideLoader = new GlideLoader(mContext);
        gson = new Gson();
    }


    /**
     * Show Progress Dailog without any message
     */
    public void showProgress() {
        showProgress(null);
    }

    /**
     * Show Progress dialog with Message
     *
     * @param message Message to show under Progress
     */
    public void showProgress(String message) {
        if (progressDialog != null) {
            progressDialog.show(message);
        } else {
            progressDialog = new CustomProgressDialog(mContext, message);
            progressDialog.show();
        }
    }

    // For Load more ProfileModel
    public boolean isLastItemDisplaying(RecyclerView recyclerView) {
        if (recyclerView.getAdapter().getItemCount() != 0) {
            int lastVisibleItemPosition = ((LinearLayoutManager) recyclerView.getLayoutManager()).findLastCompletelyVisibleItemPosition();
            return lastVisibleItemPosition != RecyclerView.NO_POSITION && lastVisibleItemPosition == recyclerView.getAdapter().getItemCount() - 1;
        }
        return false;
    }


    /**
     * Stop Progress if running and dismiss progress Dialog
     */
    public void stopProgress() {
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }

    /**
     * To check weather the progress is running
     *
     * @return True if Progress is running false else.
     */
    protected boolean isProgressShowing() {
        return progressDialog != null && progressDialog.isShowing();
    }


    public void showToastShort(String message) {
        Toast.makeText(mContext, message, Toast.LENGTH_SHORT).show();
    }

    public void showToastLong(String message) {
        Toast.makeText(mContext, message, Toast.LENGTH_LONG).show();
    }

    public void showSnackBar(String message) {
        Snackbar snackbar = Snackbar.make(mActivity.findViewById(android.R.id.content), message, Snackbar.LENGTH_LONG);
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(mActivity.findViewById(android.R.id.content).getContext(), R.color.text_blue));
        snackbar.show();
    }

    public void showErrorSnackBar(String message) {
        Snackbar snackbar = Snackbar.make(mActivity.findViewById(android.R.id.content), message, Snackbar.LENGTH_LONG);
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(mActivity.findViewById(android.R.id.content).getContext(), R.color.colorBtnRed));
        snackbar.show();
    }

    public void errorHandleFromApi(final Context mContext, final ArrayList<String> messages, final int statusCode) {
        Logger.e("StatusCode", ";-" + statusCode);
//        if (messages.size() == 0) {
//            showErrorSnackBar(messages.get(0));
//            if(statusCode == AppConstants.UNAUTHORIZED){
//                session.clearSession();
//                unBindPingService();
//
//                SignInActivity.launch(getActivity(),true);
//            }
//        } else {
        if (messages.size() > 0) {
            new MessageDialog(mContext)
                    .setTitle(getString(R.string.errors))
                    .setMessage(messages.get(0))
                    .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();
                            if (statusCode == AppConstants.UNAUTHORIZED) {
                                session.clearSession();
                                unBindPingService();

                                SignInActivity.launch(getActivity(), true);
                            }
                        }
                    })
                    .cancelable(false)
                    .show();
        }
    }

    public void unBindPingService() {
        getActivity().stopService(new Intent(getActivity(), PingService.class));
    }

    public void showPermissionSettingDialog(String message) {
        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(mContext);
        builder.setTitle("Need Permission");
        builder.setMessage(message);
        builder.setPositiveButton(R.string.app_settings, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.addCategory(Intent.CATEGORY_DEFAULT);
                intent.setData(Uri.parse("package:" + mContext.getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                intent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                startActivity(intent);
                dialog.dismiss();
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();

    }

    // navigating user to app settings
    public void openSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", mContext.getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, 101);
    }

    public void openCustomTabs(Uri uri) {
        CustomTabsIntent.Builder intentBuilder = new CustomTabsIntent.Builder();
        intentBuilder.setToolbarColor(ContextCompat.getColor(getActivity(), R.color.colorPrimary));
        intentBuilder.setSecondaryToolbarColor(ContextCompat.getColor(getActivity(), R.color.colorPrimaryDark));
        intentBuilder.setStartAnimations(getActivity(), R.anim.slide_in_right, R.anim.slide_out_left);
        intentBuilder.setExitAnimations(getActivity(), android.R.anim.slide_in_left,
                android.R.anim.slide_out_right);
        CustomTabsIntent customTabsIntent = intentBuilder.build();
        customTabsIntent.launchUrl(getActivity(), uri);
    }

    public boolean onBackPressed() {
        return false;
    }

    public void hideStatusBar() {
        getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    public void showStatusBar() {
        getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    public void hideToolBar() {
        ((AppCompatActivity) getActivity()).getSupportActionBar().hide();
    }

    public void showToolBar() {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
    }
}

