package com.alnahla.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Awesome Pojo Generator
 */
public class MyOrderData {
    @SerializedName("is_last")
    @Expose
    private String is_last;
    @SerializedName("order_list")
    @Expose
    private List<OrderListData> order_list;

    public void setIs_last(String is_last) {
        this.is_last = is_last;
    }

    public String getIs_last() {
        return is_last;
    }

    public void setOrder_list(List<OrderListData> order_list) {
        this.order_list = order_list;
    }

    public List<OrderListData> getOrder_list() {
        return order_list;
    }
}