package com.alnahla.utils.pref;

import android.content.Context;
import android.util.Log;

import com.alnahla.R;
import com.alnahla.model.UserInfo;
import com.alnahla.model.newtoken.Auth;
import com.alnahla.model.notification.NotificationData;
import com.google.gson.Gson;

import java.util.HashMap;

import static com.alnahla.utils.pref.PreferenceKeys.KEY_IS_ONLINE;

public class SessionManager {
    private SecurePreferences pref;
    public static SessionManager sessionManager;


    public SessionManager(Context context) {
        String PREF_NAME = context.getResources().getString(R.string.app_name);
        pref = SecurePreferences.getInstance(context, PREF_NAME);
    }

    public void storeUserData(HashMap<String, String> userDetail) {
        for (String key : userDetail.keySet()) {
            pref.putString(key, userDetail.get(key));
        }
        pref.commit();
    }

   /* public Token getToken() {
        Gson gson = new Gson();
        String json = getValueFromKey(PreferenceKeys.KEY_TOKEN, "");
        return gson.fromJson(json, Token.class);
    }

    public void setToken(Token Value) {
        Gson gson = new Gson();
        pref.putString(PreferenceKeys.KEY_TOKEN, gson.toJson(Value));
        pref.commit();
    }*/


    public Auth getNewToken() {
        Gson gson = new Gson();
        String json = getValueFromKey(PreferenceKeys.KEY_TOKEN, "");
        return gson.fromJson(json, Auth.class);
    }

    public void setNewToken(Auth Value) {
        Gson gson = new Gson();
        pref.putString(PreferenceKeys.KEY_TOKEN, gson.toJson(Value));
        pref.commit();
    }

    public UserInfo getUser() {
        Gson gson = new Gson();
        String json = getValueFromKey(PreferenceKeys.KEY_USER, "");
        return gson.fromJson(json, UserInfo.class);
    }

    public void setUser(UserInfo Value) {
        Gson gson = new Gson();
        pref.putString(PreferenceKeys.KEY_USER, gson.toJson(Value));
        pref.commit();
    }


    public void clearSession() {
        pref.clear();
        pref.commit();
    }

    /**
     * Getting value for key from shared Preferences
     *
     * @param key          key for which we need to get Value
     * @param defaultValue default value to be returned if key is not exits
     * @return It will return value of key if exist and defaultValue otherwise
     */
    public String getValueFromKey(String key, String defaultValue) {
        if (pref.containsKey(key)) {
            return pref.getString(key, defaultValue);
        } else {
            return defaultValue;
        }
    }


    public boolean getValueFromKey(String key, boolean defaultValue) {
        if (pref.containsKey(key)) {
            return pref.getBoolean(key, defaultValue);
        } else {
            return defaultValue;
        }
    }

    /**
     * Setting value for key from shared Preferences
     *
     * @param key   key for which we need to get Value
     * @param value value for the key
     */
    public void setValueFromKey(String key, String value) {
        pref.putString(key, value);
    }

    public void setValueFromKey(String key, double value) {
        pref.putString(key, String.valueOf(value));
    }

    /**
     * Setting value for key from shared Preferences
     *
     * @param key   key for which we need to get Value
     * @param value value for the key
     */
    public void setFlageFromKey(String key, boolean value) {
        pref.putBoolean(key, value);
    }


    /**
     * To get Flag from sharedPreferences
     *
     * @param key key of flag to get
     * @return flag value for key if exist. false if not key not exist.
     */
    public boolean getFlagFromKey(String key) {
        return pref.containsKey(key) && pref.getBoolean(key, false);
    }
    public boolean getFlagFromKey(String key,boolean d) {
        return pref.containsKey(key) && pref.getBoolean(key, d);
    }
    public void tokenUpdatedToserver(boolean bool) {
        pref.putBoolean(PreferenceKeys.KEY_FIREBASE_TOKEN_UPDATED, bool);
        pref.commit();
    }

    public void setIsOnline(boolean isChecked) {
        pref.putBoolean(KEY_IS_ONLINE, isChecked);
        pref.commit();
    }

    public NotificationData getNotificationData() {
        Gson gson = new Gson();
        String json = getValueFromKey(PreferenceKeys.NOTIFICATIONDATA, "");
        return gson.fromJson(json, NotificationData.class);
    }


    public void setNotificationData(NotificationData data) {
        Gson gson = new Gson();
        pref.putString(PreferenceKeys.NOTIFICATIONDATA, gson.toJson(data));
        pref.commit();
    }

    public void clearNotificationData() {
        pref.putString(PreferenceKeys.NOTIFICATIONDATA, "");
        pref.commit();
    }


}
