package com.alnahla.service;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.util.Log;

import com.alnahla.BuildConfig;
import com.alnahla.utils.Constants;
import com.alnahla.utils.Logger;
import com.alnahla.utils.pref.PreferenceKeys;
import com.alnahla.utils.pref.SessionManager;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.Objects;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

import static com.alnahla.utils.pref.PreferenceKeys.KEY_IS_ONLINE;

/**
 * Created by AnkitKumar on 20-08-2018.
 */

public class PingService extends Service {
    private static final int ONE_MINUTE = 1000 * 5; //1 minute
    private final int DEFAULT_FREQUENCY = ONE_MINUTE;

    private SessionManager session;
    private Socket mSocket;


    private FusedLocationProviderClient fusedLocationProviderClient;
    private LocationCallback locationCallback;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);

        @SuppressLint("InvalidWakeLockTag") PowerManager.WakeLock wakelock = ((PowerManager) getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Chat Service");
        wakelock.acquire(10 * 60 * 1000L /*10 minutes*/);
        startForegroundNotification();
        session = new SessionManager(getApplicationContext());

        setUpLocationService();

        wakelock.release();
        return START_STICKY;
    }

    private void setUpLocationService() {
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return;
        }

        initSocket();
        getLastLocation();
        sendPingOnTimeBase(DEFAULT_FREQUENCY);
    }

    public void getLastLocation() {
        // Get last known recent location using new Google Play Services SDK (v11+)
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        fusedLocationProviderClient.getLastLocation()
                .addOnSuccessListener(new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        // GPS location can be null if GPS is switched off
                        if (location != null) {
                            onLocationChanged(location);
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        e.printStackTrace();
                    }
                });
    }

    @Override
    public void onCreate() {

    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public void onDestroy() {
        try {
            if (mSocket != null) {
                if (mSocket.connected()) {
                    mSocket.disconnect();
                }
            }

            if (fusedLocationProviderClient != null && locationCallback != null) {
                fusedLocationProviderClient.removeLocationUpdates(locationCallback);
            }
            Logger.e("onDestroy","onDestroy;-");
        } catch (Exception e) {
            Logger.e("Exception",";-"+e);
            e.printStackTrace();
        }
        super.onDestroy();
    }

    @SuppressWarnings("MissingPermission")
    private void sendPingOnTimeBase(int timeInMilli) {
        LocationRequest mLocationRequest = LocationRequest.create();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(timeInMilli / 8);
        mLocationRequest.setFastestInterval(timeInMilli);


        if (locationCallback == null) {
            locationCallback = new LocationCallback() {
                @Override
                public void onLocationResult(LocationResult locationResult) {
                    // do work here
                    onLocationChanged(locationResult.getLastLocation());
                }
            };
        }

        fusedLocationProviderClient.removeLocationUpdates(locationCallback);
        fusedLocationProviderClient.requestLocationUpdates(mLocationRequest, locationCallback, Looper.myLooper());
    }

    public void onLocationChanged(Location location) {
        if (mSocket != null && mSocket.connected()) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put(Constants.SOCKET_ID, session.getValueFromKey(PreferenceKeys.KEY_USER_ID,""));
                jsonObject.put(Constants.SOCKET_LAT, location.getLatitude());
                jsonObject.put(Constants.SOCKET_LONG, location.getLongitude());

            } catch (JSONException e) {
                e.printStackTrace();
            }
            mSocket.emit(Constants.SOCKET_UPDATE_LOC, jsonObject);

//            mSocket.emit(Constants.SOCKET_UPDATE_LOC, session.getValueFromKey(PreferenceKeys.KEY_USER_ID,""),
//                    location.getLatitude(), location.getLongitude());
        } else {
            if (mSocket != null && !mSocket.connected()) {
                mSocket.connect();
            }
        }
    }


    private void initSocket() {
        try {
            IO.Options options = new IO.Options();
            options.timeout = 3000;
            options.reconnection = true;
            options.forceNew = true;
            options.upgrade = false;
            options.transports = new String[]{Constants.SOCKET_WEB_SOCKET};
            options.reconnectionAttempts = 8;

//            mSocket = IO.socket(BuildConfig.SOCKET_URL, options);

            mSocket = IO.socket(BuildConfig.SOCKET_URL, options);

            mSocket.on(Socket.EVENT_CONNECT, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put(Constants.SOCKET_ID, session.getValueFromKey(PreferenceKeys.KEY_USER_ID,""));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    mSocket.emit(Constants.SOCKET_JOIN, jsonObject);
                }
            }).on(Socket.EVENT_DISCONNECT, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    try {
                        if (session.getUser() != null && session.getFlagFromKey(KEY_IS_ONLINE)) {
                            wakeScreenIfOff();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).on(Socket.EVENT_ERROR, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                }
            });
            mSocket.connect();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    private void wakeScreenIfOff() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        assert pm != null;
        boolean isScreenOn = pm.isScreenOn();
        if (!isScreenOn) {
            @SuppressLint("InvalidWakeLockTag") PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE, "MyLock");
            wl.acquire(10000);
            @SuppressLint("InvalidWakeLockTag") PowerManager.WakeLock wl_cpu = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MyCpuLock");
            wl_cpu.acquire(10000);
            if (!mSocket.connected()) {
                mSocket.connect();
            }
        }
    }

    private void startForegroundNotification() {
        Notification.Builder notificationBuilder = new Notification.Builder(getBaseContext())
                .setAutoCancel(false)
                .setContentTitle("Driver is running")
                .setContentText("");
        if (Build.VERSION.SDK_INT >= 26) {
            String CHANNEL_ID = "my_channel_01";
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Channel human readable title",
                    NotificationManager.IMPORTANCE_DEFAULT);

            ((NotificationManager) Objects.requireNonNull(getSystemService(Context.NOTIFICATION_SERVICE))).createNotificationChannel(channel);
            notificationBuilder.setChannelId(channel.getId());
        }
        startForeground(1337, notificationBuilder.build());
    }


    /* Internet Handeling*/
    private boolean isConnectedToInternet() {
        ConnectivityManager connectivity = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        assert connectivity != null;
        NetworkInfo activeNetwork = connectivity.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isAvailable() && activeNetwork.isConnected();
    }
}
