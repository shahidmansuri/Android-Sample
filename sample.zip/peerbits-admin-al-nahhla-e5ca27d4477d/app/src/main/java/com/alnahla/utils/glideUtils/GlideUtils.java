package com.alnahla.utils.glideUtils;


import android.content.Context;
import android.net.Uri;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

/**
 * Created by Mushahid on 1/8/2018
 */

public class GlideUtils {


    private static GlideRequests glideRequests;
/*
    public static GlideRequests getRequest(Context context) {
        if(glideRequests==null){
            glideRequests = GlideApp.with(context);
        }
        return glideRequests;
    }*/

    public static void setNormalImage(Context context, Uri uri, ImageView imageView) {
        Glide.with(context)
                .load(uri)
                .apply(RequestOptions.circleCropTransform())
                .into(imageView);
    }

    public static void setImage(Context context, Uri uri, ImageView imageView) {
        Glide.with(context)
                .load(uri)
                .apply(RequestOptions.fitCenterTransform())
                .into(imageView);
    }

    public static void setImageUrl(Context context, String uri, ImageView imageView) {
        Glide.with(context)
                .load(uri)
                .apply(RequestOptions.circleCropTransform())
                .into(imageView);
    }

}
