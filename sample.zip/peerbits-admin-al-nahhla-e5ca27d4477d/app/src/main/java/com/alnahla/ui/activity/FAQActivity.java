package com.alnahla.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.alnahla.R;
import com.alnahla.databinding.ActivityFaqBinding;
import com.alnahla.model.FAQData;
import com.alnahla.model.Faq;
import com.alnahla.network.API_CONSTANTS;
import com.alnahla.network.API_EndPoints;
import com.alnahla.network.NetworkCall;
import com.alnahla.network.listeners.RetrofitResponseListener;
import com.alnahla.ui.BaseActivity;
import com.alnahla.ui.adapter.FAQListAdapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class FAQActivity extends BaseActivity {

    private static final String TAG = FAQActivity.class.getSimpleName();
    private ActivityFaqBinding mBinder;

    //for the load more
    private int start = 0;
    private int limit = 10;
    private boolean isLoading;
    private int isLast = 1;

    FAQListAdapter faqListAdapter;
    private ArrayList<Faq> faqListArrayList = new ArrayList<Faq>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faq);

        mBinder = DataBindingUtil.setContentView(this, R.layout.activity_faq);
        setStatusBarColor(this,getResources().getColor(R.color.status_color_green));
        setUpUi();
    }

    public static void launch(Activity activity, boolean isFinishActivity) {
        if (isFinishActivity) {
            Intent intent = new Intent(activity, NotificationsActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        } else {
            Intent intent = new Intent(activity, NotificationsActivity.class);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        }
    }

    private void setUpUi() {

        setupToolBar(getResources().getString(R.string.faqs));
        apiNotificationList();
    }

    /*method to set up toolbar*/
    private void setupToolBar(String text) {
        this.setSupportActionBar(mBinder.toolbarLayout.toolbar);
        ActionBar ab = this.getSupportActionBar();
        if (ab != null) {
            ab.setDisplayShowTitleEnabled(false);
            ab.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            ab.setDisplayHomeAsUpEnabled(true);
        }
        mBinder.toolbarLayout.toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        mBinder.toolbarLayout.title.setText(text);
    }

    private void apiNotificationList() {
        HashMap<String, String> params = new HashMap<>();
        params.put(API_CONSTANTS.START, String.valueOf(start));
        params.put(API_CONSTANTS.LIMIT, String.valueOf(limit));

        NetworkCall.with(this)
                .setEndPoint(API_EndPoints.FAQ_LIST)
                .setRequestParams(params)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                        if (start == 0) {
                            showProgress(getResources().getString(R.string.txt_loading));
                        } else {
                            mBinder.pbNewProgress.setVisibility(View.VISIBLE);
                        }
                        isLoading = true;
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        stopProgress();
                        mBinder.pbNewProgress.setVisibility(View.GONE);
                        isLoading = false;
                        mBinder.tvNodata.setVisibility(View.GONE);
                        GsonBuilder gsonBuilder = new GsonBuilder();
                        Gson gson = gsonBuilder.create();
                        FAQData model = gson.fromJson(String.valueOf(jsonObject), FAQData.class);
                        if (model.getFaq().size() > 0) {
                            isLast = model.getIs_last();
                            start = start + limit;
                            faqListArrayList.addAll(model.getFaq());
                            setUpRecyclerView(faqListArrayList);
                        } else {
                            setUpRecyclerView(faqListArrayList);
                            mBinder.tvNodata.setVisibility(View.VISIBLE);
                        }
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        stopProgress();
                        isLoading = false;
                        mBinder.pbNewProgress.setVisibility(View.GONE);
                        mBinder.tvNodata.setVisibility(View.VISIBLE);
                        errorHandleFromApi(messages,statusCode);
                    }
                }).makeCall();
    }

    /**
     * method to set up recycler view
     */
    private void setUpRecyclerView(ArrayList<Faq> List) {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        if (faqListAdapter == null) {
            faqListAdapter = new FAQListAdapter(this, List);
            mBinder.rvFaqList.setLayoutManager(linearLayoutManager);
            mBinder.rvFaqList.setAdapter(faqListAdapter);

        } else {
            faqListAdapter.setDataList(faqListArrayList);
        }

        mBinder.rvFaqList.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int totalItemCount = recyclerView.getLayoutManager().getItemCount();
                int lastVisibleItem = ((LinearLayoutManager) recyclerView.getLayoutManager()).findLastVisibleItemPosition();
                if (!isLoading && totalItemCount <= (lastVisibleItem + 2)) {
                    if (isLast == 1) {
                        apiNotificationList();
                    }
                }
            }
        });
    }
}
