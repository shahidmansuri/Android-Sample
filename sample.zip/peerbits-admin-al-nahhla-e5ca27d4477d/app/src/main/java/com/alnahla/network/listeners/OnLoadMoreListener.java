package com.alnahla.network.listeners;

public interface OnLoadMoreListener {
	 void onLoadMore();
}
