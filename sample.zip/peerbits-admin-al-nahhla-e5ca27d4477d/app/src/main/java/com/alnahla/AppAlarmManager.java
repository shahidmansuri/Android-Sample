package com.alnahla;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import com.alnahla.receivers.AlarmTimeNotification;
import com.alnahla.ui.BaseActivity;
import com.alnahla.ui.activity.OrderActivity;
import com.alnahla.utils.Utils;

public class AppAlarmManager {

    public void setAlarm(BaseActivity context,String orderID,String logTime,String timeMiles){
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

//        Intent intentBroadCast = new Intent(context, AlarmTimeNotification.class);
        Intent intentBroadCast = new Intent(AppStrings.BROADCAST_KEY_ALARM);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context,Integer.parseInt(orderID),intentBroadCast,0);

        long timeStamp,timeMilesMili=0;
        if(logTime.equalsIgnoreCase(AppConstants.NO_VALUE_SET_STRING)){
            timeStamp = System.currentTimeMillis();
        }else{
            timeStamp = Long.parseLong(logTime);
        }
        if(!timeMiles.equalsIgnoreCase("")){
            timeMilesMili = Long.parseLong(Utils.getMiliFromMin(timeMiles));
        }
        alarmManager.set(AlarmManager.RTC_WAKEUP,timeStamp+timeMilesMili,pendingIntent);
    }

}
