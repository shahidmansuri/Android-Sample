package com.alnahla.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Awesome Pojo Generator
 */
public class HelpMeDialogList {
    @SerializedName("data")
    @Expose
    private HelpMeDialogData data;
    @SerializedName("success")
    @Expose
    private Integer success;
    @SerializedName("error")
    @Expose
    private List<Error> error;

    public void setData(HelpMeDialogData data) {
        this.data = data;
    }

    public HelpMeDialogData getData() {
        return data;
    }

    public void setSuccess(Integer success) {
        this.success = success;
    }

    public Integer getSuccess() {
        return success;
    }

    public void setError(List<Error> error) {
        this.error = error;
    }

    public List<Error> getError() {
        return error;
    }
}