package com.alnahla.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.view.View;

import com.alnahla.R;
import com.alnahla.databinding.ActivityWelcomeBinding;
import com.alnahla.ui.BaseActivity;

public class WelcomeActivity extends BaseActivity implements View.OnClickListener {
    ActivityWelcomeBinding welcomeBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        welcomeBinding = DataBindingUtil.setContentView(this, R.layout.activity_welcome);
        setStatusBarColor(this, getResources().getColor(R.color.status_color_gray));
        setUpUi();
    }

    private void setUpUi() {
        welcomeBinding.tvMobileNumber.setOnClickListener(this);

//        glideLoader.loadImageDrawable(getDrawable(R.drawable.bg_welcome), welcomeBinding.ivBG);
    }

    public static void launch(Activity activity, boolean isFinishActivity) {

        if (isFinishActivity) {
            Intent intent = new Intent(activity, WelcomeActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        } else {
            Intent intent = new Intent(activity, WelcomeActivity.class);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvMobileNumber:
                SignInActivity.launch(WelcomeActivity.this, false);
        }
    }
}
