package com.alnahla.model.order_detais;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Awesome Pojo Generator
 * */
public class Order_status implements Serializable {
  @SerializedName("status_code")
  @Expose
  private Integer status_code;
  @SerializedName("is_late")
  @Expose
  private Integer is_late;
  @SerializedName("late_time")
  @Expose
  private String late_time;
  @SerializedName("status")
  @Expose
  private String status;
  @SerializedName("timestamp")
  @Expose
  private String timestamp;
  public void setStatus_code(Integer status_code){
   this.status_code=status_code;
  }
  public Integer getStatus_code(){
   return status_code;
  }
  public void setIs_late(Integer is_late){
   this.is_late=is_late;
  }
  public Integer getIs_late(){
   return is_late;
  }
  public void setLate_time(String late_time){
   this.late_time=late_time;
  }
  public String getLate_time(){
   return late_time;
  }
  public void setStatus(String status){
   this.status=status;
  }
  public String getStatus(){
   return status;
  }
  public void setTimestamp(String timestamp){
   this.timestamp=timestamp;
  }
  public String getTimestamp(){
   return timestamp;
  }
}