package com.alnahla.ui.adapter;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.alnahla.R;
import com.alnahla.databinding.RawFaqListBinding;
import com.alnahla.model.Faq;

import java.util.ArrayList;
import java.util.List;

public class FAQListAdapter extends RecyclerView.Adapter<FAQListAdapter.MyViewHolder> {
    private List<Faq> faqList = new ArrayList<>();
    private Context mContext;

    public FAQListAdapter(Context mContext, List<Faq> faqList) {
        this.faqList = faqList;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public FAQListAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        RawFaqListBinding binding = DataBindingUtil.inflate(layoutInflater, R.layout.raw_faq_list, parent, false);
        return new FAQListAdapter.MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull final FAQListAdapter.MyViewHolder holder, final int position) {
   /*     if (notificationList.get(position).getType().equalsIgnoreCase("cancel_status_rider")){

            holder.binding.tvNotification.setVisibility(View.GONE);
            holder.binding.tvNotificationBold.setVisibility(View.VISIBLE);
        }else if (notificationList.get(position).getType().equalsIgnoreCase("cancel_status_user")){

            holder.binding.tvNotification.setVisibility(View.GONE);
            holder.binding.tvNotificationBold.setVisibility(View.VISIBLE);
        }else{
            holder.binding.tvNotification.setVisibility(View.VISIBLE);
            holder.binding.tvNotificationBold.setVisibility(View.GONE);
        }*/


        Faq faq = faqList.get(position);

        holder.binding.tvQuestion.setText(faq.getQuestion());
        holder.binding.tvAnswer.setText(faq.getAnswer());
    }

    public void setDataList(ArrayList<Faq> dataList) {
        this.faqList = dataList;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return faqList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        final RawFaqListBinding binding;

        MyViewHolder(RawFaqListBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
