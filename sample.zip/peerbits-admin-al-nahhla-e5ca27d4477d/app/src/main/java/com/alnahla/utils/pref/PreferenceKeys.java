package com.alnahla.utils.pref;

/**
 * Created by Mushahid on 1/8/2018.
 */

public class PreferenceKeys {
    public static final String KEY_TOKEN = "Token";
    public static final String KEY_LOGIN = "is_login";
    public static final String KEY_USER = "login_user";
    public static final String KEY_USER_ID = "id";
    public static final String KEY_FIREBASE_TOKEN_UPDATED = "token_sent_server";
    public static final String KEY_FIREBASE_TOKEN = "token_sent_server";

    public static final String KEY_IS_ONLINE = "is_online";
    public static final String NOTIFICATIONDATA= "notification_data";
    public static final String ONGOINGORDER= "ongoing_order";

    public static final String KEY_MOBILE= "contactNumber";

    public static final String KEY_CMS_ABOUTUS= "aboutUS";
    public static final String KEY_CMS_TANDC= "termaAndCondition";
    public static final String KEY_CMS_PRIVACY= "privacyPolicy";

    public static final String KEY_PROF_IMAGE = "profImage";
    public static final String KEY_FULL_NAME = "full_name";
    public static final String KEY_IMAGE= "image";


    public static final String KEY_ADMIN_CONTACT = "adminContact";

    public static final String KEY_DRIVER_START_LATITUDE = "startLatitude";
    public static final String KEY_DRIVER_START_LONGITUDE = "endLongitude";

    public static final String KEY_DRIVER_REST_EDT = "driverRestEDT";
    public static final String KEY_REST_CLIENT_EDT = "restClientEDT";

    public static final String KEY_ORDER_CANCEL_REQUEST_SENT = "reqSent";
    public static final String KEY_ORDER_COMPLETED = "isOrderCompleted";

    public static final String KEY_SENDFEEDBACK = "isFeedbackSent";
}
