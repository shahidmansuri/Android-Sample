package com.alnahla.ui.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import com.alnahla.R;
import com.alnahla.model.Reason;
import com.alnahla.network.API_CONSTANTS;
import com.alnahla.network.listeners.OnLoadMoreListener;
import com.alnahla.ui.activity.OrderCancelActivity;

import java.util.ArrayList;
import java.util.List;

public class OrderCancelReasonAdapter extends RecyclerView.Adapter {

    private List<Reason> reasonList;

    private LinearLayoutManager linearLayoutManager;
    private final int VIEW_ITEM = 1;

    //** LoadMore Variables
    private OnLoadMoreListener onLoadMoreListener;

    private RadioButton mSelectedRB;
    private int mSelectedPosition = -1;
    private OrderCancelActivity orderCancelActivity;

    public OrderCancelReasonAdapter(OrderCancelActivity mContext, ArrayList<Reason> orderCancelReasonArrayList, RecyclerView recyclerView) {
        this.orderCancelActivity = mContext;

        reasonList = orderCancelReasonArrayList;
        if (recyclerView.getLayoutManager() instanceof LinearLayoutManager) {

            linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder vh = null;
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.raw_order_cancel_reason, parent, false);
        vh = new myViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {

        Reason reason = reasonList.get(position);

        if (reason != null) {
            if (holder instanceof myViewHolder) {

                ((myViewHolder) holder).tvReason.setText(reason.getReason());
                ((myViewHolder) holder).rbReason.setTag(reason.getReason_id());
                ((myViewHolder) holder).rbReason.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        if (position != mSelectedPosition && mSelectedRB != null) {
                            mSelectedRB.setChecked(false);
                        }

                        mSelectedPosition = position;
                        mSelectedRB = (RadioButton) v;
                        mSelectedRB.setChecked(true);
                        orderCancelActivity.selectedReason((Integer) mSelectedRB.getTag());
                    }
                });
//
//                if (mSelectedPosition != position) {
//                    ((myViewHolder) holder).rbReason.setChecked(false);
//                } else {
//                    ((myViewHolder) holder).rbReason.setChecked(true);
//                    if (mSelectedRB != null && ((myViewHolder) holder).rbReason != mSelectedRB) {
//                        mSelectedRB = ((myViewHolder) holder).rbReason;
//                    }
//                }
                /*
                    Setting Default Reason as Others
                 */
                if(reason.getReason_id() == API_CONSTANTS.REASON_ID_OTHERS){
                    ((myViewHolder) holder).rbReason.callOnClick();
                }
            }
        } else {
            ((ProgressBar) holder).progressBar.setIndeterminate(true);
        }
    }

    @Override
    public int getItemViewType(int position) {
        int VIEW_PROGRESS = 0;
        return reasonList.get(position) != null ? VIEW_ITEM : VIEW_PROGRESS;
    }


    @Override
    public int getItemCount() {
        return reasonList.size();
    }

    private class myViewHolder extends RecyclerView.ViewHolder {

        RadioButton rbReason;
        TextView tvReason;
        LinearLayout llReason;
        public myViewHolder(View v) {
            super(v);

            rbReason = v.findViewById(R.id.rbReason);
            tvReason = v.findViewById(R.id.tvReason);
            llReason = v.findViewById(R.id.llReason);
        }
    }

    public class ProgressBar extends RecyclerView.ViewHolder {

        android.widget.ProgressBar progressBar;

        public ProgressBar(View itemView) {
            super(itemView);

        }
    }

    public void addAll(List<Reason> reasonList) {
        this.reasonList.addAll(reasonList);
        notifyDataSetChanged();
    }

    public void addItem(Reason reason) {
        this.reasonList.add(reason);
        notifyDataSetChanged();
    }
}
