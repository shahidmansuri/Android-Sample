package com.alnahla.fcm;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Vibrator;
import android.support.v4.app.NotificationCompat;


import com.alnahla.eventbus.MessageEvent;
import com.alnahla.network.API_CONSTANTS;
import com.alnahla.ui.activity.MainActivity;
import com.alnahla.ui.activity.OrderActivity;
import com.alnahla.utils.Utils;
import com.alnahla.utils.pref.IntentConstants;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.google.gson.Gson;
import com.alnahla.AppConstants;
import com.alnahla.R;
import com.alnahla.service.RingtonePlayingService;
import com.alnahla.utils.Constants;
import com.alnahla.utils.pref.PreferenceKeys;
import com.alnahla.utils.pref.SessionManager;

import org.greenrobot.eventbus.EventBus;


public class MyFireBaseMessagingService extends FirebaseMessagingService {
    private SessionManager sessionManager;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {

        sessionManager = new SessionManager(getApplicationContext());
        Gson gson = new Gson();

        if (sessionManager.getFlagFromKey(PreferenceKeys.KEY_LOGIN)) {

            String dataNotification = remoteMessage.getData().get(API_CONSTANTS.DATA);

            com.alnahla.model.login.Data  data = gson.fromJson(dataNotification, com.alnahla.model.login.Data.class);
            data.setIs_new_request(AppConstants.REQUESTED);
            String type = data.getNotification_type();
            String message = data.getMessage();
            int orderID = AppConstants.NO_VALUE_SET;
            if(data.getOrder_details()!=null && data.getOrder_details().getOrder_id()!=null){
                orderID = data.getOrder_details().getOrder_id();
            }

            // Get instance of Vibrator from current Context
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            v.vibrate(1000);

            Intent intent = null;
            /*
                Write Code for cancle Order
             */
            if(type.equalsIgnoreCase(API_CONSTANTS.NOTI_TYPE_CANCEL_ORDER_ADMIN) || type.equalsIgnoreCase(API_CONSTANTS.NOTI_TYPE_CANCEL_ORDER_REST)){
                sendCancelOrderBroadCast(type,message,orderID,data);
            }
            /*
                Write Code for new Order
             */
            else if(type.equalsIgnoreCase(API_CONSTANTS.NOTIFICATION_TYPE_NEW_ORDER) || type.equalsIgnoreCase(API_CONSTANTS.NOTIFICATION_TYPE_ASSIGNED_ORDER)){
                Intent startIntent = new Intent(this, RingtonePlayingService.class);
                startService(startIntent);

                intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra(AppConstants.NOTIFICATION_DATA, data);
                intent.putExtra(IntentConstants.NOTY_TYPE, type);
                intent.putExtra(IntentConstants.NOTY_MSG, message);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        }
    }

    public void generateNotification(RemoteMessage remoteMessage) {
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        String type = remoteMessage.getData().get("notification_type");
        String message = remoteMessage.getData().get("message");
        String status = remoteMessage.getData().get("status");
        String order_id = remoteMessage.getData().get("order_id");
        Intent intent = null;

        if (!type.isEmpty()) {
            if (type.equalsIgnoreCase("admin")) {
                intent = new Intent(this, MainActivity.class);
                intent.putExtra(Constants.NOTIFICATION_TYPE, "admin");
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            } else if (type.equalsIgnoreCase("block_notification")) {
                intent = new Intent(this, MainActivity.class);
                intent.putExtra(Constants.NOTIFICATION_TYPE, "admin");
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            } else if (type.equalsIgnoreCase("profile_status")) {
                intent = new Intent(this, MainActivity.class);
                intent.putExtra(Constants.NOTIFICATION_TYPE, "profile_status");
                intent.putExtra(Constants.STATUS, status);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            } else if (type.equalsIgnoreCase("payment_status")) {
//                intent = new Intent(this, OrderDetailNotificationActivity.class);
                intent.putExtra(Constants.ORDER_ID, order_id);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            } else if (type.equalsIgnoreCase("payment_mode_change")) {
//                intent = new Intent(this, OrderDetailNotificationActivity.class);
                intent.putExtra(Constants.ORDER_ID, order_id);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            }
        }
        PendingIntent contentIntent = PendingIntent.getActivity(this,
                (int) System.currentTimeMillis(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_ONE_SHOT
                        | PendingIntent.FLAG_CANCEL_CURRENT);

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this);
        notificationBuilder
                .setSmallIcon(getNotificationIcon())
                .setLargeIcon(notificationIcon(R.mipmap.ic_launcher))
                .setContentTitle(getString(R.string.app_name))
                .setContentText(message)
                .setSound(notification)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .setVibrate(new long[]{1000, 1000, 1000, 1000})
                .setLights(Color.RED, 3000, 3000);
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        /**
         * Oreo
         */

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String channelId = "com_lpg_rider_notificaiton_channel_id";
            CharSequence channelName = "LPG Rider Channel";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel notificationChannel = new NotificationChannel(channelId, channelName, importance);
            notificationChannel.enableLights(true);
            notificationChannel.setDescription(message);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.enableVibration(true);
            notificationChannel.setShowBadge(true);
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .build();
            notificationChannel.setSound(notification, audioAttributes);

            notificationChannel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
            assert notificationManager != null;
            notificationManager.createNotificationChannel(notificationChannel);
            notificationBuilder.setChannelId(channelId);
        }

        notificationManager.notify((int) System.currentTimeMillis() /* ID of notification */, notificationBuilder.build());
    }

    private void sendNotificationForCancelOrder(String message,String type) {
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Intent intent = new Intent();

        intent = new Intent(this, OrderActivity.class);
        intent.putExtra(IntentConstants.NOTY_TYPE,type);

        PendingIntent contentIntent = PendingIntent.getActivity(this,
                (int) System.currentTimeMillis(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_ONE_SHOT
                        | PendingIntent.FLAG_CANCEL_CURRENT);

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this);
        notificationBuilder
                .setSmallIcon(getNotificationIcon())
                .setLargeIcon(notificationIcon(R.mipmap.ic_launcher))
                .setContentTitle(getString(R.string.app_name))
                .setContentText(message)
                .setSound(notification)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .setVibrate(new long[]{1000, 1000, 1000, 1000})
                .setLights(Color.RED, 3000, 3000)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC);
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        /**
         * Oreo
         */

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String channelId = "com_lpg_rider_notificaiton_channel_id";
            CharSequence channelName = "LPG Rider Channel";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel notificationChannel = new NotificationChannel(channelId, channelName, importance);
            notificationChannel.enableLights(true);
            notificationChannel.setDescription(message);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.enableVibration(true);
            notificationChannel.setShowBadge(true);
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .build();
            notificationChannel.setSound(notification, audioAttributes);

            notificationChannel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
            assert notificationManager != null;
            notificationManager.createNotificationChannel(notificationChannel);
            notificationBuilder.setChannelId(channelId);
        }
        notificationManager.notify((int) System.currentTimeMillis() /* ID of notification */, notificationBuilder.build());
    }

    private int getNotificationIcon() {
        boolean useWhiteIcon = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP);
        return useWhiteIcon ? R.drawable.ic_rider_top : R.mipmap.ic_launcher;
    }

    private Bitmap notificationIcon(int ic_notification_rider) {
        Bitmap largeIcon = BitmapFactory.decodeResource(getResources(), ic_notification_rider);
        return largeIcon;
    }

    private void stopNewRequestRingToneService() {
        try {
            Intent intent = new Intent(this, RingtonePlayingService.class);
            stopService(intent);
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
    }

    private void sendCancelOrderBroadCast(String type,String message,int orderID, com.alnahla.model.login.Data  data){
        if(Utils.getAppInForeground())
            EventBus.getDefault().post(new MessageEvent(type,message));
        else{
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.putExtra(IntentConstants.NOTY_TYPE, type);
            intent.putExtra(IntentConstants.NOTY_MSG, message);
            intent.putExtra(IntentConstants.ORDER_ID,orderID);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra(AppConstants.NOTIFICATION_DATA, data);
            startActivity(intent);
        }
    }
}
