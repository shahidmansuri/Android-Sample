package com.alnahla.utils;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.customtabs.CustomTabsIntent;
import android.support.v4.content.ContextCompat;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.alnahla.AppConstants;
import com.alnahla.R;
import com.alnahla.ui.activity.MainActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by RajeshKushvaha on 24-05-17
 */

public class Utils {

    private static boolean isAppInForeground = false;
    public static MainActivity activityMain = null;

    public static String getRealPathFromURI(Context context, Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = context.getContentResolver().query(contentUri, proj, null, null, null);
        if (cursor != null) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        }
        return null;
    }

    public static int durationBetweenTwoTimes(String timestamp1, String timestamp2) {
        int min = 0;
        if (!timestamp1.equalsIgnoreCase("") && !timestamp2.equalsIgnoreCase("")) {
            Date time1 = new Date(Long.parseLong(timestamp1));
            Date time2 = new Date(Long.parseLong(timestamp2));

            long difference = time2.getTime() - time1.getTime();
            int days = (int) (difference / (1000 * 60 * 60 * 24));
            int hours = (int) ((difference - (1000 * 60 * 60 * 24 * days)) / (1000 * 60 * 60));
            min = (int) (difference - (1000 * 60 * 60 * 24 * days) - (1000 * 60 * 60 * hours)) / (1000 * 60);
            hours = (hours < 0 ? -hours : hours);
        }
        return min;
    }

    // to print the date in the UI
    public static String longToDateString(long timestamp) {
        Calendar cal = Calendar.getInstance();
        TimeZone tz = cal.getTimeZone();

        /* date formatter in local timezone */
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yyyy, HH:mm");
        sdf.setTimeZone(tz);

        String localTime = sdf.format(new Date(timestamp * 1000)); // I assume your timestamp is in seconds and you're converting to milliseconds?

        return localTime;
    }

    public static long dateToTimeStamp(String str_date) {
        //String str_date = "13-09-2011";
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date date = null;
        try {
            date = formatter.parse(str_date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        assert date != null;
        return date.getTime();
        //System.out.println("Today is " + date.getTime());
    }

    // to print the date in the UI
    public static String longToDateStringFilter(long timestamp) {
        Calendar cal = Calendar.getInstance();
        TimeZone tz = cal.getTimeZone();

        /* date formatter in local timezone */
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM''yy");
        sdf.setTimeZone(tz);

        String localTime = sdf.format(new Date(timestamp)); // I assume your timestamp is in seconds and you're converting to milliseconds?

        return localTime;
    }

    // to print the date in the UI
    public static String longToDateStringWithAtFormat(long timestamp) {
        Calendar cal = Calendar.getInstance();
        TimeZone tz = cal.getTimeZone();

        /* date formatter in local timezone */
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yyyy, HH:mm");
        sdf.setTimeZone(tz);

        String localTime = sdf.format(new Date(timestamp * 1000)); // I assume your timestamp is in seconds and you're converting to milliseconds?

        String time = localTime;
        return time;
    }

    public static String getDateFromLong(long mili) {
//        String dateString = new SimpleDateFormat("EEE, dd MMM yyyy hh:mm").format(new Date(mili));

        String dateString = new SimpleDateFormat("MMM dd,yyyy hh:mm a").format(new Date(mili));

        return dateString;
    }

    public static String getTimeFromLong(long mili) {
        String timeString = new SimpleDateFormat("hh:mm a").format(new Date(mili));

        return timeString;
    }

    public static String getTimeAgo(long time, Context ctx) {
        SimpleDateFormat newSdf = null;
        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
        cal.setTimeInMillis(time * 1000L);
        String date = null;
        long current = System.currentTimeMillis();
        if (current - (time * 1000L) < 60000) {
            date = TimeUnit.MILLISECONDS.toSeconds(current - (time * 1000L)) + " sec ago";
        } else if (current - (time * 1000L) < 3600000) {
            date = TimeUnit.MILLISECONDS.toMinutes(current - (time * 1000L)) + " mins ago";
        } else if (current - (time * 1000L) < 86400000) {
            date = TimeUnit.MILLISECONDS.toHours(current - (time * 1000L)) + " hours ago";
        } else if (current - (time * 1000L) < 604800000) {
            date = TimeUnit.MILLISECONDS.toDays(current - (time * 1000L)) + " days ago";
        } else {
            newSdf = new SimpleDateFormat("dd/mm/yyyy, HH:mm aa");
            TimeZone tz = cal.getTimeZone();
            newSdf.setTimeZone(tz);
            date = newSdf.format(new Date(time * 1000));
        }
        return date;
    }

    public static void openCustomTabs(Activity activity, Uri uri) {
        // create an intent builder
        CustomTabsIntent.Builder intentBuilder = new CustomTabsIntent.Builder();

        // Begin customizing
        // set toolbar colors
        intentBuilder.setToolbarColor(ContextCompat.getColor(activity, R.color.colorPrimary));
        intentBuilder.setSecondaryToolbarColor(ContextCompat.getColor(activity, R.color.colorPrimaryDark));

        // set start and exit animations
        intentBuilder.setStartAnimations(activity, R.anim.slide_in_right, R.anim.slide_out_left);
        intentBuilder.setExitAnimations(activity, android.R.anim.slide_in_left,
                android.R.anim.slide_out_right);

        // build custom tabs intent
        CustomTabsIntent customTabsIntent = intentBuilder.build();

        // launch the url
        customTabsIntent.launchUrl(activity, uri);
    }

    public static long strDateToTimeStamp(String str_date) {
        // create an intent builder
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date date = null;
        try {
            date = formatter.parse(str_date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date.getTime();
    }

    public static int dipToPixels(Activity context, float dipValue) {
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dipValue, metrics);
    }

    public static long getDurationInSecVideo(Context context, File file) {
        if (file == null || !file.exists())
            return 0;

        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        //use one of overloaded setDataSource() functions to set your data source
        retriever.setDataSource(context, Uri.fromFile(file));
        String time = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
        if (TextUtils.isEmpty(time))
            return 0;
        long timeInMillisec = Long.parseLong(time);

        retriever.release();
        return TimeUnit.MILLISECONDS.toSeconds(timeInMillisec);
    }

    public static long getFileSizeInMB(File file) {
        if (file == null || !file.exists())
            return 0;

        long fileSizeInBytes = file.length();
        // Convert the bytes to Kilobytes (1 KB = 1024 Bytes)
        long fileSizeInKB = fileSizeInBytes / 1024;
        // Convert the KB to MegaBytes (1 MB = 1024 KBytes)
        return fileSizeInKB / 1024;
    }

    public static void preventDoubleClick(final View view) {
        view.setEnabled(false);
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                view.setEnabled(true);
            }
        }, 2000);
    }

    public static ArrayList<String> getMessageFromResponseObject(Context context, JSONObject object) {
        ArrayList<String> message = new ArrayList<>();

        if (object != null && object.has("error")) {
            JSONArray errors_arr = object.optJSONArray("error");
            for (int i = 0; i < errors_arr.length(); i++) {
                message.add(errors_arr.optString(i));
            }
        }
        if (message.size() == 0) {
            message.add(context.getString(R.string.str_something_went_wrong));
        }
        return message;
    }

    //*****************************************************************
    public static boolean isValidPassword(String password) {

        Pattern pattern;
        Matcher matcher;
        String PASSWORD_PATTERN = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{6,15})";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();
    }

    public static boolean isValidEmail(CharSequence target) {
        return !TextUtils.isEmpty(target) && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    /**
     * Check if the device is connected to internet
     *
     * @return true if connected to internet false otherwise.
     */
    public boolean isConnectedToInternet(Context mContext) {
        ConnectivityManager connectivity = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = connectivity.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isAvailable() && activeNetwork.isConnected();
    }

    public static void showSoftKeyboard(EditText editText, Context mContext) {
        InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT);
    }

    public static void hideSoftKeyboard(Context mContext) {
        try {
            InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(((Activity) mContext).getCurrentFocus().getWindowToken(), 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static InputFilter filterPreventWhiteSpaces = new InputFilter() {
        public CharSequence filter(CharSequence source, int start, int end,
                                   Spanned dest, int dstart, int dend) {
            for (int i = start; i < end; i++) {
                if (Character.isWhitespace(source.charAt(i))) {
                    return "";
                }
            }
            return null;
        }
    };

    public static boolean isValidMobileNumber(String mobile) {
        String MOBILE_PATTERN = "^[1-9][0-9 ]*$";
        Pattern pattern = Pattern.compile(MOBILE_PATTERN);
        Matcher matcher = pattern.matcher(mobile);
        return matcher.matches();
    }

    public static boolean isMyServiceRunning(Activity activity, Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) activity.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    /*
        We have to return decimal point count and double value
     */
    public static String setDoubleDecimalPoints(int decimalPoints, double value) {
        String result = String.format("%." + decimalPoints + "f", value);
        return result;
    }


    public static String getMilesFromMeters(String meters) {
        return Utils.setDoubleDecimalPoints(AppConstants.DEFAULT_DECIMAL_POINTS, Double.parseDouble(meters) / Constants.dbMilesToMeters);
    }

    public static String getMinFromMili(String milliseconds) {
//        return Utils.setDoubleDecimalPoints(AppConstants.DEFAULT_DECIMAL_POINTS, Double.parseDouble(mins) / Constants.dbMiliToMin);
        return String.valueOf(TimeUnit.MILLISECONDS.toMinutes(Long.parseLong(milliseconds)));
    }

    public static String getMinFromSec(String seconds) {
//        return Utils.setDoubleDecimalPoints(AppConstants.DEFAULT_DECIMAL_POINTS, Double.parseDouble(mins) / Constants.dbMiliToMin);
        return String.valueOf(TimeUnit.SECONDS.toMinutes(Long.parseLong(seconds)));
    }

    public static String getMiliFromMin(String mins) {
        return String.valueOf(TimeUnit.MINUTES.toMillis(Long.parseLong(mins)));
    }

     /*

        This functions will help us to identify if our application is in foreground or background.
        From BaseActivity, in OnResume() we will set this veriable to true and from onPause() we will set this function to false;

     */

    public static void setIsAppInForeground(boolean isActive) {
        Utils.isAppInForeground = isActive;
    }

    public static boolean getAppInForeground() {
        return Utils.isAppInForeground;
    }

}
