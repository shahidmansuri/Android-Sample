package com.alnahla.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Awesome Pojo Generator
 */
public class RatingReviewsData {
    @SerializedName("two_rate_count")
    @Expose
    private String two_rate_count;
    @SerializedName("review_list_list")
    @Expose
    private List<ReviewsListData> review_list_list;
    @SerializedName("is_last")
    @Expose
    private String is_last;
    @SerializedName("one_rate_count")
    @Expose
    private String one_rate_count;
    @SerializedName("three_rate_count")
    @Expose
    private String three_rate_count;
    @SerializedName("review_count")
    @Expose
    private String review_count;
    @SerializedName("overall_rating")
    @Expose
    private float overall_rating;
    @SerializedName("five_rate_count")
    @Expose
    private String five_rate_count;
    @SerializedName("four_rate_count")
    @Expose
    private String four_rate_count;

    public void setTwo_rate_count(String two_rate_count) {
        this.two_rate_count = two_rate_count;
    }

    public String getTwo_rate_count() {
        return two_rate_count;
    }

    public void setReview_list_list(List<ReviewsListData> review_list_list) {
        this.review_list_list = review_list_list;
    }

    public List<ReviewsListData> getReview_list_list() {
        return review_list_list;
    }

    public void setIs_last(String is_last) {
        this.is_last = is_last;
    }

    public String getIs_last() {
        return is_last;
    }

    public void setOne_rate_count(String one_rate_count) {
        this.one_rate_count = one_rate_count;
    }

    public String getOne_rate_count() {
        return one_rate_count;
    }

    public void setThree_rate_count(String three_rate_count) {
        this.three_rate_count = three_rate_count;
    }

    public String getThree_rate_count() {
        return three_rate_count;
    }

    public void setReview_count(String review_count) {
        this.review_count = review_count;
    }

    public String getReview_count() {
        return review_count;
    }

    public void setOverall_rating(float overall_rating) {
        this.overall_rating = overall_rating;
    }

    public float getOverall_rating() {
        return overall_rating;
    }

    public void setFive_rate_count(String five_rate_count) {
        this.five_rate_count = five_rate_count;
    }

    public String getFive_rate_count() {
        return five_rate_count;
    }

    public void setFour_rate_count(String four_rate_count) {
        this.four_rate_count = four_rate_count;
    }

    public String getFour_rate_count() {
        return four_rate_count;
    }
}