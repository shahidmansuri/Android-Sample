package com.alnahla.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;

import com.alnahla.R;
import com.alnahla.databinding.ActivityNewContactUsBinding;
import com.alnahla.network.API_CONSTANTS;
import com.alnahla.network.API_EndPoints;
import com.alnahla.network.NetworkCall;
import com.alnahla.network.listeners.RetrofitResponseListener;
import com.alnahla.ui.BaseActivity;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class ContactUsActivity extends BaseActivity implements View.OnClickListener {

    private static final String TAG = ContactUsActivity.class.getSimpleName();
    ActivityNewContactUsBinding mBinder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinder = DataBindingUtil.setContentView(this, R.layout.activity_new_contact_us);

        setStatusBarColor(this,getResources().getColor(R.color.status_color_green));
        setUpToolBar();
        setUpUi();
    }

    public static void launch(Activity activity, boolean isFinishActivity) {
        if (isFinishActivity) {
            Intent intent = new Intent(activity, ContactUsActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        } else {
            Intent intent = new Intent(activity, ContactUsActivity.class);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        }
    }

    private void setUpUi() {

        mBinder.btnSubmit.setOnClickListener(this);
    }

    /*method to set up toolbar*/
    private void setUpToolBar() {
        mBinder.included.title.setText(getString(R.string.contac_us));
        mBinder.included.toolbar.setNavigationIcon(R.drawable.ic_back_arrow_white);
        mBinder.included.toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.btnSubmit:
                if (isValid())
                    apiContactUs(mBinder.etSubject.getText().toString().trim(),
                            mBinder.etMessage.getText().toString().trim());
                break;
        }
    }

    private void apiContactUs(String subject, String message) {
        HashMap<String, String> params = new HashMap<>();
        params.put(API_CONSTANTS.SUBJECT, subject);
        params.put(API_CONSTANTS.MESSAGE, message);

        NetworkCall.with(this)
                .setEndPoint(API_EndPoints.CONTACT_US)
                .setRequestParams(params)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                        showProgress(getResources().getString(R.string.txt_pls_wait));
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        stopProgress();
                        showToastShort(jsonObject.optString(API_CONSTANTS.MESSAGE));
                        onBackPressed();
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        String message = String.valueOf(messages);
                        showToastLong(message.substring(1, message.length() - 1));

                        stopProgress();
                    }
                }).makeCall();
    }

    private boolean isValid() {
        boolean isValid = false;
        if (TextUtils.isEmpty(mBinder.etSubject.getText().toString().trim())) {
            showErrorSnackBar(getApplicationContext().getResources().getString(R.string.v_subject));
            mBinder.etSubject.requestFocus();
        } else if (TextUtils.isEmpty(mBinder.etMessage.getText().toString().trim())) {
            showErrorSnackBar(getApplicationContext().getResources().getString(R.string.v_message));
            mBinder.etMessage.requestFocus();
        } else {
            isValid = true;
        }
        return isValid;
    }
}
