package com.alnahla.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Awesome Pojo Generator
 */
public class FAQData {
    @SerializedName("is_last")
    @Expose
    private Integer is_last;
    @SerializedName("faq")
    @Expose
    private List<Faq> faq;
    @SerializedName("message")
    @Expose
    private String message;

    public void setIs_last(Integer is_last) {
        this.is_last = is_last;
    }

    public Integer getIs_last() {
        return is_last;
    }

    public void setFaq(List<Faq> faq) {
        this.faq = faq;
    }

    public List<Faq> getFaq() {
        return faq;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}