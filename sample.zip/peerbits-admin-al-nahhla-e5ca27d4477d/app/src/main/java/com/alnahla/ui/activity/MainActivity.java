package com.alnahla.ui.activity;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView.OnNavigationItemSelectedListener;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.AppCompatImageView;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;

import com.alnahla.AppConstants;
import com.alnahla.AppStrings;
import com.alnahla.R;
import com.alnahla.databinding.ActivityNewMainBinding;
import com.alnahla.model.login.Data;
import com.alnahla.model.newlogin.User_info;
import com.alnahla.service.PingService;
import com.alnahla.ui.BaseActivity;
import com.alnahla.ui.dialog.MessageDialog;
import com.alnahla.ui.fragments.EarningFragment;
import com.alnahla.ui.fragments.HistoryFragment;
import com.alnahla.ui.fragments.HomeFragment;
import com.alnahla.ui.fragments.NotificationFragment;
import com.alnahla.ui.fragments.SettingFragment;
import com.alnahla.utils.Utils;
import com.alnahla.utils.pref.IntentConstants;
import com.alnahla.utils.pref.PreferenceKeys;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.util.List;

public class MainActivity extends BaseActivity implements OnNavigationItemSelectedListener, OnCheckedChangeListener, View.OnClickListener {
    public ActivityNewMainBinding mBinding;
    private String callPermission = Manifest.permission.CALL_PHONE;
    private Fragment mFragmentDashboard;
    private FragmentTransaction ft;
    private User_info userInfo;
    private NotificationFragment notificationFragment;
    private boolean isBackDisable = false;
    private boolean doubleBackToExitPressedOnce = false;
    private com.alnahla.model.login.Data notificationData;
    private String notificationType, notificationMsg;
    private Intent pingServiceIntent;
    private int DELAY_DOUBLEBACK = 2000;
    public static void launch(Activity activity, boolean isFinishActivity) {
        if (isFinishActivity) {
            Intent intent = new Intent(activity, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        } else {
            Intent intent = new Intent(activity, MainActivity.class);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_new_main);
        setStatusBarColor(this, getResources().getColor(R.color.status_color_green));
        init();
        setUpToolBar();
        setOnListener();
        checkIfNewRequestArrived();
        openAppLock();
        pushHomeFragment();
    }

    /**
     * It will start PingService to send location in background
     */
    public void bindPingService() {
        boolean isPingServiceRunning = Utils.isMyServiceRunning(this, PingService.class);

        if (isPingServiceRunning)
            return;

        pingServiceIntent = new Intent(this, PingService.class);
        startService(pingServiceIntent);
    }



    /*
        This function will on/off the Online Switch as data saved in session, when user appear back after killing application
     */
    public void controlOnlineOfflineSwitch(boolean isOnline) {
        mBinding.included.switchOnOff.setChecked(isOnline);
    }

    private void pushHomeFragment() {
        if (mFragmentDashboard == null) {
            setToolBarWithIcon(getResources().getString(R.string.toolbar_home), View.VISIBLE, View.VISIBLE, View.GONE);
            mFragmentDashboard = new HomeFragment();
        }
        Bundle bundle = new Bundle();
        bundle.putSerializable(AppConstants.NOTIFICATION_DATA, notificationData);
        bundle.putString(IntentConstants.NOTY_TYPE, notificationType);
        bundle.putString(IntentConstants.NOTY_MSG, notificationMsg);
        mFragmentDashboard.setArguments(bundle);
        pushFragment(mFragmentDashboard);
    }

    @Override
    protected void onResume() {
        super.onResume();
        userInfo = gson.fromJson(session.getValueFromKey(PreferenceKeys.KEY_USER, ""), User_info.class);
        setDataInNavigationHeader();
    }

    private void init() {
        notificationFragment = new NotificationFragment();
        userInfo = gson.fromJson(session.getValueFromKey(PreferenceKeys.KEY_USER, ""), User_info.class);
    }

    private void setDataInNavigationHeader() {
        if (userInfo != null) {
            View headerView = mBinding.navView.getHeaderView(0);
            if (userInfo.getFull_name() != null) {
                TextView navUsername = headerView.findViewById(R.id.navUserName);
                navUsername.setText(userInfo.getFull_name());
            }
            if (userInfo.getImage() != null) {
                AppCompatImageView navProfile = headerView.findViewById(R.id.navProfile);
                glideLoader.loadImageCircle(userInfo.getImage(), navProfile);
            }
            if (userInfo.getAddress() != null) {
                TextView navAddress = headerView.findViewById(R.id.navUserAddress);
                navAddress.setText(userInfo.getAddress());
            }
        }
    }

    private void setOnListener() {
        mBinding.included.switchOnOff.setOnCheckedChangeListener(this);
        mBinding.included.ivNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inTroubleDialog();
            }
        });
        mBinding.navView.setNavigationItemSelectedListener(this);
    }

    private void setUpToolBar() {
        setSupportActionBar(mBinding.included.switchToolbar);
        android.support.v7.app.ActionBar ab = getSupportActionBar();
        if (ab != null) {
            ab.show();
            ab.setDisplayHomeAsUpEnabled(true);
            ab.setDisplayShowTitleEnabled(false);
            setUpNavigationDrawer();
            // ab.setHomeAsUpIndicator(R.drawable.ic_menu);
        }
        mBinding.included.switchToolbar.setNavigationIcon(R.drawable.ic_menu);
        mBinding.included.title.setText(getResources().getString(R.string.toolbar_home));
    }


    private void setUpNavigationDrawer() {
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mBinding.drawerLayout, mBinding.included.switchToolbar, R.string.app_name, R.string.app_name);
        mBinding.drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
        switch (compoundButton.getId()) {
            case R.id.switchOnOff:
                if (isChecked) {
                    Fragment f = getSupportFragmentManager().findFragmentById(R.id.mainContainer);
                    if (f instanceof HomeFragment) {
                        ((HomeFragment) f).showHide(true);
                    }
                } else {
                    Fragment f = getSupportFragmentManager().findFragmentById(R.id.mainContainer);
                    if (f instanceof HomeFragment) {
                        ((HomeFragment) f).showHide(false);
                    }
                }
                break;
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_home:
                mBinding.drawerLayout.openDrawer(GravityCompat.START);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_home:
                setToolBarWithIcon(getResources().getString(R.string.toolbar_home), View.VISIBLE, View.VISIBLE, View.GONE);

                if (mFragmentDashboard == null)
                    mFragmentDashboard = new HomeFragment();
                Bundle bundle = new Bundle();
                mFragmentDashboard.setArguments(bundle);
                ft = getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.mainContainer, mFragmentDashboard);
                ft.commit();
                break;
            case R.id.nav_history:
                setToolBarWithIcon(getResources().getString(R.string.toolbar_orderHistory), View.VISIBLE, View.INVISIBLE, View.GONE);
                pushFragment(new HistoryFragment());
                break;
            case R.id.nav_earning:
                setToolBarWithIcon(getResources().getString(R.string.toolbar_earning), View.INVISIBLE, View.INVISIBLE, View.INVISIBLE);
                pushFragment(new EarningFragment());
                break;
            case R.id.nav_notification:
                setToolBarWithIcon(getResources().getString(R.string.toolbar_notifications), View.INVISIBLE, View.INVISIBLE, View.VISIBLE);
                pushFragment(notificationFragment);
                break;
            case R.id.nav_setting:
                setToolBarWithIcon(getResources().getString(R.string.toolbar_setting), View.INVISIBLE, View.INVISIBLE, View.GONE);
                pushFragment(new SettingFragment());

                break;
            case R.id.nav_logout:
                logOutDialog();
                break;

        }
        mBinding.drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }


    public void pushFragment(Fragment fragment) {
        //if fragment not in back stack, create it.
        ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.mainContainer, fragment);
        ft.commit();
    }

    private void logOutDialog() {

        new MessageDialog(MainActivity.this)
                .setTitle(getString(R.string.logout))
                .setMessage(getString(R.string.are_sure_you_want_to_logout))
                .setPositiveButton(getString(R.string.yes), new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        logout();
                    }
                }).setNegativeButton(getString(R.string.no), new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).show();

    }

    private void logout() {
        session.clearSession();
        unBindPingService();
        startActivity(new Intent(this, WelcomeActivity.class));
        finish();
    }

    private void inTroubleDialog() {
        new MessageDialog(MainActivity.this)
                .setTitle(getString(R.string.alert_message_title_in_trouble))
                .setMessage(getString(R.string.alert_message_msg_calltoadmin))
                .setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        checkForCallPermission();
                        dialogInterface.dismiss();
                    }
                }).setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).show();
    }

    public void checkForCallPermission() {
        try {
            Dexter.withActivity(this).withPermissions(callPermission).withListener(new MultiplePermissionsListener() {
                @Override
                public void onPermissionsChecked(MultiplePermissionsReport report) {

                    if (report.areAllPermissionsGranted())
                        callPhone(session.getValueFromKey(PreferenceKeys.KEY_ADMIN_CONTACT, ""));
                    else if (mFragmentDashboard != null) {

                        ((HomeFragment) mFragmentDashboard).openCallDialog();
//                        showSnackBar(getResources().getString(R.string.err_grantAllPer));
                    }

                }

                @Override
                public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                    token.continuePermissionRequest();
                }

            })
                    .onSameThread()
                    .check();
        } catch (Exception e) {

        }
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.tvClearAll:
                notificationFragment.clearAll();
                break;
        }
    }

    private void setToolBarWithIcon(String title, int notificationStatus, int switchStatus, int clearAll) {
        mBinding.included.title.setText(title);
        mBinding.included.ivNotification.setVisibility(notificationStatus);
        mBinding.included.switchOnOff.setVisibility(switchStatus);
        mBinding.included.tvClearAll.setVisibility(clearAll);
        mBinding.included.tvClearAll.setOnClickListener(this);
    }

    public void makeSwitchVisibleInvisible(int switchStatus) {
        mBinding.included.switchOnOff.setVisibility(switchStatus);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Fragment f = getSupportFragmentManager().findFragmentById(R.id.mainContainer);
        if (f instanceof HomeFragment) {
            f.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawerLayout);
        if (isBackDisable) return;
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
//            super.onBackPressed();
            try {
                if (doubleBackToExitPressedOnce) {
                    finish();
                    return;
                }
                this.doubleBackToExitPressedOnce = true;
                showToastShort(AppStrings.MSG_DOUBLE_PRESS_EXIT);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        doubleBackToExitPressedOnce = false;
                    }
                }, DELAY_DOUBLEBACK);
            } catch (Exception e) {
                super.onBackPressed();
            }
        }
    }

    private void checkIfNewRequestArrived() {
        if (getIntent().hasExtra(AppConstants.NOTIFICATION_DATA)) {
            notificationData = (Data) getIntent().getSerializableExtra(AppConstants.NOTIFICATION_DATA);
            notificationType = getIntent().getStringExtra(IntentConstants.NOTY_TYPE);
            notificationMsg = getIntent().getStringExtra(IntentConstants.NOTY_MSG);
        } else {
            notificationData = new Data();
            notificationData.setIs_new_request(AppConstants.NO_VALUE_SET);
            notificationType = AppConstants.NO_VALUE_SET_STRING;
            notificationMsg = AppConstants.NO_VALUE_SET_STRING;
        }
    }
    public void setVisibilityClearAllBt(int isVisible){
        mBinding.included.tvClearAll.setVisibility(isVisible);
    }
}