package com.alnahla.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Awesome Pojo Generator
 */
public class OrderDetailData {
    @SerializedName("payment_type")
    @Expose
    private String payment_type;
    @SerializedName("payment_status")
    @Expose
    private String payment_status;
    @SerializedName("cancelation_charge")
    @Expose
    private String cancelation_charge;
    @SerializedName("flat_charge")
    @Expose
    private String flat_charge;
    @SerializedName("user_info")
    @Expose
    private OrderDetailUserInfo user_info;
    @SerializedName("price")
    @Expose
    private List<OrderDetailPrice> price;
    @SerializedName("order_price")
    @Expose
    private String order_price;
    @SerializedName("order_time")
    @Expose
    private String order_time;
    @SerializedName("order_id")
    @Expose
    private String order_id;
    @SerializedName("order_status")
    @Expose
    private String order_status;
    @SerializedName("order_type_compelete")
    @Expose
    private List<OrderList> order_type_compelete;

    public void setPayment_type(String payment_type) {
        this.payment_type = payment_type;
    }

    public String getPayment_type() {
        return payment_type;
    }

    public void setUser_info(OrderDetailUserInfo user_info) {
        this.user_info = user_info;
    }

    public OrderDetailUserInfo getUser_info() {
        return user_info;
    }

    public void setPrice(List<OrderDetailPrice> price) {
        this.price = price;
    }

    public List<OrderDetailPrice> getPrice() {
        return price;
    }

    public void setOrder_price(String order_price) {
        this.order_price = order_price;
    }

    public String getOrder_price() {
        return order_price;
    }

    public void setOrder_time(String order_time) {
        this.order_time = order_time;
    }

    public String getOrder_time() {
        return order_time;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_list(List<OrderList> order_type_compelete) {
        this.order_type_compelete = order_type_compelete;
    }

    public List<OrderList> getOrder_list() {
        return order_type_compelete;
    }

    public String getCancelation_charge() {
        return cancelation_charge;
    }

    public void setCancelation_charge(String cancelation_charge) {
        this.cancelation_charge = cancelation_charge;
    }

    public String getPayment_status() {
        return payment_status;
    }

    public void setPayment_status(String payment_status) {
        this.payment_status = payment_status;
    }

    public String getOrder_status() {
        return order_status;
    }

    public void setOrder_status(String order_status) {
        this.order_status = order_status;
    }

    public String getFlat_charge() {
        return flat_charge;
    }

    public void setFlat_charge(String flat_charge) {
        this.flat_charge = flat_charge;
    }
}