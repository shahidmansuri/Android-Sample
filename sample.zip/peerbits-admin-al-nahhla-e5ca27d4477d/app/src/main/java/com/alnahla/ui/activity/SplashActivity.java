package com.alnahla.ui.activity;

import android.annotation.SuppressLint;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.databinding.DataBindingUtil;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;

import com.alnahla.R;
import com.alnahla.databinding.ActivitySplashBinding;
import com.alnahla.model.notification.NotificationData;
import com.alnahla.ui.BaseActivity;
import com.alnahla.utils.Constants;
import com.alnahla.utils.Logger;
import com.alnahla.utils.pref.PreferenceKeys;
import com.google.firebase.iid.FirebaseInstanceId;

import java.security.MessageDigest;

public class SplashActivity extends BaseActivity {

    private ActivitySplashBinding mBinding;
    private NotificationData notificationData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFullScreenView();
        getHashKey();
        getIntentData();

    }

    private void getIntentData() {
        if (getIntent().getExtras() != null) {
            notificationData = ((NotificationData) getIntent().getSerializableExtra("NotificationData"));
        }
    }

    public void setFullScreenView() {
        if (Build.VERSION.SDK_INT < 19) {
            View v = this.getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        }
        mBinding = DataBindingUtil.setContentView(SplashActivity.this, R.layout.activity_splash);
//        MainActivity.launch(SplashActivity.this, true);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                if (session.getFlagFromKey(PreferenceKeys.KEY_LOGIN,true)) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            MainActivity.launch(SplashActivity.this, true);
                        }
                    }, 1500);

                } else {
                    WelcomeActivity.launch(SplashActivity.this,true);
                }
            }
        }, 1500);
    }

    @Override
    public void onBackPressed() {

    }

    /**
     * Function for fetching Hash Key, please comment this function once you are done with
     */
    private void getHashKey() {
        try {
            @SuppressLint("PackageManagerGetSignatures") PackageInfo info = getPackageManager().getPackageInfo(getApplicationContext().getPackageName(),
                    PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
