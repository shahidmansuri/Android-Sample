package com.alnahla.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Awesome Pojo Generator
 */
public class Reason {
    @SerializedName("reason")
    @Expose
    private String reason;
    @SerializedName("translation_id")
    @Expose
    private Integer translation_id;
    @SerializedName("reason_id")
    @Expose
    private Integer reason_id;

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getReason() {
        return reason;
    }

    public void setTranslation_id(Integer translation_id) {
        this.translation_id = translation_id;
    }

    public Integer getTranslation_id() {
        return translation_id;
    }

    public void setReason_id(Integer reason_id) {
        this.reason_id = reason_id;
    }

    public Integer getReason_id() {
        return reason_id;
    }
}