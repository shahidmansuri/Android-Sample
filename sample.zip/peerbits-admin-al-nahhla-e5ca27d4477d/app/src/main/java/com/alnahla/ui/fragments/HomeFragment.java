package com.alnahla.ui.fragments;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.alnahla.AppConstants;
import com.alnahla.R;
import com.alnahla.databinding.FragmentNewHomeBinding;
import com.alnahla.eventbus.MessageEvent;
import com.alnahla.interfaces.InterfaceAPI;
import com.alnahla.model.GoogleMapModel;
import com.alnahla.model.login.Order_details;
import com.alnahla.model.login.Restaurant_details;
import com.alnahla.model.order_detais.Data;
import com.alnahla.network.API_CONSTANTS;
import com.alnahla.network.API_EndPoints;
import com.alnahla.network.NetworkCall;
import com.alnahla.network.common_api.ApisCommon;
import com.alnahla.network.listeners.RetrofitResponseListener;
import com.alnahla.service.RingtonePlayingService;
import com.alnahla.ui.BaseFragment;
import com.alnahla.ui.activity.MainActivity;
import com.alnahla.ui.activity.NewRequestDialogActivity;
import com.alnahla.ui.activity.OrderActivity;
import com.alnahla.ui.activity.OrderCancelActivity;
import com.alnahla.ui.dialog.MessageDialog;
import com.alnahla.utils.Logger;
import com.alnahla.utils.Utils;
import com.alnahla.utils.pref.IntentConstants;
import com.alnahla.utils.pref.PreferenceKeys;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jay.googlelocation.Globle.Constants;
import com.jay.googlelocation.Globle.GoogleDistanceAPI;
import com.jay.googlelocation.LocationFetcher;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class HomeFragment extends BaseFragment implements View.OnClickListener, OnMapReadyCallback {

    private static final int ORDER_CANCEL_CODE = 2;
    private FragmentNewHomeBinding mBinder;
    private com.alnahla.model.login.Data dashBoardData;
    private String notificationType, notificationMsg;
    private final int LOC_SETTING = 3;
    private final int CALL_SETTING = 5;
    private final int LOC_FETCH = 0;
    private final int NEW_REQUEST = 1;
    private final int ORDER_STARTED = 4;

    double dbDriverLat = 0.0, dbDriverLng = 0.0;
    double dbRestLat = 0.0, dbRestLng = 0.0;


    public static GoogleMapModel googleMapModel;
    private GoogleMap googleMap;
    private SupportMapFragment supportMapFragment;

    private int intIsOrderRunning = AppConstants.NO_ORDERS;
    private Order_details orderDetailsCurrent;

    private Integer intOrderId;

    private ApisCommon apisCommon;
    private Marker markerStartingPoint, markerEndPoint;
    private String estDistanceFromAPI;
    private String etaFromAPI;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (mBinder == null) {
            mBinder = DataBindingUtil.inflate(inflater, R.layout.fragment_new_home, container, false);
            setHasOptionsMenu(true);
        }
        Logger.e("HomeFragment",";onCreateView-");
        init(savedInstanceState);
        setUI();
        setListeners();
        checkIfNewRequest();

        return mBinder.getRoot();
    }

    private void checkIfNewRequest() {
        notificationType = getArguments().getString(IntentConstants.NOTY_TYPE);
        notificationMsg = getArguments().getString(IntentConstants.NOTY_MSG);
        dashBoardData = (com.alnahla.model.login.Data) getArguments().getSerializable(AppConstants.NOTIFICATION_DATA);
        if (dashBoardData != null && dashBoardData.getIs_new_request() == AppConstants.REQUESTED) {

            orderDetailsCurrent = dashBoardData.getOrder_details();
            intOrderId = orderDetailsCurrent.getOrder_id();
            if (notificationType.equalsIgnoreCase(API_CONSTANTS.NOTIFICATION_TYPE_NEW_ORDER)) {

                notificationType = AppConstants.NO_VALUE_SET_STRING;
                NewRequestDialogActivity.launch(getActivity(), false, dbDriverLat, dbDriverLng, orderDetailsCurrent, NEW_REQUEST);
            } else if (notificationType.equalsIgnoreCase(API_CONSTANTS.NOTIFICATION_TYPE_ASSIGNED_ORDER)) {
                new MessageDialog(getActivity())
                        .setTitle(getString(R.string.alert_msg_title_assignedOrder))
                        .setMessage(notificationMsg)
                        .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                 /*
                                    Stopping the ringtone service
                                 */
                                getActivity().stopService(new Intent(getActivity(), RingtonePlayingService.class));

                                OrderActivity.launch(getActivity(), false, dbDriverLat, dbDriverLng, intOrderId, ORDER_STARTED, false, null, notificationType);

//                                callOrderActivity(dbDriverLat, dbDriverLng, intOrderId, ORDER_STARTED, false, null, notificationType);
                            }
                        })
                        .cancelable(false)
                        .show();
            } else if (notificationType.equalsIgnoreCase(API_CONSTANTS.NOTI_TYPE_CANCEL_ORDER_ADMIN) || notificationType.equalsIgnoreCase(API_CONSTANTS.NOTI_TYPE_CANCEL_ORDER_REST)) {
                int intOrderId = dashBoardData.getOrder_details().getOrder_id();
                OrderActivity.launch(getActivity(), false, dbDriverLat, dbDriverLng, intOrderId, ORDER_STARTED, false, null, notificationType);
//                callOrderActivity(dbDriverLat, dbDriverLng, intOrderId, ORDER_STARTED, false, null, notificationType);
            }
        } else {
            dashBoardAPI();
        }
    }


    private void setUI() {
        showHide(session.getFlagFromKey(PreferenceKeys.KEY_IS_ONLINE));
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap = googleMap;

        this.googleMap.getUiSettings().setZoomControlsEnabled(true);
        this.googleMap.setMinZoomPreference(6.0f);


        setMyCurrentLocation();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case LOC_FETCH:
                if (resultCode == Activity.RESULT_OK) {
                    if (data.getIntExtra(Constants.PERMISSION, Constants.DENIED) == Constants.GRANTED) {
                        dbDriverLat = data.getDoubleExtra(Constants.LATITUDE, 0.0);
                        dbDriverLng = data.getDoubleExtra(Constants.LONGITUDE, 0.0);
                        setMyCurrentLocation();
                        doCallOrderActivity();

                    } else {
                        openLocSettingDialog();
                    }
                }
                break;

            case NEW_REQUEST:
                if (resultCode == Activity.RESULT_OK) {
                    int resData = data.getIntExtra(IntentConstants.REQUEST_STATUS, com.alnahla.utils.Constants.DEFAULT_ORDER_STATUS);
                    if (data.hasExtra(IntentConstants.ETA))
                        etaFromAPI = data.getStringExtra(IntentConstants.ETA);
                    if (resData == com.alnahla.utils.Constants.ORDER_ACCEPT) {

                        /*
                            Order Accepted, call api
                         */
                        updateOrderStatus(AppConstants.ACCEPTED, API_CONSTANTS.REASON_ID_OTHERS, AppConstants.NO_VALUE_SET_STRING, etaFromAPI,false);


                    } else if (resData == com.alnahla.utils.Constants.ORDER_CANCEL) {

                        setVisibilityOrderNoOrder(View.GONE, View.VISIBLE);
                        int reqStatus = data.getIntExtra(IntentConstants.REQUEST_STATUS, com.alnahla.utils.Constants.DEFAULT_ORDER_STATUS);
                        int reasonID = data.getIntExtra(IntentConstants.REASON_ID, AppConstants.NO_VALUE_SET);
                        String othersComment = data.getStringExtra(IntentConstants.OTHERS_COMMENT);

                        updateOrderStatus(AppConstants.REJECTED, reasonID, othersComment, AppConstants.NO_VALUE_SET_STRING,false);
                    } else if (resData == com.alnahla.utils.Constants.ORDER_SKIPPED) {
                        new MessageDialog(getActivity())
                                .setTitle(getString(R.string.alert_message_title_skipped))
                                .setMessage(getString(R.string.alert_msg_skipOrder))
                                .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                    }
                                })
                                .cancelable(false)
                                .show();
                    }
                }
                break;
            case LOC_SETTING:
                getCurrentLocation();
                break;
            case CALL_SETTING:
                ((MainActivity) getActivity()).checkForCallPermission();
                break;
            case ORDER_STARTED:
                if (resultCode == Activity.RESULT_OK) {
                    session.setFlageFromKey(PreferenceKeys.KEY_SENDFEEDBACK,false);
                    if (data.hasExtra(IntentConstants.ORDER_COMPLETED)) {
                        notificationType = AppConstants.NO_VALUE_SET_STRING;
                        dashBoardAPI();
                    }
                    setVisibilityOrderNoOrder(View.GONE, View.VISIBLE);
                    googleMap.clear();
                }
                break;


            case ORDER_CANCEL_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    int resData = data.getIntExtra(IntentConstants.REQUEST_STATUS, com.alnahla.utils.Constants.DEFAULT_ORDER_STATUS);
                    int reasonID = data.getIntExtra(IntentConstants.REASON_ID, AppConstants.NO_VALUE_SET);
                    String othersComment = data.getStringExtra(IntentConstants.OTHERS_COMMENT);

                    if (resData == com.alnahla.utils.Constants.ORDER_CANCEL) {
                        /*
                            Order Rejected, call api
                         */
                        updateOrderStatus(AppConstants.REJECTED, reasonID, othersComment,AppConstants.NO_VALUE_SET_STRING,true);

                    } else if (resData == com.alnahla.utils.Constants.ORDER_CANCEL_REJECTED) {

                    }
                }
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.llOnline:
                if (dashBoardData != null && dashBoardData.getIs_order_running().equals(AppConstants.ORDER_RUNNING)) {
                    NewRequestDialogActivity.launch(getActivity(), false, dbDriverLat, dbDriverLng, orderDetailsCurrent, NEW_REQUEST);
                }
                break;

            case R.id.llRestaurantDetails:
                OrderActivity.launch(getActivity(), false, dbDriverLat, dbDriverLng, intOrderId, ORDER_STARTED, false, null, notificationType);
//                callOrderActivity(dbDriverLat, dbDriverLng, intOrderId, ORDER_STARTED, false, null, notificationType);
                break;

            case R.id.btnArrived:
                OrderActivity.launch(getActivity(), false, dbDriverLat, dbDriverLng, intOrderId, ORDER_STARTED, false, null, notificationType);
//                callOrderActivity(dbDriverLat, dbDriverLng, intOrderId, ORDER_STARTED, false, null, notificationType);
                break;

            case R.id.tvHelpMe:
                OrderCancelActivity.launch(getActivity(), false, ORDER_CANCEL_CODE);
                break;
        }
    }

    /*

        Public methods

     */

    public void showHide(boolean isShow) {
        setVisibilityOnlineOffline(isShow);
        if (isShow) {
            ((MainActivity) mContext).bindPingService();
            getCurrentLocation();
        } else {
            ((MainActivity) mContext).unBindPingService();
        }
        // setting status, if user do online-offline manually
        session.setFlageFromKey(PreferenceKeys.KEY_IS_ONLINE, isShow);
        doCallOrderActivity();
    }
/*
       Public methods

     */

    private void init(Bundle savedInstanceState) {
        notificationType = AppConstants.NO_VALUE_SET_STRING;
        apisCommon = new ApisCommon();
        etaFromAPI = AppConstants.NO_VALUE_SET_STRING;

        googleMapModel = new GoogleMapModel();
//        if (supportMapFragment == null)
//            supportMapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
//        supportMapFragment.getMapAsync(this);

        mBinder.map.onCreate(savedInstanceState);
        MapsInitializer.initialize(this.getActivity());

        mBinder.map.getMapAsync(this);


    }

    private void setListeners() {
        mBinder.llOnline.setOnClickListener(this);
        mBinder.llRestaurantDetails.setOnClickListener(this);
        mBinder.btnArrived.setOnClickListener(this);
        mBinder.tvHelpMe.setOnClickListener(this);
    }

    //Details for Driver

    private void dashBoardAPI() {
        HashMap<String, String> params = new HashMap<>();

        NetworkCall.with(getActivity())
                .setEndPoint(API_EndPoints.DASHBOARD)
                .setRequestParams(params)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                        showProgress(getString(R.string.txt_pls_wait));
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        stopProgress();

                        GsonBuilder gsonBuilder = new GsonBuilder();
                        Gson gson = gsonBuilder.create();

                        dashBoardData = gson.fromJson(jsonObject.toString(), com.alnahla.model.login.Data.class);
                        if (dashBoardData != null) {
                            if (dashBoardData.getIs_order_running() != null) {
                                intIsOrderRunning = dashBoardData.getIs_order_running();
                            }
                            if (intIsOrderRunning == AppConstants.ORDER_RUNNING) {
                                orderDetailsCurrent = dashBoardData.getOrder_details();
                                dbRestLat = orderDetailsCurrent.getRestaurant_details().getRestaurant_latitude();
                                dbRestLng = orderDetailsCurrent.getRestaurant_details().getRestaurant_longitude();
                                intOrderId = orderDetailsCurrent.getOrder_id();
                            }
                        }

                        // if Order is running and user is online, then move to order Activity
                        doCallOrderActivity();
                        //   callGoogleApi();
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        errorHandleFromApi(getActivity(), messages,statusCode);
                        stopProgress();
                    }

                }).makeCall();
    }


    private void getCurrentLocation() {
        /*
            Here we are using external library to get current location
         */

        Intent intent_location = new Intent(getActivity(), LocationFetcher.class);
        intent_location.putExtra(Constants.TYPE, Constants.LOCATION_FETCH);
        startActivityForResult(intent_location, LOC_FETCH);
    }

    private void setVisibilityOrderNoOrder(int orderAcccept, int noOrder) {
        mBinder.svOrderAccept.setVisibility(orderAcccept);
        mBinder.llNoOrder.setVisibility(noOrder);
        MainActivity mainActivity = (MainActivity) getActivity();
        mainActivity.makeSwitchVisibleInvisible(noOrder);
    }

    private void setRestDetailsAndShowGooglePath() {
        Restaurant_details restaurant_details = orderDetailsCurrent.getRestaurant_details();
        if (restaurant_details != null) {
            glideLoader.loadImageCircle(restaurant_details.getRestaurant_image(), mBinder.ivRest);
            mBinder.tvRestAddress.setText(restaurant_details.getRestaurant_address());
            mBinder.tvRestName.setText(restaurant_details.getRestaurant_name());
            mBinder.tvOrderId.setText(getResources().getString(R.string.msg_hash) + String.valueOf(intOrderId));
            dbRestLat = orderDetailsCurrent.getRestaurant_details().getRestaurant_latitude();
            dbRestLng = orderDetailsCurrent.getRestaurant_details().getRestaurant_longitude();

            drawRouteOnMap(dbDriverLat, dbDriverLng, dbRestLat, dbRestLng);
        }
    }

    private void setVisibilityOnlineOffline(boolean isOnline) {
        if (isOnline) {
            mBinder.llOnline.setVisibility(View.VISIBLE);
            mBinder.llOffline.setVisibility(View.GONE);
        } else {
            mBinder.llOnline.setVisibility(View.GONE);
            mBinder.llOffline.setVisibility(View.VISIBLE);
        }

        ((MainActivity) getActivity()).controlOnlineOfflineSwitch(isOnline);
    }

    @SuppressLint("MissingPermission")
    private void setMyCurrentLocation() {
        if (googleMap != null && dbDriverLat != 0.0 && dbDriverLng != 0.0) {
            googleMap.setMyLocationEnabled(true);
            // Creating a LatLng object for the current location
            LatLng latLng = new LatLng(dbDriverLat, dbDriverLng);

            // Showing the current location in Google Map
            googleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));

            // Zoom in the Google Map
            googleMap.animateCamera(CameraUpdateFactory.zoomTo(15));
        }
    }

    private void openLocSettingDialog() {
        new MessageDialog(getActivity())
                .setTitle(getString(R.string.alert_message_title_perReq))
                .setMessage(getString(R.string.alert_message_msg_perReq))
                .setPositiveButton(getString(R.string.alert_msg_openSetting), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ((MainActivity)getActivity()).openApplicationSettingScreen(getActivity(), LOC_SETTING);
                        dialogInterface.dismiss();
                    }
                })
                .cancelable(false)
                .show();
    }

    public void openCallDialog() {
        new MessageDialog(getActivity())
                .setTitle(getString(R.string.alert_message_title_perReq))
                .setMessage(getString(R.string.alert_message_msg_perReqCall))
                .setPositiveButton(getString(R.string.alert_msg_openSetting), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ((MainActivity)getActivity()).openApplicationSettingScreen(getActivity(), CALL_SETTING);
                        dialogInterface.dismiss();
                    }
                })
                .cancelable(false)
                .show();
    }

    private void doCallOrderActivity() {
        if (intIsOrderRunning == AppConstants.ORDER_RUNNING && session.getFlagFromKey(PreferenceKeys.KEY_IS_ONLINE) && dbDriverLat != 0.0) {
            OrderActivity.launch(getActivity(), false, dbDriverLat, dbDriverLng, intOrderId, ORDER_STARTED, false, null, notificationType);
//            callOrderActivity( dbDriverLat, dbDriverLng, intOrderId, ORDER_STARTED, false, null, notificationType);
        }
    }

    private void updateOrderStatus(final int is_accepted, final int reasonID, final String othersComment, String etaFromAPI, final boolean isOrderRunning) {

        apisCommon.apiCancelAcceptOrder(getContext(), String.valueOf(intOrderId), reasonID, othersComment, is_accepted, etaFromAPI, new InterfaceAPI() {
            @Override
            public void onPreExecute() {
                showProgress();
            }

            @Override
            public void apiSuccessful(int statusCode, JSONObject jsonObject, String response) {
                stopProgress();
                Data orderStatusUpdateData = gson.fromJson(jsonObject.toString(), Data.class);
                showSnackBar(orderStatusUpdateData.getMessage());
                if (is_accepted == AppConstants.ACCEPTED) {
                    setVisibilityOrderNoOrder(View.VISIBLE, View.GONE);
                    setRestDetailsAndShowGooglePath();
                } else if (is_accepted == AppConstants.REJECTED) {
                    if(isOrderRunning){

                        new MessageDialog(getActivity())
                                .setTitle(getString(R.string.alert_msg_title_orderCanceled))
                                .setMessage(getString(R.string.alert_msg_orderCanceled))
                                .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        session.setFlageFromKey(PreferenceKeys.KEY_ORDER_CANCEL_REQUEST_SENT, true);
                                        mBinder.tvHelpMe.setVisibility(View.GONE);
                                    }
                                })
                                .cancelable(false)
                                .show();
                    }else{
                        setVisibilityOrderNoOrder(View.GONE, View.VISIBLE);
                    }
                }
            }

            @Override
            public void apiFailed(int statusCode,ArrayList<String> messages) {
                stopProgress();
                errorHandleFromApi(getContext(), messages,statusCode);
            }
        });
    }

    private void drawRouteOnMap(final double srcLat, final double srcLng, final double destLat, final double destLng) {

        showProgress();

        String googleApiKey = getResources().getString(R.string.key_google_client);
        GoogleDistanceAPI googleDistanceAPI = new GoogleDistanceAPI();
        googleDistanceAPI.getDirectionDetails(srcLat, srcLng, destLat, destLng, googleApiKey, getActivity(), new GoogleDistanceAPI.GoogleDistance() {
            @Override
            public void onResult(String distance, String time, ArrayList<LatLng> route) {
                estDistanceFromAPI = distance;
                //setting arriving duration
                mBinder.tvDistance.setText(Utils.getMilesFromMeters(distance) + getResources().getString(R.string.msg_miles_small));
                //in Seconds
                etaFromAPI = Utils.getMinFromSec(time);
                stopProgress();
                if (route.size() > 0) {

                    PolylineOptions polylineOptions = new PolylineOptions();
                    polylineOptions.width(10.0f).color(ContextCompat.getColor(getActivity(), R.color.background_pending)).addAll(route);
                    Polyline polyLine = googleMap.addPolyline(polylineOptions);
                    polyLine.setPoints(route);
                    //Adding pick up pin
                    markerStartingPoint = addMarker(srcLat, srcLng, getString(R.string.msg_driver_position), R.drawable.ic_map_start);
                    //Adding destination pin
                    markerEndPoint = addMarker(destLat, destLng, getString(R.string.msg_driver_destination), R.drawable.ic_map_dest_gray);
                }
            }
        });
    }

    //adding marker
    private Marker addMarker(double latitude, double longitude, String title, int icon) {
        LatLng latLng = new LatLng(latitude, longitude);
        Marker marker = googleMap.addMarker(new MarkerOptions()
                .position(latLng)
                .title(title)
                .icon(BitmapDescriptorFactory.fromResource(icon)));

        return marker;

    }

    /*
        Brocast receiver for order cancel update
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(MessageEvent event) {

        new MessageDialog(getActivity())
                .setTitle(getResources().getString(R.string.alert_msg_title_orderCanceled))
                .setMessage(getResources().getString(R.string.alert_msg_body_orderCanceled))
                .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dashBoardAPI();
                        setVisibilityOrderNoOrder(View.GONE, View.VISIBLE);
                        googleMap.clear();
                    }
                })
                .cancelable(false)
                .show();
    }

    @Override
    public void onStop() {
        super.onStop();
        if (EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().unregister(this);
    }

    private void callOrderActivity(double drivLat, double drivLng, int orderID, int reqCode, boolean isComeFromOrderHistory, com.alnahla.model.order_detais.Order_details order_details, String notificationType){
        Intent intent = new Intent(getActivity(), OrderActivity.class);
        intent.putExtra(IntentConstants.DRIVER_LNG, drivLng);
        intent.putExtra(IntentConstants.DRIVER_LAT, drivLat);
        intent.putExtra(IntentConstants.ORDER_ID, orderID);
        intent.putExtra(IntentConstants.FROM_ORDERHISTORY, isComeFromOrderHistory);
        intent.putExtra(IntentConstants.NOTY_TYPE, notificationType);

        if (order_details != null)
            intent.putExtra(IntentConstants.ORDER_DETAILS, order_details);

        getActivity().startActivityForResult(intent, reqCode);
        getActivity().overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }
    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mBinder.map.onLowMemory();
    }

    @Override
    public void onResume() {
        super.onResume();
        mBinder.map.onResume();
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        mBinder.map.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mBinder.map != null)
            mBinder.map.onDestroy();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        mBinder.map.onSaveInstanceState(outState);
    }
}
