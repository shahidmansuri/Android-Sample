package com.alnahla.model.cms;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
/**
 * Awesome Pojo Generator
 * */
public class Data{
  @SerializedName("terms_and_conditions")
  @Expose
  private String terms_and_conditions;
  @SerializedName("about_us")
  @Expose
  private String about_us;
  @SerializedName("privacy_policy")
  @Expose
  private String privacy_policy;
  public void setTerms_and_conditions(String terms_and_conditions){
   this.terms_and_conditions=terms_and_conditions;
  }
  public String getTerms_and_conditions(){
   return terms_and_conditions;
  }
  public void setAbout_us(String about_us){
   this.about_us=about_us;
  }
  public String getAbout_us(){
   return about_us;
  }
  public void setPrivacy_policy(String privacy_policy){
   this.privacy_policy=privacy_policy;
  }
  public String getPrivacy_policy(){
   return privacy_policy;
  }
}