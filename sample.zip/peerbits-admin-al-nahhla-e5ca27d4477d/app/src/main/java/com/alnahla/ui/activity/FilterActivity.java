package com.alnahla.ui.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.RadioGroup;

import com.alnahla.AppConstants;
import com.alnahla.R;
import com.alnahla.databinding.ActivityFilterBinding;
import com.alnahla.ui.BaseActivity;


import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Locale;

public class FilterActivity extends BaseActivity implements View.OnClickListener{
    private ActivityFilterBinding mBinder;
    private android.app.DatePickerDialog DateStartPickerDialog, DateEndPickerDialog;
    private String order_status = "", payment_mode = "", start_date = "", end_date = "";
    private SimpleDateFormat dateFormatter;
    private Calendar newStartDate, newEndDate;
    private Typeface font;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinder = DataBindingUtil.setContentView(this, R.layout.activity_filter);
        setStatusBarColor(this,getResources().getColor(R.color.status_color_green));
        setUpUi();
    }

    private void setUpUi() {
        font = Typeface.createFromAsset(getAssets(), "fonts/" + getString(R.string.font_news));
        setDateTimeField();
        setEndDateTimeField();
        setUpToolBar(getResources().getString(R.string.filter));
        setOnClickListner();

        if (getIntent().getExtras() != null) {
            //set Filter
            start_date = getIntent().getStringExtra(AppConstants.STARTDATE);
            end_date = getIntent().getStringExtra(AppConstants.ENDDATE);
            order_status = getIntent().getStringExtra(AppConstants.ORDERFILTERSTATUS);
            payment_mode = getIntent().getStringExtra(AppConstants.PAYMENTMODE);
            setData(start_date, end_date, order_status, payment_mode);
        }

        mBinder.radioOrderStatus.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rbDelivered) {
                    order_status = "D";
                } else if (checkedId == R.id.rbCancelled) {
                    order_status = "C";
                }
            }
        });

        mBinder.radioPaymentMode.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rbCard) {
                    payment_mode = "O";
                } else if (checkedId == R.id.rbCash) {
                    payment_mode = "C";
                }
            }
        });
    }

    private void setData(String start_date, String end_date, String order_status, String payment_mode) {
        if (!start_date.isEmpty()) {
            mBinder.etStartDate.setText(setTimestampToDate(Long.parseLong(start_date)));
            mBinder.etEndDate.setText(setTimestampToDate(Long.parseLong(end_date)));
        }

        if (!order_status.isEmpty()) {
            if (order_status.equalsIgnoreCase("D")) {
                mBinder.rbDelivered.setChecked(true);
            } else if (order_status.equalsIgnoreCase("C")) {
                mBinder.rbCancelled.setChecked(true);
            }
        }

        if (!payment_mode.isEmpty()) {
            if (payment_mode.equalsIgnoreCase("O")) {
                mBinder.rbCard.setChecked(true);
            } else if (payment_mode.equalsIgnoreCase("C")) {
                mBinder.rbCash.setChecked(true);
            }
        }
    }

    private void setOnClickListner() {
        mBinder.etStartDate.setOnClickListener(this);
        mBinder.etEndDate.setOnClickListener(this);
        mBinder.btnApply.setOnClickListener(this);
    }

    /*method to set up toolbar*/
    private void setUpToolBar(String text) {
        setSupportActionBar(mBinder.toolbarLayout.toolbar);
        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            ab.setDisplayShowTitleEnabled(false);
            ab.setHomeAsUpIndicator(R.drawable.ic_left_arrow);
            ab.setDisplayHomeAsUpEnabled(true);
        }
        mBinder.toolbarLayout.toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        mBinder.toolbarLayout.title.setText(text);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.etStartDate:
                DateStartPickerDialog.show();
                mBinder.etEndDate.setText("");
                end_date = "";
                break;
            case R.id.etEndDate:
                DateEndPickerDialog.show();
                break;
            case R.id.btnApply:
                sendIntent();
                break;
        }
    }

    /**
     * method for setting date & time to select delivery date
     */
    private void setDateTimeField() {
        dateFormatter = new SimpleDateFormat("dd MMM, yyyy", Locale.getDefault());
        final Calendar newCalendar = Calendar.getInstance();
        DateStartPickerDialog = new android.app.DatePickerDialog(this, R.style.MyDatePickerDialogTheme, new android.app.DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                newStartDate = Calendar.getInstance();
                newStartDate.set(year, monthOfYear, dayOfMonth);
                mBinder.etStartDate.setText(dateFormatter.format(newStartDate.getTime()));
                start_date = String.valueOf(newStartDate.getTimeInMillis() / 1000);
                setEndDateTimeField();
                DateEndPickerDialog.getDatePicker().setMinDate(newStartDate.getTimeInMillis());

            }

        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        DateStartPickerDialog.setButton(DialogInterface.BUTTON_POSITIVE, getResources().getString(R.string.ok), DateStartPickerDialog);
        DateStartPickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE, getResources().getString(R.string.str_cancel), DateStartPickerDialog);
    }

    /**
     * method for setting date & time to select delivery date
     */
    private void setEndDateTimeField() {
        dateFormatter = new SimpleDateFormat("dd MMM, yyyy", Locale.US);
        final Calendar newCalendar = Calendar.getInstance();
        DateEndPickerDialog = new android.app.DatePickerDialog(this, R.style.MyDatePickerDialogTheme, new android.app.DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                newEndDate = Calendar.getInstance();
                newEndDate.set(year, monthOfYear, dayOfMonth);
                mBinder.etEndDate.setText(dateFormatter.format(newEndDate.getTime()));
                end_date = String.valueOf(newEndDate.getTimeInMillis() / 1000);

            }

        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        DateEndPickerDialog.setButton(DialogInterface.BUTTON_POSITIVE, getResources().getString(R.string.ok), DateEndPickerDialog);
        DateEndPickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE, getResources().getString(R.string.str_cancel), DateEndPickerDialog);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_filter, menu);//Menu Resource, Menu
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.actionClearAll:
                clearFilter();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public String setTimestampToDate(long dataByKey) {
        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
        cal.setTimeInMillis(dataByKey * 1000L);
        String date = DateFormat.format("dd MMM, yyyy", cal).toString();
        return date;
    }

    //Clear Filter Selection
    private void clearFilter() {
        mBinder.rbDelivered.setChecked(false);
        mBinder.rbCancelled.setChecked(false);
        mBinder.rbCard.setChecked(false);
        mBinder.rbCash.setChecked(false);
        mBinder.etStartDate.setText("");
        mBinder.etEndDate.setText("");
        order_status = "";
        payment_mode = "";
        start_date = "";
        end_date= "";
        sendIntent();
    }

    private void sendIntent() {
        Intent filterActivityIntent = new Intent();
        filterActivityIntent.putExtra(AppConstants.ORDERFILTERSTATUS, order_status);
        filterActivityIntent.putExtra(AppConstants.PAYMENTMODE, payment_mode);
        filterActivityIntent.putExtra(AppConstants.STARTDATE, start_date);
        filterActivityIntent.putExtra(AppConstants.ENDDATE, end_date);
        setResult(121, filterActivityIntent);
        finish();//finishing activity
    }
}
