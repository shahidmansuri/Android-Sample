package com.alnahla.utils;

/**
 * Created by ZEBRONICS-1 on 2/13/2018
 */

public class Constants {

    public static class ORDERSTATUS {
        public static int STATUS_PASS = 2;
        public static int STATUS_ACCEPT = 3;
        public static int STATUS_START = 4;
        public static int STATUS_PICKEDUP = 5;
        public static int STATUS_REFILLNG = 6;
        public static int STATUS_DELIVERED = 7;
    }

    public static class PRODUCTTYPE {
        public static String PRODUCTTYPE_COMPLETE = "C";
        public static String PRODUCTTYPE_OUTRIGHT = "O";
        public static String PRODUCTTYPE_RIFILLING = "R";
        public static String PRODUCTTYPE_EXCHANGE = "E";
    }

    //    Notification
    public static String NOTIFICATION_TYPE = "notification_type";
    public static String STATUS = "status";
    public static String ORDER_ID = "order_id";
    public static String TYPE = "type";
    public static String CANCELBYUSER = "cancel_by_user";
    public static String MESSAGE = "message";

    //Firebase Table
    public static final String LOCATION_MAIN_TABLE = "lpg_rider";

    //socket connection url
    public static final String SOCKET_URL = "http://35.156.121.8:3002/";
    public static final String SOCKET_JOIN = "join";
    public static final String SOCKET_UPDATE_LOC = "updateLocation";
    public static final String SOCKET_ID = "id";
    public static final String SOCKET_LAT = "latitude";
    public static final String SOCKET_LONG = "longitude";
    public static final String SOCKET_WEB_SOCKET = "websocket";

    public static final double DEFAULT_LAT = 23.8859;
    public static final double DEFAULT_LNG = 45.0792;
    public static final int DEFAULT_ORDER_ID = -1;

    public static final int DEFAULT_ORDER_STATUS = 2;
    public static final int ORDER_ACCEPT = 1;
    public static final int ORDER_CANCEL = 2;
    public static final int ORDER_SKIPPED = 4;
    public static final int ORDER_CANCEL_REJECTED = 3;

    public static final double dbMilesToMeters = 1609.34;
    public static final double dbMiliToMin = 60;

    //OrderActivity
    public static final float MAP_ZOOM_PREF = 6.0f;

    public static final String FILE_AUTORITY = "com.alnahla.fileprovider";
}
