package com.alnahla.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Awesome Pojo Generator
 */
public class OrderDetailUserInfo {
    @SerializedName("user_image")
    @Expose
    private String user_image;
    @SerializedName("user_name")
    @Expose
    private String user_name;
    @SerializedName("user_address")
    @Expose
    private String user_address;
    @SerializedName("latitude")
    @Expose
    private Double latitude;
    @SerializedName("mobile_number")
    @Expose
    private String mobile_number;
    @SerializedName("longitude")
    @Expose
    private Double longitude;

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }

    public String getUser_image() {
        return user_image;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_address(String user_address) {
        this.user_address = user_address;
    }

    public String getUser_address() {
        return user_address;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setMobile_number(String mobile_number) {
        this.mobile_number = mobile_number;
    }

    public String getMobile_number() {
        return mobile_number;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLongitude() {
        return longitude;
    }
}