package com.alnahla.model;

import com.google.android.gms.maps.model.LatLng;

import java.io.Serializable;
import java.util.ArrayList;

public class GoogleMapModel implements Serializable {
    private transient com.google.android.gms.maps.model.LatLng mLocation;
    private ArrayList<LatLng> mapRoute;
    private String strDistance;
    private String strTiming;

    public ArrayList<LatLng> getMapRoute() {
        return mapRoute;
    }

    public void setMapRoute(ArrayList<LatLng> mapRoute) {
        this.mapRoute = mapRoute;
    }

    public String getStrDistance() {
        return strDistance;
    }

    public void setStrDistance(String strDistance) {
        this.strDistance = strDistance;
    }

    public String getStrTiming() {
        return strTiming;
    }

    public void setStrTiming(String strTiming) {
        this.strTiming = strTiming;
    }
}
