package com.alnahla.model.newtoken;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
/**
 * Awesome Pojo Generator
 * */
public class Data{
  @SerializedName("auth")
  @Expose
  private Auth auth;
  public void setAuth(Auth auth){
   this.auth=auth;
  }
  public Auth getAuth(){
   return auth;
  }
}