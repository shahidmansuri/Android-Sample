package com.alnahla.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

import com.alnahla.AppConstants;
import com.alnahla.R;
import com.alnahla.databinding.ActivityPasswordBinding;
import com.alnahla.model.newtoken.Data;
import com.alnahla.network.API_CONSTANTS;
import com.alnahla.network.API_EndPoints;
import com.alnahla.network.NetworkCall;
import com.alnahla.network.listeners.RetrofitResponseListener;
import com.alnahla.ui.BaseActivity;
import com.alnahla.utils.pref.PreferenceKeys;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class PasswordActivity extends BaseActivity implements View.OnClickListener {

    private ActivityPasswordBinding mBinder;
    String phoneNumber = "";
    String dialCode = "";

    public static void launch(Activity activity, boolean isFinishActivity, String phoneNumber, String dialCode) {
//    public static void launch(Activity activity, boolean isFinishActivity, String phoneNumber) {
        if (isFinishActivity) {
            Intent intent = new Intent(activity, PasswordActivity.class);
            intent.putExtra(AppConstants.PHONENUMBER, phoneNumber);
            intent.putExtra(AppConstants.DIALCODE, dialCode);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        } else {
            Intent intent = new Intent(activity, PasswordActivity.class);
            intent.putExtra(AppConstants.PHONENUMBER, phoneNumber);
            intent.putExtra(AppConstants.DIALCODE, dialCode);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinder = DataBindingUtil.setContentView(this, R.layout.activity_password);
        setStatusBarColor(this, getResources().getColor(R.color.status_color_gray));
        getIntentData();
        setOnClickListner();
        setUpToolBar();
        getTokenApi();
    }

    private void getIntentData() {
        phoneNumber = getIntent().getStringExtra(AppConstants.PHONENUMBER);
        dialCode = getIntent().getStringExtra(AppConstants.DIALCODE);
    }

    private void setUpToolBar() {
        mBinder.included.whiteToolbar.setNavigationIcon(R.drawable.ic_back_arrow_green);
        mBinder.included.whiteToolbar.setNavigationOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void setOnClickListner() {
        mBinder.btnDone.setOnClickListener(this);
        mBinder.tvForgotPassword.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnDone:
                validation();
                break;
            case R.id.tvForgotPassword:
                ForgetPasswordActivity.launch(this, false, phoneNumber, dialCode);
                break;
        }
    }

    private void validation() {
        String password = mBinder.etPassword.getText().toString().trim();
        if (password.length() == 0) {
            showSnackBar(getString(R.string.v_password));
            mBinder.etPassword.requestFocus();
        } else if (password.length() < 6) {
            showSnackBar(getString(R.string.v_password_6_to_15));
            mBinder.etPassword.requestFocus();
        } else if (password.length() > 15) {
            showSnackBar(getString(R.string.v_password_6_to_15));
            mBinder.etPassword.requestFocus();
        } else {
            signInApi(dialCode, phoneNumber, password);
        }
    }

    private void getTokenApi() {
        HashMap<String, String> params = new HashMap<>();
        String deviceId = FirebaseInstanceId.getInstance().getToken();
        params.put(API_CONSTANTS.DEVICE_ID, deviceId);
        params.put(API_CONSTANTS.DEVICE_TYPE, AppConstants.DEVICE_TYPE);

        NetworkCall.with(PasswordActivity.this)
                .setEndPoint(API_EndPoints.GET_TOKEN)
                .setRequestParams(params)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        GsonBuilder gsonBuilder = new GsonBuilder();
                        Gson gson = gsonBuilder.create();
                        Data tokenModel = gson.fromJson(jsonObject.toString(), Data.class);
                        session.setNewToken(tokenModel.getAuth());
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        errorHandleFromApi(messages,statusCode);
                    }
                }).makeCall();
    }

    private void signInApi(String dialCode, final String phoneNumber, String password) {
        HashMap<String, String> params = new HashMap<>();
        String deviceId = FirebaseInstanceId.getInstance().getToken();
        params.put(AppConstants.DIALCODE, dialCode);
        params.put(AppConstants.PHONENUMBER, phoneNumber);
        params.put(API_CONSTANTS.DEVICE_TYPE, "A");
        params.put(AppConstants.PASSWORD, password);
        params.put(API_CONSTANTS.DEVICE_ID, deviceId);

        NetworkCall.with(this)
                .setEndPoint(API_EndPoints.SIGN_IN)
                .setRequestParams(params)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                        showProgress(getString(R.string.txt_pls_wait));
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        stopProgress();

                        GsonBuilder gsonBuilder = new GsonBuilder();
                        Gson gson = gsonBuilder.create();

                        final com.alnahla.model.newlogin.Data loginData = gson.fromJson(jsonObject.toString(), com.alnahla.model.newlogin.Data.class);
                        if (loginData.getAdmin_contact_number() != null)
                            session.setValueFromKey(PreferenceKeys.KEY_ADMIN_CONTACT, loginData.getAdmin_contact_number());

                        session.setValueFromKey(PreferenceKeys.KEY_USER_ID, String.valueOf(loginData.getUser_info().getId()));
                        session.setValueFromKey(PreferenceKeys.KEY_USER, gson.toJson(loginData.getUser_info()));
                        session.setFlageFromKey(PreferenceKeys.KEY_LOGIN, true);
//                        session.setValueFromKey(PreferenceKeys.KEY_FULL_NAME, loginData.getUser_info().getFull_name());
//                        session.setValueFromKey(PreferenceKeys.KEY_IMAGE, loginData.getUser_info().getImage());

                        MainActivity.launch(PasswordActivity.this, true);
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        errorHandleFromApi(messages,statusCode);
                        stopProgress();
                    }

                }).makeCall();
    }
}