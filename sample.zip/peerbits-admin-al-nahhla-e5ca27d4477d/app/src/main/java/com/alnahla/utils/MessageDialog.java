package com.alnahla.utils;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;

import com.alnahla.R;
import com.alnahla.databinding.AlertDialogMessageBinding;


public class MessageDialog extends AlertDialog implements View.OnClickListener {
    private boolean cancelable = false;
    private String title, message;
    private String positiveButtonText, negativeButtonText;

    private OnClickListener onPositiveButtonClick;
    private OnClickListener onNegativeButtonClick;

    public MessageDialog(Context context) {
        super(context, R.style.DialogWithAnimation);
    }

    public MessageDialog setTitle(String title) {
        this.title = title;
        return this;
    }

    public MessageDialog setMessage(String message) {
        this.message = message;
        return this;
    }

    public MessageDialog cancelable(boolean cancelable) {
        this.cancelable = cancelable;
        return this;
    }

    public MessageDialog setPositiveButton(String text, OnClickListener listener) {
        this.positiveButtonText = text;
        this.onPositiveButtonClick = listener;
        return this;
    }

    public MessageDialog setNegativeButton(String text, OnClickListener listener) {
        this.negativeButtonText = text;
        this.onNegativeButtonClick = listener;
        return this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AlertDialogMessageBinding mBinder = DataBindingUtil.inflate(LayoutInflater.from(getContext()),
                R.layout.alert_dialog_message, null, false);
        setContentView(mBinder.getRoot());
        setCanceledOnTouchOutside(cancelable);
        setCancelable(cancelable);

        mBinder.tvTitle.setVisibility(title != null ? View.VISIBLE : View.GONE);
        if (title != null) mBinder.tvTitle.setText(title);

        mBinder.tvMessageText.setVisibility(message != null ? View.VISIBLE : View.GONE);
        if (message != null) mBinder.tvMessageText.setText(message);

        if (positiveButtonText != null) mBinder.tvPositiveButton.setText(positiveButtonText);
        if (negativeButtonText != null) mBinder.tvNegativeButton.setText(negativeButtonText);
        mBinder.tvPositiveButton.setVisibility(onPositiveButtonClick != null ? View.VISIBLE : View.GONE);
        mBinder.tvNegativeButton.setVisibility(negativeButtonText != null ? View.VISIBLE : View.GONE);
        mBinder.tvPositiveButton.setOnClickListener(this);
        mBinder.tvNegativeButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvPositiveButton:
                if (onPositiveButtonClick != null)
                    onPositiveButtonClick.onClick(MessageDialog.this, 0);
                break;
            case R.id.tvNegativeButton:
                if (onNegativeButtonClick != null)
                    onNegativeButtonClick.onClick(MessageDialog.this, 0);
                break;
        }
    }
}