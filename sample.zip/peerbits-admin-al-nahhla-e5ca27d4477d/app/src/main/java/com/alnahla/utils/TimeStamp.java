package com.alnahla.utils;

import android.text.format.DateFormat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public class TimeStamp {
    private static final String FULL_DATE_FORMAT = "dd MMM yyyy, hh:mm:ss a";
    private static final String DATE_FORMAT = "dd-MM-yyyy";
    private static final String TIME_FORMAT = "hh:mm:ss a";

    public static long formatToSeconds(String value, String format) {
        TimeZone timeZone = TimeZone.getDefault();
        return formatToSeconds(value, format, timeZone);
    }

    public static long formatToSeconds(String value, String format, TimeZone timeZone) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.ENGLISH);
            sdf.setTimeZone(timeZone);
            Date mDate = sdf.parse(value);
            return TimeUnit.MILLISECONDS.toSeconds(mDate.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public static String millisToFormat(Long millis) {
        TimeZone timeZone = TimeZone.getDefault();
        return millisToFormat(millis, FULL_DATE_FORMAT, timeZone);
    }

    public static String millisToFormat(String millis) {
        TimeZone timeZone = TimeZone.getDefault();
        return millisToFormat(Long.parseLong(millis), FULL_DATE_FORMAT, timeZone);
    }

    public static String millisToFormat(long millis, String format) {
        TimeZone timeZone = TimeZone.getDefault();
        return millisToFormat(millis, format, timeZone);
    }

    public static String millisToFormat(String millis, String format) {
        TimeZone timeZone = TimeZone.getDefault();
        return millisToFormat(Long.parseLong(millis), format, timeZone);
    }

    public static String millisToFormat(long millis, String format, TimeZone tz) {
        if (millis < 1000000000000L) {
            millis *= 1000;
        }
        Calendar cal = Calendar.getInstance(tz);
        cal.setTimeInMillis(millis);
        SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.ENGLISH);
        sdf.setTimeZone(tz);
        return sdf.format(cal.getTime());
    }

    public static String getYTT(long millis) {
        if (millis < 1000000000000L) {
            millis *= 1000;
        }
        Calendar givenTime = Calendar.getInstance();
        givenTime.setTimeInMillis(millis);

        Calendar now = Calendar.getInstance();
        Calendar yesterday = Calendar.getInstance();
        yesterday.add(Calendar.DATE, -1);
        Calendar tomorrow = Calendar.getInstance();
        tomorrow.add(Calendar.DATE, +1);

        if (givenTime.getTime().equals(now.getTime())) {
            return "Today";
        } else if (givenTime.getTime().equals(yesterday.getTime())) {
            return "Yesterday";
        } else if (givenTime.getTime().equals(tomorrow.getTime())) {
            return "Tomorrow";
        } else {
            String date = DateFormat.format("EEE dd, MMM yyyy", givenTime).toString();
            return String.format("%s", date);
        }
    }

    public static String getTimeAgo(long time) {
        if (time < 1000000000000L) {
            time *= 1000;
        }
        int SECOND_MILLIS = 1000;
        int MINUTE_MILLIS = 60 * SECOND_MILLIS;
        int HOUR_MILLIS = 60 * MINUTE_MILLIS;
        int DAY_MILLIS = 24 * HOUR_MILLIS;

        Calendar cal = Calendar.getInstance();

        long now = cal.getTimeInMillis();
        if (time > now || time <= 0) {
            return "in the future";
        }

        final long diff = now - time;
        if (diff < MINUTE_MILLIS) {
            return "Moments ago";
        } else if (diff < 2 * MINUTE_MILLIS) {
            return "A minute ago";
        } else if (diff < 50 * MINUTE_MILLIS) {
            return diff / MINUTE_MILLIS + " minutes ago";
        } else if (diff < 90 * MINUTE_MILLIS) {
            return "An hour ago";
        } else if (diff < 24 * HOUR_MILLIS) {
            return diff / HOUR_MILLIS + " hours ago";
        } else if (diff < 48 * HOUR_MILLIS) {
            return "Yesterday";
        } else {
            return diff / DAY_MILLIS + " days ago";
        }
    }
}
