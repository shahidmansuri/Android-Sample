package com.alnahla.ui.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.view.View;

import com.alnahla.AppConstants;
import com.alnahla.AppStrings;
import com.alnahla.R;
import com.alnahla.databinding.ActivityOrderCancelBinding;
import com.alnahla.model.OrderCancelData;
import com.alnahla.model.Reason;
import com.alnahla.network.API_CONSTANTS;
import com.alnahla.network.API_EndPoints;
import com.alnahla.network.NetworkCall;
import com.alnahla.network.listeners.RetrofitResponseListener;
import com.alnahla.ui.BaseActivity;
import com.alnahla.ui.adapter.OrderCancelReasonAdapter;
import com.alnahla.utils.Constants;
import com.alnahla.utils.SimpleDividerItemDecoration;
import com.alnahla.utils.pref.IntentConstants;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class OrderCancelActivity extends BaseActivity implements View.OnClickListener {

    ActivityOrderCancelBinding mBinding;
    ArrayList<Reason> reasonArrayList = new ArrayList<>();
    OrderCancelReasonAdapter orderCancelReasonAdapter;

    private int start = 1;
    private final int LIMIT = 10;
    private int reasonID;
    private String otherComments;

    public static void launch(Activity activity, boolean isFinishActivity, int reqCode) {
        Intent intent = new Intent(activity, OrderCancelActivity.class);
        if (isFinishActivity) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        }
        activity.startActivityForResult(intent, reqCode);
        activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_cancel);

        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_order_cancel);

        this.setFinishOnTouchOutside(false);

        init();
        setListeners();
        setupRecyclerView();
        apiOrderCancelReason();
    }

    private void init() {
        start = 1;
        reasonID = AppConstants.NO_VALUE_SET;
        otherComments = AppConstants.NO_VALUE_SET_STRING;

    }

    private void setListeners() {

        mBinding.tvCancel.setOnClickListener(this);
        mBinding.tvSubmit.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.tvCancel:
                sendFeedback(Constants.ORDER_CANCEL_REJECTED);
                break;

            case R.id.tvSubmit:
                if(reasonID == AppConstants.NO_VALUE_SET){
                    showSnackBar(getResources().getString(R.string.err_enterReason));
                }else{
                    if(reasonID == API_CONSTANTS.REASON_ID_OTHERS){
                        otherComments = mBinding.etOtherComments.getText().toString();
                        if(otherComments.equals("")){
                            showSnackBar(getResources().getString(R.string.err_enterReason));
                        }else{
                            sendFeedback(Constants.ORDER_CANCEL);
                        }
                    }else{
                        sendFeedback(Constants.ORDER_CANCEL);
                    }
                }
                break;
        }
    }

    private void setupRecyclerView() {

        mBinding.rvOrderCancel.setLayoutManager(new LinearLayoutManager(this));
        mBinding.rvOrderCancel.addItemDecoration(new SimpleDividerItemDecoration(this));
        orderCancelReasonAdapter = new OrderCancelReasonAdapter(OrderCancelActivity.this, reasonArrayList, mBinding.rvOrderCancel);
        mBinding.rvOrderCancel.setAdapter(orderCancelReasonAdapter);
    }

    private void apiOrderCancelReason() {

        HashMap<String, String> params = new HashMap<>();
        params.put(API_CONSTANTS.IS_FOR_REQ, String.valueOf(start));
        params.put(API_CONSTANTS.LIMIT, String.valueOf(LIMIT));

        NetworkCall.with(this)
                .setRequestParams(params)
                .setEndPoint(API_EndPoints.REASON_LIST)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute()  {
                        showProgress();
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        stopProgress();
                        OrderCancelData data = new Gson().fromJson(jsonObject.toString(), OrderCancelData.class);

                        /*
                            Create reason object for "Others" field
                         */
                        Reason reasonOthers = new Reason();
                        reasonOthers.setReason(AppStrings.REASON_OTHERS);
                        reasonOthers.setReason_id(API_CONSTANTS.REASON_ID_OTHERS);
                        ArrayList<Reason> reasons = (ArrayList<Reason>) data.getReason();
                        if(reasons==null){
                            reasons = new ArrayList<>();
                        }
                        reasons.add(reasons.size(),reasonOthers);
                        reasonArrayList.addAll(reasons);
                        orderCancelReasonAdapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        stopProgress();
                        errorHandleFromApi(messages,statusCode);
                    }
                })
                .makeCall();
    }

    private void sendFeedback(int reqStatus){

        Intent resultIntent = new Intent();

        resultIntent.putExtra(IntentConstants.REQUEST_STATUS, reqStatus);
        resultIntent.putExtra(IntentConstants.OTHERS_COMMENT, otherComments);
        resultIntent.putExtra(IntentConstants.REASON_ID, reasonID);

        setResult(Activity.RESULT_OK, resultIntent);
        finish();
    }
    public void selectedReason(int reasonID){
        this.reasonID = reasonID;
    }
}
