package com.alnahla.ui.adapter;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.alnahla.AppConstants;
import com.alnahla.R;
import com.alnahla.databinding.RawNotificationListBinding;
import com.alnahla.model.Notification_details;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class NotificationListAdapter extends RecyclerView.Adapter<NotificationListAdapter.MyViewHolder> {
    private List<Notification_details> notificationList;
    private Context mContext;

    /*public NotificationListAdapter(Activity context, List<NotificationList> notificationList) {

        this.notificationList = notificationList;
        this.mContext = context;
    }*/

    public NotificationListAdapter(Context mContext, List<Notification_details> notificationLists) {
        this.notificationList = notificationLists;
        this.mContext = mContext;
    }

   /* public void clearList() {
        this.notificationList.clear();
        this.notifyDataSetChanged();
    }*/

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        RawNotificationListBinding binding = DataBindingUtil.inflate(layoutInflater, R.layout.raw_notification_list, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
   /*     if (notificationList.get(position).getType().equalsIgnoreCase("cancel_status_rider")){

            holder.binding.tvNotification.setVisibility(View.GONE);
            holder.binding.tvNotificationBold.setVisibility(View.VISIBLE);
        }else if (notificationList.get(position).getType().equalsIgnoreCase("cancel_status_user")){

            holder.binding.tvNotification.setVisibility(View.GONE);
            holder.binding.tvNotificationBold.setVisibility(View.VISIBLE);
        }else{
            holder.binding.tvNotification.setVisibility(View.VISIBLE);
            holder.binding.tvNotificationBold.setVisibility(View.GONE);
        }*/


        Notification_details notification_details = notificationList.get(position);

        holder.binding.tvNotification.setText(notification_details.getNotification_details());
        //holder.binding.tvDateAndTime.setText(Utils.getDateFromLong(Long.parseLong(String.valueOf(notification_details.getNotification_date_time()))));
        if(!notificationList.get(position).getNotification_date_time().equalsIgnoreCase(AppConstants.NO_VALUE_SET_STRING)){
            holder.binding.tvDateAndTime.setText(timestampToDate(Long.parseLong(notificationList.get(position).getNotification_date_time())));
        }
    }

    public String timestampToDate(Long dataByKey) {
        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
        cal.setTimeInMillis(dataByKey * 1000L);
        String date = DateFormat.format("MMM dd, yyyy", cal).toString() + " at " + DateFormat.format("hh:mm a ", cal).toString();
        return date;
    }

    public void setDataList(ArrayList<Notification_details> dataList) {
        this.notificationList = dataList;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return notificationList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        final RawNotificationListBinding binding;

        MyViewHolder(RawNotificationListBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
