package com.alnahla.utils;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import static com.alnahla.utils.Utils.isValidMobileNumber;

/**
 * Created by RAJESH
 */

public class SSNFormatter implements TextWatcher {
    private EditText mEditText;
    private boolean mShouldDeleteSpace;
    private Context mContext;

    public SSNFormatter(EditText editText) {
        mEditText = editText;
    }

    public SSNFormatter(EditText editText, Context mContext) {
        mEditText = editText;
        this.mContext = mContext;
    }

    public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

    }

    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        if (start > 0) {
            CharSequence charDeleted = s.subSequence(start - 1, start);
            mShouldDeleteSpace = " ".equals(charDeleted.toString());
        }
    }

    public void afterTextChanged(Editable editable) {
        mEditText.removeTextChangedListener(this);

        int cursorPosition = mEditText.getSelectionStart();
        String withSpaces = formatText(editable);
        mEditText.setText(withSpaces);

        mEditText.setSelection(cursorPosition + (withSpaces.length() - editable.length()));

        if (mShouldDeleteSpace) {
            mShouldDeleteSpace = false;
        }


        if (!isValidMobileNumber(editable.toString())) {
            mEditText.setText("");
           // Toast.makeText(mContext, "Mobile number should be 10 digit long without leading zero, e.g. 777 777 7777", Toast.LENGTH_SHORT).show();
        }


        mEditText.addTextChangedListener(this);
    }

    private String formatText(CharSequence text) {
        StringBuilder formatted = new StringBuilder();
        if (text.length() == 2 || text.length() == 6) {
            if (!mShouldDeleteSpace) {
                formatted.append(text.subSequence(0, text.length() - 1) + " " + text.charAt(text.length() - 1));
            } else {
                formatted.append(text.subSequence(0, text.length() - 1));
            }
        } else {
            formatted.append(text);
        }
        return formatted.toString();
    }
}