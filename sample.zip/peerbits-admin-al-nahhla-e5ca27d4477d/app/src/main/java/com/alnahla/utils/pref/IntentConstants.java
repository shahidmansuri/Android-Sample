package com.alnahla.utils.pref;

public class IntentConstants {

    public static final String DRIVER_LAT = "driverLat";
    public static final String DRIVER_LNG = "driverLng";
    public static final String ORDER_ID = "orderID";
    public static final String MAP_MODEL = "mapModel";
    public static final String REQUEST_STATUS = "reqStatus";
    public static final String ORDER_DETAILS = "orderDetails";
    public static final String REASON_ID = "reasonID";
    public static final String OTHERS_COMMENT = "others";
    public static final String ORDER_COMPLETED = "orderCompleted";
    public static final String GEO_FENCING_REQID = "orderCompleted";
    public static final String ETA = "eta";
    public static final String NOTY_TYPE = "notiType";
    public static final String NOTY_MSG = "notiMsg";
    public static final String FROM_ORDERHISTORY = "orderHistory";
}
