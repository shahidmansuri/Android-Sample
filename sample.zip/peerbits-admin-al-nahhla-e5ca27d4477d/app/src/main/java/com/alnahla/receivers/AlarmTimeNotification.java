package com.alnahla.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmTimeNotification extends BroadcastReceiver {

    //the method will be fired when the alarm is triggerred

    public AlarmTimeNotification(){
        super();
    }
    @Override
    public void onReceive(Context context, Intent intent) {

        //you can check the log that it is fired
        //Here we are actually not doing anything
        //but you can do any task here that you want to be done at a specific time everyday

        // Calculating distance to check if the user got late or not
//            GoogleDistanceAPI googleDistanceAPI = new GoogleDistanceAPI();
//            googleDistanceAPI.getDirectionDetails(dbDriverLat, dbDriverLng, dbRestLat, dbRestLng, getString(R.string.key_google_client), getApplicationContext(), new GoogleDistanceAPI.GoogleDistance() {
//                @Override
//                public void onDistanceFetch(String distance) {
//                    if (!distance.equals("")) {
//                        long distanceLong = Long.parseLong(distance);
//                        // check if driver reached max required distance
//                        if (distanceLong <= AppConstants.DEFAULT_DIS_METERS) {
//                            // do some processing
//                        } else {
//                            markerEndPoint.setIcon(BitmapDescriptorFactory.fromResource(R.drawable.ic_red_flag));
////                            MarkerOptions markerOptions;
////                            addMarker(dbRestLat,dbRestLng,getString(R.string.msg_late),R.drawable.ic_red_flag);
//                        }
//                    }
//                }
//
//                @Override
//                public void onTimingFetch(String time) {
//
//                }
//
//                @Override
//                public void getRoutes(ArrayList<LatLng> route) {
//
//                }
//            });
    }

}