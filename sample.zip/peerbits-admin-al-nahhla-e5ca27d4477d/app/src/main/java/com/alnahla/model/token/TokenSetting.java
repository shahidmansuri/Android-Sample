package com.alnahla.model.token;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Awesome Pojo Generator
 * */
public class TokenSetting{
  @SerializedName("data")
  @Expose
  private Data data;
  @SerializedName("success")
  @Expose
  private Integer success;
  @SerializedName("error")
  @Expose
  private List<Error> error;
  public void setData(Data data){
   this.data=data;
  }
  public Data getData(){
   return data;
  }
  public void setSuccess(Integer success){
   this.success=success;
  }
  public Integer getSuccess(){
   return success;
  }
  public void setError(List<Error> error){
   this.error=error;
  }
  public List<Error> getError(){
   return error;
  }
}