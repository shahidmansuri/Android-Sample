package com.alnahla.network.responsemodel;

import java.util.ArrayList;

/**
 * Created by ZEBRONICS-1 on 2/14/2018
 */

public class ResponseClass<T> {
    private int success;
    private T data;
    private ArrayList<Object> error;

    public ResponseClass() {
    }

    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public ArrayList<Object> getError() {
        return error;
    }

    public void setError(ArrayList<Object> error) {
        this.error = error;
    }
}
