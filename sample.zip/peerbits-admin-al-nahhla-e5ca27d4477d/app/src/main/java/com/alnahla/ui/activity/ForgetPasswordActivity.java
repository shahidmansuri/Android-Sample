package com.alnahla.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

import com.alnahla.AppConstants;
import com.alnahla.R;
import com.alnahla.databinding.ActivityForgetPasswordBinding;
import com.alnahla.network.API_CONSTANTS;
import com.alnahla.network.API_EndPoints;
import com.alnahla.network.NetworkCall;
import com.alnahla.network.listeners.RetrofitResponseListener;
import com.alnahla.ui.BaseActivity;
import com.alnahla.utils.SSNFormatter;
import com.alnahla.utils.Validations;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class ForgetPasswordActivity extends BaseActivity implements View.OnClickListener {
    ActivityForgetPasswordBinding mBinding;

    public static void launch(Activity activity, boolean isFinishActivity, String phoneNumber, String dialCode) {
        if (isFinishActivity) {
            Intent intent = new Intent(activity, ForgetPasswordActivity.class);
            intent.putExtra(AppConstants.PHONENUMBER, phoneNumber);
            intent.putExtra(AppConstants.DIALCODE, dialCode);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        } else {
            Intent intent = new Intent(activity, ForgetPasswordActivity.class);
            intent.putExtra(AppConstants.PHONENUMBER, phoneNumber);
            intent.putExtra(AppConstants.DIALCODE, dialCode);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_forget_password);
        setStatusBarColor(this, getResources().getColor(R.color.status_color_gray));
        setUpToolBar();
        setOnClickListner();
        setUpUi();
    }

    private void setUpUi() {
        String phoneNumber = getIntent().getStringExtra(AppConstants.PHONENUMBER);
        setFormatedSSN(phoneNumber);
    }

    private void setFormatedSSN(String phoneNumber) {
        String formatedString = "";
        for (int i = 0; i < phoneNumber.length(); i++) {
            formatedString = formatedString + phoneNumber.charAt(i);
            if (i == 0) {
                formatedString = formatedString + " ";
            } else if (i == 4) {
                formatedString = formatedString + " ";
            }
        }

        mBinding.etForgetPassword.setText(formatedString);
        mBinding.etForgetPassword.setSelection(mBinding.etForgetPassword.getText().length());
    }

    private void setOnClickListner() {
        mBinding.etForgetPassword.addTextChangedListener(new SSNFormatter(mBinding.etForgetPassword, this));
        mBinding.btnGetOtp.setOnClickListener(this);
    }

    private void setUpToolBar() {
        mBinding.included.whiteToolbar.setNavigationIcon(R.drawable.ic_back_arrow_green);
        mBinding.included.whiteToolbar.setNavigationOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnGetOtp:
                if (isValid()) {
                    String dialCode = mBinding.tvDialCode.getText().toString();
                    String phoneNumber = mBinding.etForgetPassword.getText().toString().trim().replace(" ", "");
                    forgotPasswordApi(dialCode, phoneNumber);
                }
        }
    }

    private void forgotPasswordApi(final String dialCode, final String phoneNumber) {
        HashMap<String, String> params = new HashMap<>();
        params.put(API_CONSTANTS.DIAL_CODE, dialCode);
        params.put(API_CONSTANTS.PHONE_NO, phoneNumber);

        NetworkCall.with(this)
                .setEndPoint(API_EndPoints.FORGOTPASSWORD)
                .setRequestParams(params)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                        showProgress(getResources().getString(R.string.txt_pls_wait));
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        stopProgress();
                        showToastLong(jsonObject.optString(API_CONSTANTS.MESSAGE));
                        OtpActivity.launch(ForgetPasswordActivity.this, false, dialCode, phoneNumber);
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        stopProgress();
                        errorHandleFromApi(messages,statusCode);
                    }
                }).makeCall();
    }


    private boolean isValid() {
        String phoneNumber = mBinding.etForgetPassword.getText().toString().trim().replace(" ", "");
        boolean isValid = false;
        if (Validations.isEditTextEmpty(mBinding.etForgetPassword)) {
            showSnackBar(getString(R.string.v_phone_number));
            mBinding.etForgetPassword.requestFocus();
        } else if (phoneNumber.length() != AppConstants.MOBILE_REQ_LENGTH) {
            showSnackBar(getString(R.string.v_phone_number_9digit));
            mBinding.etForgetPassword.requestFocus();
        } else {
            isValid = true;
        }
        return isValid;
    }
}
