package com.alnahla.utils;

/**
 * Created by Pooja Goswami on 5/10/2018.
 */
public enum Filter {
    C("Cancelled"),
    D("Delivered"),
    Cr("Card"),
    Cs("Cash");

    private final String text;

    /**
     * @param text
     */
    Filter(final String text) {
        this.text = text;
    }

    /* (non-Javadoc)
     * @see java.lang.Enum#toString()
     */
    @Override
    public String toString() {
        return text;
    }
}