package com.alnahla.eventbus;

public class MessageEvent {
    /* Additional fields if needed */

    public boolean isOrderCancelled = false;
    public String message = "";
    public String type = "";


    public MessageEvent(String type,String message) {
        this.type = type;
        this.message = message;
    }
}