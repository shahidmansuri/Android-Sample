package com.alnahla.network.models;

import java.util.ArrayList;

public class ModelRFIDs {

    private String timestamp;
    private ArrayList<ModelRFID> rfids;

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public ArrayList<ModelRFID> getRfids() {
        return rfids;
    }

    public void setRfids(ArrayList<ModelRFID> rfids) {
        this.rfids = rfids;
    }
}
