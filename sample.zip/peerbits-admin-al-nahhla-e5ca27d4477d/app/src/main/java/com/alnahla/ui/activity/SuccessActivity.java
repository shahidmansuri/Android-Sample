package com.alnahla.ui.activity;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

import com.alnahla.R;
import com.alnahla.databinding.ActivitySuccessBinding;
import com.alnahla.ui.BaseActivity;

public class SuccessActivity extends BaseActivity implements OnClickListener {

    ActivitySuccessBinding mBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_success);
        setStatusBarColor(this,getResources().getColor(R.color.status_color_gray));
        setOnClickListner();
    }

    private void setOnClickListner() {
        mBinding.btnLetsStart.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnLetsStart:
                Intent intent = new Intent(this, SignInActivity.class);
                startActivity(intent);
        }

    }
}
