package com.alnahla.network.listeners;


public interface NoInternetListner {
    void onNoInternet();
}
