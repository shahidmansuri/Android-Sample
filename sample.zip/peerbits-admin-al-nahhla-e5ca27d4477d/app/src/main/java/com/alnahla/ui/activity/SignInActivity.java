package com.alnahla.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Selection;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;

import com.alnahla.AppConstants;
import com.alnahla.R;
import com.alnahla.databinding.ActivityNewSignInBinding;
import com.alnahla.ui.BaseActivity;
import com.alnahla.utils.SSNFormatter;
import com.alnahla.utils.Validations;

public class SignInActivity extends BaseActivity implements OnClickListener {
    ActivityNewSignInBinding signInBinding;

    public static void launch(Activity activity, boolean isFinishActivity) {
        if (isFinishActivity) {
            Intent intent = new Intent(activity, SignInActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        } else {
            Intent intent = new Intent(activity, SignInActivity.class);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        signInBinding = DataBindingUtil.setContentView(this, R.layout.activity_new_sign_in);
        init();
    }

    private void init() {

        setStatusBarColor(this, getResources().getColor(R.color.status_color_gray));
        setUpToolBar();
        setListeners();
    }

    private void getEdittextPrefix() {

        final String prefix = AppConstants.DIALCODE_VALUE;
        signInBinding.etPhoneNumber.setText(prefix);

        signInBinding.etPhoneNumber.setFilters(new InputFilter[]{
                new InputFilter() {
                    @Override
                    public CharSequence filter(final CharSequence source, final int start,
                                               final int end, final Spanned dest, final int dstart, final int dend) {
                        final int newStart = Math.max(prefix.length(), dstart);
                        final int newEnd = Math.max(prefix.length(), dend);
                        if (newStart != dstart || newEnd != dend) {
                            final SpannableStringBuilder builder = new SpannableStringBuilder(dest);
                            builder.replace(newStart, newEnd, source);
                            if (source instanceof Spanned) {
                                TextUtils.copySpansFrom(
                                        (Spanned) source, 0, source.length(), null, builder, newStart);
                            }
                            Selection.setSelection(builder, newStart + source.length());
                            return builder;
                        } else {
                            return null;
                        }
                    }
                }
        });
    }

    private void setUpToolBar() {
        signInBinding.included.whiteToolbar.setNavigationIcon(R.drawable.ic_back_arrow_green);
        signInBinding.included.whiteToolbar.setNavigationOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void setListeners() {
        signInBinding.etPhoneNumber.addTextChangedListener(new SSNFormatter(signInBinding.etPhoneNumber, this));
        signInBinding.btnNext.setOnClickListener(this);
        signInBinding.etPhoneNumber.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    signInBinding.tvWelcome.setVisibility(View.VISIBLE);
                    signInBinding.tvDialCode.setVisibility(View.VISIBLE);
                    signInBinding.etPhoneNumber.setHint("");
                } else if (!hasFocus && signInBinding.etPhoneNumber.getText().equals("")) {
                    signInBinding.tvWelcome.setVisibility(View.INVISIBLE);
                    signInBinding.tvDialCode.setVisibility(View.GONE);
                    signInBinding.etPhoneNumber.setHint(getResources().getString(R.string.mobile_number));
                }
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnNext:
                checkDataEnterd();
                break;
        }
    }

    private void checkDataEnterd() {
        String phoneNumber = signInBinding.etPhoneNumber.getText().toString().trim().replace(" ", "");
        String dialCode = signInBinding.tvDialCode.getText().toString().trim();
        if (Validations.isEditTextEmpty(phoneNumber)) {
            showErrorSnackBar(getResources().getString(R.string.v_phone_number));
            signInBinding.etPhoneNumber.requestFocus();
        }
        else if (phoneNumber.length() < AppConstants.MOBILE_REQ_LENGTH) {
            showErrorSnackBar(getResources().getString(R.string.v_phone_number_9digit));
            signInBinding.etPhoneNumber.requestFocus();
        }
        else {
            PasswordActivity.launch(SignInActivity.this, false, phoneNumber, dialCode);
//            PasswordActivity.launch(SignInActivity.this, false, phoneNumber);
        }
    }
}
