package com.alnahla.model.login;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Awesome Pojo Generator
 */
public class Data implements Serializable {
    @SerializedName("is_new_request")
    @Expose
    private Integer is_new_request;

    @SerializedName("notification_type")
    @Expose
    private String notification_type;

    @SerializedName("is_order_running")
    @Expose
    private Integer is_order_running;
    @SerializedName("message")
    @Expose
    private String message;

    @SerializedName("admin_contact_number")
    @Expose
    private String admin_contact_number;

    @SerializedName("order_details")
    @Expose
    private Order_details order_details;

    public void setIs_order_running(Integer is_order_running) {
        this.is_order_running = is_order_running;
    }

    public Integer getIs_order_running() {
        return is_order_running;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setOrder_details(Order_details order_details) {
        this.order_details = order_details;
    }

    public Order_details getOrder_details() {
        return order_details;
    }

    public String getAdmin_contact_number() {
        return admin_contact_number;
    }

    public void setAdmin_contact_number(String admin_contact_number) {
        this.admin_contact_number = admin_contact_number;
    }

    public Integer getIs_new_request() {
        return is_new_request;
    }

    public void setIs_new_request(Integer is_new_request) {
        this.is_new_request = is_new_request;
    }

    public String getNotification_type() {
        return notification_type;
    }

    public void setNotification_type(String notification_type) {
        this.notification_type = notification_type;
    }
}