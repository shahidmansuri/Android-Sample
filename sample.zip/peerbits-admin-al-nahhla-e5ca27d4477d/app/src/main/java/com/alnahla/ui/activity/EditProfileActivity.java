package com.alnahla.ui.activity;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.design.widget.Snackbar;
import android.support.v4.content.FileProvider;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;

import com.alnahla.AppConstants;
import com.alnahla.AppStrings;
import com.alnahla.R;
import com.alnahla.databinding.ActivityEditProfileBinding;
import com.alnahla.model.newlogin.User_info;
import com.alnahla.network.API_CONSTANTS;
import com.alnahla.network.API_EndPoints;
import com.alnahla.network.NetworkCall;
import com.alnahla.network.listeners.NoInternetListner;
import com.alnahla.network.listeners.RetrofitResponseListener;
import com.alnahla.ui.BaseActivity;
import com.alnahla.ui.dialog.ImagePicker;
import com.alnahla.utils.AmazonUtil;
import com.alnahla.utils.Constants;
import com.alnahla.utils.Logger;
import com.alnahla.utils.Utils;
import com.alnahla.utils.Validations;
import com.alnahla.utils.pref.PreferenceKeys;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferType;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class EditProfileActivity extends BaseActivity implements OnClickListener {
    ActivityEditProfileBinding mBinder;
    private String selectedImage = "";
    private final int CAMERA = 0, GALLERY = 1;

    //amazon
    private TransferUtility transferUtility;
    private TransferListener transferListener;
    private ArrayList<HashMap<String, Object>> transferRecordMaps;
    private String urlS3 = "";

    //permissions
    private String cameraPermission = Manifest.permission.CAMERA;
    private String externalStoragePermission = Manifest.permission.WRITE_EXTERNAL_STORAGE;

    private User_info userInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinder = DataBindingUtil.setContentView(this, R.layout.activity_edit_profile);
        setStatusBarColor(this, getResources().getColor(R.color.status_color_green));
        init();
        setListsners();
        setUpToolBar();
        setValues();
        initBucket();
    }

    private void setListsners() {
        mBinder.rlProfileImageView.setOnClickListener(this);
        mBinder.btnSubmit.setOnClickListener(this);
    }

    private void init() {
        if (session.getValueFromKey(PreferenceKeys.KEY_USER, "").equals("")) {
            userInfo = new User_info();
        } else {
            userInfo = gson.fromJson(session.getValueFromKey(PreferenceKeys.KEY_USER, ""), User_info.class);
        }

        urlS3 = userInfo.getImage();
    }

    private void setUpToolBar() {
        mBinder.included.title.setText(getString(R.string.edit_profile));
        mBinder.included.toolbar.setNavigationIcon(R.drawable.ic_back_arrow_white);
        mBinder.included.toolbar.setNavigationOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void setValues() {
        glideLoader.loadImageForUser(urlS3, mBinder.rlProfileImageView);
        mBinder.etFullName.setText(userInfo.getFull_name());
    }

    @Override
    public void onClick(View v) {
        Utils.preventDoubleClick(v);
        switch (v.getId()) {

            case R.id.rlProfileImageView:

                if (android.os.Build.VERSION.SDK_INT >= 23) {
                    checkForPermission();
                } else {
                    selectImageDialog();
                }
                break;
            case R.id.btnSubmit:
                if (isValid()) {
                    if (!selectedImage.equalsIgnoreCase("")) {
                        beginUpload(selectedImage);
                    } else {
                        apiSubmitProfileData(false);
                    }
                }
                break;
            default:
                break;
        }
    }

    private void checkForPermission() {
        try {
            Dexter.withActivity(this).withPermissions(cameraPermission, externalStoragePermission).withListener(new MultiplePermissionsListener() {
                @Override
                public void onPermissionsChecked(MultiplePermissionsReport report) {
                    if (report.areAllPermissionsGranted()) {
                        selectImageDialog();
                    } else {
                        showSnackBar(getResources().getString(R.string.err_grantAllPer));
                    }
                }

                @Override
                public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                    token.continuePermissionRequest();
                }

            })
                    .onSameThread()
                    .check();
        } catch (Exception e) {

        }
    }

    private boolean isValid() {
        if (Validations.isEditTextEmpty(mBinder.etFullName)) {
            mBinder.etFullName.requestFocus();
            showErrorSnackBar(getString(R.string.str_err_msg_please_enter_full_name));
            return false;
        }

        return true;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            switch (requestCode) {

                case CAMERA:
//                    mBinder.ivAddImage.setVisibility(View.GONE);
                    glideLoader.loadCircleImageFromFile(new File(selectedImage), mBinder.rlProfileImageView);
                    break;

                case GALLERY:
                    if (data.getData() != null) {

                        selectedImage = getRealPathFromURI(data.getData());

                        glideLoader.loadCircleImageFromFile(new File(selectedImage), mBinder.rlProfileImageView);
                    } else {
                        Snackbar.make(mBinder.rlProfileImageView, getString(R.string.str_bad_image_file), Snackbar.LENGTH_LONG)
                                .show();
                    }
                    break;
                default:
                    Snackbar.make(mBinder.rlProfileImageView, getString(R.string.str_resu), Snackbar.LENGTH_LONG)
                            .show();
                    break;
            }
        }
    }

    /*

        Custom Methods

     */

    private void selectImageDialog() {
        new ImagePicker(this) {
            @Override
            protected void onCameraClicked() {
                displayCamera();
            }

            @Override
            protected void onGalleryClicked() {
                Intent pickPhoto = new Intent(Intent.ACTION_PICK,
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(pickPhoto, GALLERY);
            }
        }.show();
    }

    private void displayCamera() {
        File imagesFolder = new File(Environment
                .getExternalStorageDirectory(), getResources()
                .getString(R.string.app_name));
        try {
            if (!imagesFolder.exists()) {
                boolean isCreated = imagesFolder.mkdirs();
                if (!isCreated) {
                    showToastShort(getString(R.string.storage_not_found));
                    return;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // -------- Start of v24 FileProvider concept ----------
        String timeStamp = new SimpleDateFormat(AppStrings.PIC_TIMESTAMP_FORMAT, Locale.getDefault()).format(new Date());
        String imageFileName = "IMG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        try {
            File image = File.createTempFile(
                    imageFileName,  /* prefix */
                    AppStrings.PIC_EXTENSION,         /* suffix */
                    storageDir      /* directory */
            );
            Uri uriSavedImage = FileProvider.getUriForFile(EditProfileActivity.this, Constants.FILE_AUTORITY, image);
            // -------- End v24 FileProvider concept ----------
            Intent intent = new Intent(
                    MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, uriSavedImage);

            selectedImage = image.getAbsolutePath();
            try {
                startActivityForResult(intent, CAMERA);
            } catch (ActivityNotFoundException e) {
                e.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void initBucket() {
        transferUtility = AmazonUtil.getTransferUtility(this);
        transferRecordMaps = new ArrayList<>();
        transferListener = new TransferListener() {
            @Override
            public void onStateChanged(int id, TransferState state) {
                switch (state) {
                    case IN_PROGRESS:
                        break;
                    case COMPLETED:
                        stopProgress();
                        apiSubmitProfileData(false);
                        break;
                    case FAILED:
                        stopProgress();
                        showToastShort(getString(R.string.strFailed));
                        break;
                }
            }

            @Override
            public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
            }

            @Override
            public void onError(int id, Exception ex) {

            }
        };
        transferRecordMaps.clear();
    }

    private void beginUpload(String filePath) {
        showProgress();
        File file = new File(filePath);
        transferUtility.upload(AppConstants.BUCKET_NAME, file.getName(),
                file, CannedAccessControlList.PublicRead);
        urlS3 = getAWSUrl(AppConstants.BUCKET_NAME, file.getName());
        List<TransferObserver> observersForUpload = transferUtility.getTransfersWithType(TransferType.UPLOAD);
        for (TransferObserver observer : observersForUpload) {
            HashMap<String, Object> map = new HashMap<String, Object>();
            AmazonUtil.fillMap(map, observer, false);
            transferRecordMaps.add(map);
            observer.setTransferListener(transferListener);
        }
    }

    private void apiSubmitProfileData(final boolean isGetting) {

        HashMap<String, String> params = new HashMap<>();
        if (!isGetting) {
            params.put(API_CONSTANTS.IMAGE, urlS3);
            params.put(API_CONSTANTS.FULL_NAME, mBinder.etFullName.getText().toString().trim());
        }

        NetworkCall.with(this)
                .setRequestParams(params)
                .setEndPoint(API_EndPoints.COMPLETE_PROFILE)
                .setNoInternetListner(new NoInternetListner() {
                    @Override
                    public void onNoInternet() {

                    }
                }).setResponseListener(new RetrofitResponseListener() {
            @Override
            public void onPreExecute() {
                showProgress();
            }

            @Override
            public void onSuccess(int statusCode, final JSONObject jsonObject, final String response) {
                stopProgress();
                showToastLong(jsonObject.optString(API_CONSTANTS.MESSAGE));
                userInfo.setFull_name(mBinder.etFullName.getText().toString());
                userInfo.setImage(urlS3);
                session.setValueFromKey(PreferenceKeys.KEY_USER, gson.toJson(userInfo));
                finish();
            }

            @Override
            public void onError(int statusCode, ArrayList<String> messages) {
                stopProgress();
                showErrorSnackBar(messages.get(0));
            }
        }).makeCall();

    }

}
