package com.alnahla;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.multidex.MultiDexApplication;
import android.util.Log;

import com.alnahla.listener.ContextProvider;
import com.alnahla.network.NetworkCall;
import com.alnahla.network.listeners.DefaultActionPerformer;
import com.alnahla.utils.ForceUpdateChecker;
import com.alnahla.utils.pref.SessionManager;
import com.crashlytics.android.Crashlytics;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;

import java.util.HashMap;
import java.util.Map;

import io.fabric.sdk.android.Fabric;

/**
 * Created by Mushahid on 1/8/2018
 */

public class AppClass extends MultiDexApplication implements ContextProvider {

    SessionManager sessionManager;
    private Activity currentActivity;
    static AppClass instance;
    private static final String TAG = AppClass.class.getSimpleName();

    @Override
    public Context getActivityContext() {
        return currentActivity;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        init();
        instance = this;
        NetworkCall.setBASE_URL(BuildConfig.BASE_URL);
        NetworkCall.setActionPerformer(new DefaultActionPerformer() {
            @Override
            public void onActionPerform(HashMap<String, String> headers, HashMap<String, String> params) {

                if (sessionManager.getNewToken() != null) {
                    String token = sessionManager.getNewToken().getType() + " " + sessionManager.getNewToken().getToken();
                    headers.put("Authorization", token);
                }
            }
        });

        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
                AppClass.this.currentActivity = activity;
            }

            @Override
            public void onActivityStarted(Activity activity) {
                AppClass.this.currentActivity = activity;
            }

            @Override
            public void onActivityResumed(Activity activity) {
                AppClass.this.currentActivity = activity;
            }

            @Override
            public void onActivityPaused(Activity activity) {
                AppClass.this.currentActivity = null;
            }

            @Override
            public void onActivityStopped(Activity activity) {
                // don't clear current activity because activity may get stopped after
                // the new activity is resumed
            }

            @Override
            public void onActivitySaveInstanceState(Activity activity, Bundle outState) {

            }

            @Override
            public void onActivityDestroyed(Activity activity) {
                // don't clear current activity because activity may get destroyed after
                // the new activity is resumed
            }
        });
    }

    // Getter to access Singleton instance
    public static AppClass getInstance() {
        return instance;
    }

    private void init() {
        Fabric.with(this, new Crashlytics());
        sessionManager = new SessionManager(this);

        final FirebaseRemoteConfig firebaseRemoteConfig = FirebaseRemoteConfig.getInstance();

        PackageManager packageManager = this.getPackageManager();
        PackageInfo packageInfo = null;
        try {
            packageInfo = packageManager.getPackageInfo(getPackageName(), 0);
            String currentVersion = packageInfo.versionName;

            // set in-app defaults
            Map<String, Object> remoteConfigDefaults = new HashMap();
            //   remoteConfigDefaults.put(ForceUpdateChecker.KEY_UPDATE_REQUIRED, true);
            //    remoteConfigDefaults.put(ForceUpdateChecker.KEY_CURRENT_VERSION, "1.6.6");
            remoteConfigDefaults.put(ForceUpdateChecker.KEY_UPDATE_URL,
                    "https://play.google.com/store/apps/details?id=com.alnahla");

            firebaseRemoteConfig.setDefaults(remoteConfigDefaults);
            firebaseRemoteConfig.fetch(60) // fetch every minutes
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Log.d(TAG, "remote config is fetched.");
                                firebaseRemoteConfig.activateFetched();
                            }
                        }
                    });
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

    }
}
