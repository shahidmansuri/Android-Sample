package com.alnahla.widget;

import android.content.Context;
import android.support.design.widget.TextInputEditText;
import android.util.AttributeSet;

public class TTextInputEditText extends TextInputEditText {

    public TTextInputEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        FontManager.getInstance().applyFont(this, attrs);
    }
}
