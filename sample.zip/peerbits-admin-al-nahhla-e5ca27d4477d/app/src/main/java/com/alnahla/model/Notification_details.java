package com.alnahla.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Awesome Pojo Generator
 */
public class Notification_details {
    @SerializedName("notification_type")
    @Expose
    private String notification_type;
    @SerializedName("is_read")
    @Expose
    private String is_read;
    @SerializedName("notification_details")
    @Expose
    private String notification_details;
    @SerializedName("notification_date_time")
    @Expose
    private String notification_date_time;
    @SerializedName("notification_title")
    @Expose
    private String notification_title;
    @SerializedName("notification_id")
    @Expose
    private Integer notification_id;
    @SerializedName("order_id")
    @Expose
    private String order_id;

    public void setNotification_type(String notification_type) {
        this.notification_type = notification_type;
    }

    public String getNotification_type() {
        return notification_type;
    }

    public void setIs_read(String is_read) {
        this.is_read = is_read;
    }

    public String getIs_read() {
        return is_read;
    }

    public void setNotification_details(String notification_details) {
        this.notification_details = notification_details;
    }

    public String getNotification_details() {
        return notification_details;
    }

    public void setNotification_date_time(String notification_date_time) {
        this.notification_date_time = notification_date_time;
    }

    public String getNotification_date_time() {
        return notification_date_time;
    }

    public void setNotification_title(String notification_title) {
        this.notification_title = notification_title;
    }

    public String getNotification_title() {
        return notification_title;
    }

    public void setNotification_id(Integer notification_id) {
        this.notification_id = notification_id;
    }

    public Integer getNotification_id() {
        return notification_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getOrder_id() {
        return order_id;
    }
}