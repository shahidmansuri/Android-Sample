package com.alnahla.model.newlogin;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Awesome Pojo Generator
 */
public class Data {
    @SerializedName("admin_contact_number")
    @Expose
    private String admin_contact_number;

    @SerializedName("user_info")
    @Expose
    private User_info user_info;
    @SerializedName("auth")
    @Expose
    private Auth auth;
    @SerializedName("ongoing_order_details")
    @Expose
    private Ongoing_order_details ongoing_order_details;
    @SerializedName("is_order_running")
    @Expose
    private Integer is_order_running;
    @SerializedName("message")
    @Expose
    private String message;

    public void setUser_info(User_info user_info) {
        this.user_info = user_info;
    }

    public User_info getUser_info() {
        return user_info;
    }

    public void setAuth(Auth auth) {
        this.auth = auth;
    }

    public Auth getAuth() {
        return auth;
    }

    public void setOngoing_order_details(Ongoing_order_details ongoing_order_details) {
        this.ongoing_order_details = ongoing_order_details;
    }

    public Ongoing_order_details getOngoing_order_details() {
        return ongoing_order_details;
    }

    public void setIs_order_running(Integer is_order_running) {
        this.is_order_running = is_order_running;
    }

    public Integer getIs_order_running() {
        return is_order_running;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }


    public String getAdmin_contact_number() {
        return admin_contact_number;
    }

    public void setAdmin_contact_number(String admin_contact_number) {
        this.admin_contact_number = admin_contact_number;
    }

}