package com.alnahla.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

import com.alnahla.AppConstants;
import com.alnahla.R;
import com.alnahla.databinding.ActivityResetPasswordBinding;
import com.alnahla.network.API_CONSTANTS;
import com.alnahla.network.API_EndPoints;
import com.alnahla.network.NetworkCall;
import com.alnahla.network.listeners.RetrofitResponseListener;
import com.alnahla.ui.BaseActivity;
import com.alnahla.utils.Validations;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class ResetPasswordActivity extends BaseActivity implements OnClickListener {
    ActivityResetPasswordBinding mBinding;
    String newPassword, dialcode, phoneNumber;

    public static void launch(Activity activity, boolean isFinishActivity, String dialCode, String phoneNumber) {
        if (isFinishActivity) {
            Intent intent = new Intent(activity, ResetPasswordActivity.class);
            intent.putExtra(AppConstants.DIALCODE, dialCode);
            intent.putExtra(AppConstants.PHONENUMBER, phoneNumber);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        } else {
            Intent intent = new Intent(activity, ResetPasswordActivity.class);
            intent.putExtra(AppConstants.DIALCODE, dialCode);
            intent.putExtra(AppConstants.PHONENUMBER, phoneNumber);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_reset_password);
        setStatusBarColor(this,getResources().getColor(R.color.status_color_green));
        setOnClickListner();
        setUpToolBar();
    }

    private void setUpToolBar() {
        mBinding.included.toolbar.setNavigationIcon(R.drawable.ic_back_arrow_white);
        mBinding.included.title.setText(getString(R.string.reset_password));
        mBinding.included.toolbar.setNavigationOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                SignInActivity.launch(ResetPasswordActivity.this, true);
            }
        });
    }

    private void setOnClickListner() {
        mBinding.btnSave.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnSave:
                if (isValid()) {
                    dialcode = getIntent().getStringExtra(AppConstants.DIALCODE);
                    phoneNumber = getIntent().getStringExtra(AppConstants.PHONENUMBER);
                    newPassword = mBinding.etNewPassword.getText().toString().trim();
                    resetPasswordApi(dialcode, phoneNumber, newPassword);
                }
               /* Intent intent = new Intent(this, SuccessActivity.class);
                startActivity(intent);*/
        }
    }

    private void resetPasswordApi(String dialcode, String phoneNumber, String newPassword) {
        HashMap<String, String> params = new HashMap<>();
        params.put(API_CONSTANTS.DIAL_CODE, dialcode);
        params.put(API_CONSTANTS.PHONE_NO, phoneNumber);
        params.put(API_CONSTANTS.NEW_PASS, newPassword);

        NetworkCall.with(this)
                .setEndPoint(API_EndPoints.RESET_PASSWORD)
                .setRequestParams(params)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                        showProgress(getResources().getString(R.string.txt_pls_wait));
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        stopProgress();
                        showToastShort(jsonObject.optString(API_CONSTANTS.MESSAGE));
                        startActivity(new Intent(ResetPasswordActivity.this, SuccessActivity.class));
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        stopProgress();
                        errorHandleFromApi(messages,statusCode);

                    }
                }).makeCall();
    }

    private boolean isValid() {
        newPassword = mBinding.etNewPassword.getText().toString().trim();
        String confirmPassword = mBinding.etConfirmPassword.getText().toString().trim();
        boolean isValid = false;
        if (Validations.isEditTextEmpty(newPassword)) {
            showErrorSnackBar(getResources().getString(R.string.err_enterNewPass));
            mBinding.etNewPassword.requestFocus();
        } else if (newPassword.length() < AppConstants.MIN_PASS_LENGTH) {
            showSnackBar(getResources().getString(R.string.err_newPassBetween));
            mBinding.etNewPassword.requestFocus();
        } else if (newPassword.length() > AppConstants.MAX_PASS_LENGTH) {
            showSnackBar(getResources().getString(R.string.err_newPassBetween));
            mBinding.etNewPassword.requestFocus();
        } else if (Validations.isEditTextEmpty(confirmPassword)) {
            showSnackBar(getResources().getString(R.string.err_enterConfPass));
            mBinding.etConfirmPassword.requestFocus();
        } else if (confirmPassword.length() < AppConstants.MIN_PASS_LENGTH) {
            showSnackBar(getResources().getString(R.string.err_conPassBetween));
            mBinding.etConfirmPassword.requestFocus();
        } else if (confirmPassword.length() > AppConstants.MAX_PASS_LENGTH) {
            showSnackBar(getResources().getString(R.string.err_conPassBetween));
            mBinding.etConfirmPassword.requestFocus();
        } else if (!newPassword.equals(confirmPassword)) {
            showErrorSnackBar(getResources().getString(R.string.err_newConfPassMismatch));
            mBinding.etConfirmPassword.requestFocus();
        } else {
            isValid = true;
        }
        return isValid;
    }
}
