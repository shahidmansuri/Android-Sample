package com.alnahla.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Awesome Pojo Generator
 */
public class UserInfo {

    @SerializedName("user_id")
    @Expose
    private String user_id;
    @SerializedName("full_name")
    @Expose
    private String full_name;
    @SerializedName("country_code")
    @Expose
    private String country_code;
    @SerializedName("mobile_number")
    @Expose
    private String mobile_number;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("profile_image")
    @Expose
    private String profile_image;

    @SerializedName("is_email_verified")
    @Expose
    private String is_email_verified;

    @SerializedName("is_mobile_verified")
    @Expose
    private String is_mobile_verified;

    @SerializedName("dob")
    @Expose
    private String dob;

    @SerializedName("is_notification")
    @Expose
    private String is_notification;
    @SerializedName("is_profile_approved_by_admin")
    @Expose
    private String is_profile_approved_by_admin;


    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getFull_name() {
        return full_name;
    }

    public void setFull_name(String full_name) {
        this.full_name = full_name;
    }

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    public String getMobile_number() {
        return mobile_number;
    }

    public void setMobile_number(String mobile_number) {
        this.mobile_number = mobile_number;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getProfile_image() {
        return profile_image;
    }

    public void setProfile_image(String profile_image) {
        this.profile_image = profile_image;
    }

    public String getIs_email_verified() {
        return is_email_verified;
    }

    public void setIs_email_verified(String is_email_verified) {
        this.is_email_verified = is_email_verified;
    }

    public String getIs_mobile_verified() {
        return is_mobile_verified;
    }

    public void setIs_mobile_verified(String is_mobile_verified) {
        this.is_mobile_verified = is_mobile_verified;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getIs_notification() {
        return is_notification;
    }

    public void setIs_notification(String is_notification) {
        this.is_notification = is_notification;
    }

    public String getIs_profile_approved_by_admin() {
        return is_profile_approved_by_admin;
    }

    public void setIs_profile_approved_by_admin(String is_profile_approved_by_admin) {
        this.is_profile_approved_by_admin = is_profile_approved_by_admin;
    }
}