package com.alnahla.network;

/**
 * Created by Mushahid on 1/8/2018
 */

public class API_EndPoints {
    //    public static final String BASE_URL = "http://peerdevelopment.com/apps/grubshoot/web/v1/user/";
    public static final String SIGN_IN = "auth/login";
    public static final String GET_TOKEN = "common/gettoken";
    public static final String FORGOT_M_PIN = "forgotmpin";
    public static final String FORGOTPASSWORD = "auth/forgotpassword";
    public static final String OTP = "auth/verifyotp";
    public static final String RESET_PASSWORD = "auth/resetpassword";
    public static final String CHANGE_PASSWORD = "auth/changepassword";
    public static final String MY_ORDER_LIST = "order/order-list";

    public static final String LOGOUT = "logout";
    public static final String CHANGE_M_PIN = "changempin";
    public static final String CONTACT_US = "common/contactus";
    public static final String GET_CMS_PAGES = "getcms";
    public static final String GET_CANCEl_ORDER_REASON_LIST = "reasonlist";
    public static final String IS_ONLINE = "notificationsetting";
    public static final String CHANGE_STATUS = "changestatus";
    public static final String SEND_CANCEl_ORDER = "cancelorder";
    public static final String GET_DASHBOARD_COUNT = "dashboard";
    public static final String RATING_REVIEWS = "review";
    public static final String NOTIFICATION_LIST = "notification/notificationlist";
    public static final String CLEAR_NOTIFICATION_LIST = "notification/clearnotificationlist";
    public static final String UPDATEPROFILEPIC = "updateprofileimage";
    public static final String PAYMENTSTATUS = "paymentreceived";
    public static final String UPDATELOCATION = "changelocation";
    public static final String GET_CMS = "common/getcms";
    public static final String COMPLETE_PROFILE = "auth/editprofile";
    public static final String FAQ_LIST = "common/faqlist";
    public static final String DASHBOARD = "rider/dashboard";

    public static final String ACCEPT_CANCEL = "order/cancel-accept-order";
    public static final String ORDER_DETAILS = "order/order-detail";

    public static final String REASON_LIST = "common/reason-list";
    public static final String UPDATE_ORDER_STATUS = "order/update-order-status";
    public static final String EARNING_LIST = "rider/earning";
}
