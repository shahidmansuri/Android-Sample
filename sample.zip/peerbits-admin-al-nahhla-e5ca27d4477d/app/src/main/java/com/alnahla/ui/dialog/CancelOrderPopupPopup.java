package com.alnahla.ui.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.alnahla.R;
import com.alnahla.databinding.CustomDialogCancelOrderBinding;
import com.alnahla.service.RingtonePlayingService;


/**
 * Created by AnkitKumar on 25-07-2017.
 */

public abstract class CancelOrderPopupPopup extends Dialog implements View.OnClickListener {
    private CustomDialogCancelOrderBinding binder;

    private String message = "";
    private Activity mActivity;

    public CancelOrderPopupPopup(@NonNull Activity mActivity, String message) {
        super(mActivity);
        this.message = message;
        this.mActivity = mActivity;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        binder = DataBindingUtil.inflate(LayoutInflater.from(getContext()), R.layout.custom_dialog_cancel_order, null, false);
        setContentView(binder.getRoot());

        try {
            Window window = getWindow();
            assert window != null;
            WindowManager.LayoutParams wlp = window.getAttributes();
            wlp.gravity = Gravity.CENTER;
            window.setAttributes(wlp);
            getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
            getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            getWindow().setDimAmount(0.7f);
        } catch (Exception e) {
            e.printStackTrace();
        }
        binder.tvMessage.setText(message);
        setCancelable(false);
        setCanceledOnTouchOutside(false);
        binder.tvButtonOk.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvButtonOk:
                Intent stopIntent = new Intent(mActivity, RingtonePlayingService.class);
                mActivity.stopService(stopIntent);
                onOkButtonClick(CancelOrderPopupPopup.this);
                break;
        }
    }

    protected abstract void onOkButtonClick(Dialog dialog);
}


