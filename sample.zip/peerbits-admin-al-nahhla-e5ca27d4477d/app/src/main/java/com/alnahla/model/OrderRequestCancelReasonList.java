package com.alnahla.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

/**
 * Awesome Pojo Generator
 */
public class OrderRequestCancelReasonList implements Serializable {
    @SerializedName("reason_list")
    @Expose
    private List<Reason_list> reason_list;


    public void setReason_list(List<Reason_list> reason_list) {
        this.reason_list = reason_list;
    }

    public List<Reason_list> getReason_list() {
        return reason_list;
    }


}