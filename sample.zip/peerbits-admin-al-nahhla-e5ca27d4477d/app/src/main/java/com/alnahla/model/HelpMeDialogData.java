package com.alnahla.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Awesome Pojo Generator
 */
public class HelpMeDialogData {
    @SerializedName("reason")
    @Expose
    private List<Reason> reason;
    @SerializedName("is_last")
    @Expose
    private Integer is_last;
    @SerializedName("message")
    @Expose
    private String message;

    public void setReason(List<Reason> reason) {
        this.reason = reason;
    }

    public List<Reason> getReason() {
        return reason;
    }

    public void setIs_last(Integer is_last) {
        this.is_last = is_last;
    }

    public Integer getIs_last() {
        return is_last;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}