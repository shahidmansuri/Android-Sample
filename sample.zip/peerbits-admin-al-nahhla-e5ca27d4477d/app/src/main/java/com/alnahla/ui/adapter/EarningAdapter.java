package com.alnahla.ui.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alnahla.AppConstants;
import com.alnahla.R;
import com.alnahla.model.Earning_details;
import com.alnahla.network.listeners.OnLoadMoreListener;
import com.alnahla.ui.fragments.EarningFragment;

import java.util.ArrayList;
import java.util.List;

public class EarningAdapter extends RecyclerView.Adapter {

    private List<Earning_details> earningDetailsList;
    private EarningFragment earningFragment;
    private RecyclerView recyclerView;

    private LinearLayoutManager linearLayoutManager;
    private final int VIEW_ITEM = 1;

    //** LoadMore Variables
    private OnLoadMoreListener onLoadMoreListener;
    private int visibleThreshold = 1;
    private int lastVisibleItem, totalItemCount;
    private boolean loading;

    private Context mContext;

    public EarningAdapter(EarningFragment earningFragment, ArrayList<Earning_details> earning_details, RecyclerView recyclerView) {
        this.earningFragment = earningFragment;

        earningDetailsList = earning_details;
        if (recyclerView.getLayoutManager() instanceof LinearLayoutManager) {

            linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

            recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                @Override
                public void onScrolled(RecyclerView recyclerView,
                                       int dx, int dy) {
                    super.onScrolled(recyclerView, dx, dy);
                    totalItemCount = linearLayoutManager.getItemCount();
                    lastVisibleItem = linearLayoutManager.findLastVisibleItemPosition();
                    if (!loading && totalItemCount <= (lastVisibleItem + visibleThreshold)) {
                        // End has been reached
                        // Do something
                        if (onLoadMoreListener != null) {
                            loading = true;
                            onLoadMoreListener.onLoadMore();
                        }
                    }
                }
            });
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder vh;
        if (viewType == VIEW_ITEM) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.raw_earning_list, parent, false);
            vh = new EarningAdapter.MyViewHolder(v);
        } else {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_progress_bar, parent, false);
            vh = new EarningAdapter.ProgressBar(v);
        }
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {

        Earning_details earning_details = earningDetailsList.get(position);

        if (earning_details != null) {
            if (holder instanceof MyViewHolder) {

                int type = earning_details.getType();
                ((MyViewHolder) holder).tvCurrency.setText(String.valueOf(earning_details.getEarnings()));
                ((MyViewHolder) holder).tvOrder.setText(String.valueOf(earning_details.getOrders()));
                ((MyViewHolder) holder).tvTime.setText(String.valueOf(earning_details.getJourney_time()));

                if (type == AppConstants.TYPE_FILTERED) {
                    ((MyViewHolder) holder).rlType.setVisibility(View.GONE);
                    ((MyViewHolder) holder).rlDate.setVisibility(View.VISIBLE);
                    ((MyViewHolder) holder).tvFromDate.setText(earningFragment.getStart_date());
                    ((MyViewHolder) holder).tvToDate.setText(earningFragment.getEnd_date());
                } else if (type == AppConstants.TYPE_TODAY) {
                    ((MyViewHolder) holder).rlType.setVisibility(View.VISIBLE);
                    ((MyViewHolder) holder).rlDate.setVisibility(View.GONE);
                    ((MyViewHolder) holder).tvType.setText(R.string.today);
                } else if (type == AppConstants.TYPE_TOTAL) {
                    ((MyViewHolder) holder).rlType.setVisibility(View.VISIBLE);
                    ((MyViewHolder) holder).rlDate.setVisibility(View.GONE);
                    ((MyViewHolder) holder).tvType.setText(R.string.total);
                }
            }

        } else {
            ((ProgressBar) holder).progressBar.setIndeterminate(true);
        }
    }

    @Override
    public int getItemViewType(int position) {
        int VIEW_PROGRESS = 0;
        return earningDetailsList.get(position) != null ? VIEW_ITEM : VIEW_PROGRESS;
    }

    public void setLoaded() {
        loading = false;
    }

    public void setOnLoadMoreListener(OnLoadMoreListener onLoadMoreListener) {
        this.onLoadMoreListener = onLoadMoreListener;
    }

    @Override
    public int getItemCount() {
        return earningDetailsList.size();
    }

    private class MyViewHolder extends RecyclerView.ViewHolder {

        CardView cardViewEarning;
        RelativeLayout rlDate, rlType;
        TextView tvFromDate, tvToDate, tvType, tvCurrency, tvOrder, tvTime;

        public MyViewHolder(View v) {
            super(v);

            cardViewEarning = (CardView) v.findViewById(R.id.cardViewEarning);

            rlDate = (RelativeLayout) v.findViewById(R.id.rlDate);
            rlType = (RelativeLayout) v.findViewById(R.id.rlType);

            tvFromDate = (TextView) v.findViewById(R.id.tvFromDate);
            tvToDate = (TextView) v.findViewById(R.id.tvToDate);
            tvType = (TextView) v.findViewById(R.id.tvType);
            tvCurrency = (TextView) v.findViewById(R.id.tvCurrency);
            tvOrder = (TextView) v.findViewById(R.id.tvOrder);
            tvTime = (TextView) v.findViewById(R.id.tvTime);
        }
    }

    public class ProgressBar extends RecyclerView.ViewHolder {

        android.widget.ProgressBar progressBar;

        public ProgressBar(View itemView) {
            super(itemView);

            progressBar = (android.widget.ProgressBar) itemView.findViewById(R.id.progressBar);
        }
    }

    public void addAll(List<Earning_details> earningDetails) {
        this.earningDetailsList.clear();
        this.earningDetailsList.addAll(earningDetails);
        notifyDataSetChanged();
    }

    public void addItem(Earning_details earning) {
        this.earningDetailsList.add(earning);
        notifyDataSetChanged();
    }
}
