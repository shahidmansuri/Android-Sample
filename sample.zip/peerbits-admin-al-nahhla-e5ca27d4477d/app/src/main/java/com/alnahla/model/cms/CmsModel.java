package com.alnahla.model.cms;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.List;
/**
 * Awesome Pojo Generator
 * */
public class CmsModel {
  @SerializedName("data")
  @Expose
  private Data data;
  @SerializedName("success")
  @Expose
  private Integer success;
  @SerializedName("message")
  @Expose
  private String message;
  @SerializedName("error")
  @Expose
  private List<Error> error;
  public void setData(Data data){
   this.data=data;
  }
  public Data getData(){
   return data;
  }
  public void setSuccess(Integer success){
   this.success=success;
  }
  public Integer getSuccess(){
   return success;
  }
  public void setMessage(String message){
   this.message=message;
  }
  public String getMessage(){
   return message;
  }
  public void setError(List<Error> error){
   this.error=error;
  }
  public List<Error> getError(){
   return error;
  }
}