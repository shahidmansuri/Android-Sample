package com.alnahla.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.alnahla.AppStrings;
import com.alnahla.R;
import com.alnahla.databinding.ActivityNotificationBinding;
import com.alnahla.model.NotificationData;
import com.alnahla.model.NotificationList;
import com.alnahla.network.API_CONSTANTS;
import com.alnahla.network.API_EndPoints;
import com.alnahla.network.NetworkCall;
import com.alnahla.network.listeners.RetrofitResponseListener;
import com.alnahla.ui.BaseActivity;
import com.alnahla.ui.adapter.NotificationListAdapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class NotificationsActivity extends BaseActivity{

    private static final String TAG = NotificationsActivity.class.getSimpleName();
    ActivityNotificationBinding mBinding;
    //for the load more
    private int start = 0;
    private int limit = 10;
    private boolean isLoading;
    private String isLast = "Y";

    NotificationListAdapter notificationListAdapter;
    private ArrayList<NotificationList> notificationList =new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_notification);
        setStatusBarColor(this,getResources().getColor(R.color.status_color_green));
        setUpUi();
    }

    public static void launch(Activity activity, boolean isFinishActivity) {
        if (isFinishActivity) {
            Intent intent = new Intent(activity, NotificationsActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        } else {
            Intent intent = new Intent(activity, NotificationsActivity.class);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        }
    }

    private void setUpUi() {

        setupToolBar(getResources().getString(R.string.notifications));
        apiNotificationList();
    }

    /*method to set up toolbar*/
    private void setupToolBar(String text) {
        this.setSupportActionBar(mBinding.toolbarLayout.toolbar);
        ActionBar ab = this.getSupportActionBar();
        if (ab != null) {
            ab.setDisplayShowTitleEnabled(false);
            ab.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            ab.setDisplayHomeAsUpEnabled(true);
        }
        mBinding.toolbarLayout.toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        mBinding.toolbarLayout.title.setText(text);
    }

    private void apiNotificationList() {
        HashMap<String, String> params = new HashMap<>();
        params.put(API_CONSTANTS.START, String.valueOf(start));
        params.put(API_CONSTANTS.LIMIT, String.valueOf(limit));

        NetworkCall.with(this)
                .setEndPoint(API_EndPoints.NOTIFICATION_LIST)
                .setRequestParams(params)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                        if (start == 0) {
                            showProgress(getResources().getString(R.string.txt_loading));
                        } else {
                            mBinding.pbProgress.setVisibility(View.VISIBLE);
                        }
                        isLoading = true;
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        stopProgress();
                        mBinding.pbProgress.setVisibility(View.GONE);
                        isLoading = false;
                        mBinding.tvNodata.setVisibility(View.GONE);
                        GsonBuilder gsonBuilder = new GsonBuilder();
                        Gson gson = gsonBuilder.create();
                        NotificationData model = gson.fromJson(String.valueOf(jsonObject), NotificationData.class);
                        if(model.getNotification_list().size()>0) {
                            isLast = model.getIs_last();
                            start = start + limit;
                            notificationList.addAll(model.getNotification_list());
                            setUpRecyclerView(notificationList);
                        } else {
                            setUpRecyclerView(notificationList);
                            mBinding.tvNodata.setVisibility(View.VISIBLE);
                        }
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        stopProgress();
                        isLoading = false;
                        mBinding.pbProgress.setVisibility(View.GONE);
                        mBinding.tvNodata.setVisibility(View.VISIBLE);
                        errorHandleFromApi(messages,statusCode);
                    }
                }).makeCall();
    }

    /**
     * method to set up recycler view
     */
    private void setUpRecyclerView(ArrayList<NotificationList> List) {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        if (notificationListAdapter == null) {
//            notificationListAdapter = new NotificationListAdapter(this, List);
            mBinding.rvNotificationList.setLayoutManager(linearLayoutManager);
            mBinding.rvNotificationList.setAdapter(notificationListAdapter);

        } else {
//            notificationListAdapter.setDataList(notificationList);
        }

        mBinding.rvNotificationList.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int totalItemCount = recyclerView.getLayoutManager().getItemCount();
                int lastVisibleItem = ((LinearLayoutManager) recyclerView.getLayoutManager()).findLastVisibleItemPosition();
                if (!isLoading && totalItemCount <= (lastVisibleItem + 2)) {
                    if (isLast.equalsIgnoreCase("N")) {
                        apiNotificationList();
                    }
                }
            }
        });
    }

    private void apiClearNotification() {
        NetworkCall.with(this)
                .setEndPoint(API_EndPoints.CLEAR_NOTIFICATION_LIST)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                        showProgress();
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        stopProgress();
                        mBinding.tvNodata.setVisibility(View.VISIBLE);
                        notificationList.clear();
                        notificationListAdapter.notifyDataSetChanged();
                    }
                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        stopProgress();
                        mBinding.tvNodata.setVisibility(View.VISIBLE);
                        errorHandleFromApi(messages,statusCode);
                    }
                }).makeCall();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_filter, menu);//Menu Resource, Menu
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {

        //Get a reference to your item by id
        final MenuItem item = menu.findItem(R.id.actionClearAll);
        //Here, you get access to the view of your item, in this case, the layout of the item has a FrameLayout as root view but you can change it to whatever you use
        FrameLayout rootView = (FrameLayout) item.getActionView();
        //Then you access to your control by finding it in the rootView
        TextView control = rootView.findViewById(R.id.tvSkip);

        control.setText(AppStrings.CLEAR_ALL);
        control.setTextColor(getResources().getColor(R.color.white));
        control.setAllCaps(false);
        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onOptionsItemSelected(item);
            }
        });
        //And from here you can do whatever you want with your control
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.actionClearAll:
                apiClearNotification();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
