package com.alnahla.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Pattern;


@SuppressLint("SimpleDateFormat")
public class Validations {

    public static final String DateFormat = "dd-MM-yyyy";
    public static final String Date_Format = "dd MMM yyyy";
    public static final String Date_Format_medium = "dd-MMM-yyyy";
    public static final String MyPostDateFormat = "EEE. dd.MM.yyyy";

    public static final String AppDateFormat = "MMM dd, yyyy";
    public static final String AppFullDateFormat = "MMMM dd, yyyy";

    public static final String MyPostDateDay = "dd";
    public static final String TimeFormat = "hh:mm aa";
    public static final String TimeFormatWithoutAMPM = "HH:mm";
    public static final String ReviewDateFormat = "dd-MM-yyyy, HH:mm aa";
    public static final String DateFormatCriminal = "MM/dd/yyyy";

    /**
     * Display Toast Message
     * Inputs:
     * 1. Context
     * 2. Message
     * Output: It will display Toast of given message
     */
    public static void showMessage(Context context, String msg) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }

    /**
     * Check String is Empty or not
     * Input:
     * 1. String
     * Output: True / False
     */
    public static boolean isEditTextEmpty(String text) {
        return text == null || TextUtils.isEmpty(text.trim());
    }

    /**
     * Check EditText is Empty or not
     * Input:
     * 1. EditText
     * Output: True / False
     */
    public static boolean isEditTextEmpty(EditText et) {
        return TextUtils.isEmpty(et.getText().toString().trim());
    }

    public static boolean isValidDesc(EditText etUserName) {
        String temp = etUserName.getText().toString().trim();

        return temp.length() >= 10 || temp.length() <= 3000;
    }

    public static boolean isMobileEmpty(EditText et) {
        return TextUtils.isEmpty(et.getText().toString());
    }

    /**
     * Regex pattern for Email Validation
     */
    static String regExpnEmail =
            "^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                    + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                    + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                    + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                    + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                    + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$";
    public final static Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile(regExpnEmail, Pattern.CASE_INSENSITIVE);

    /**
     * Check Email String is Valid or Not
     * Input:
     * 1. Email String
     * Output: True / False
     */
    public static boolean isValidEmail(String email) {
        return EMAIL_ADDRESS_PATTERN.matcher(email).matches();
    }

    public static boolean isValidEmail(EditText email) {
        return EMAIL_ADDRESS_PATTERN.matcher(email.getText().toString()).matches();
    }

    public static boolean isValidContact(EditText etContact) {
        String temp = etContact.getText().toString();

        return temp.length() >= 9 && temp.length() <= 10;
    }

    public static boolean isValidPassword(EditText etPassword) {
        String temp = etPassword.getText().toString();

        return temp.length() >= 4 && temp.length() <= 32;
    }

    public static boolean isValidUserName(EditText etUserName) {
        String temp = etUserName.getText().toString().trim();

        return temp.length() >= 6 || temp.length() <= 15;
    }

    /**
     * Check Email EditText is valid or not and display Right Drawable icon
     * Inputs:
     * 1. Context
     * 2. EditText
     * Output: True / False and also display right drawable of provided resource if it is false
     */
    public static boolean isValidEmail(Context context, EditText etEmail) {
        if (isEditTextEmpty(etEmail)) {
//			showMessage(context, context.getResources().getString(R.string.v_email));
            return false;
        } else return EMAIL_ADDRESS_PATTERN.matcher(etEmail.getText().toString().trim()).matches();
    }

    /**
     * Check Password EditText is Valid or Not
     * Inputs:
     * 1. Context
     * 2. EditText of Password
     * Output: True / False and also display toast if password is wrong
     */
    public static boolean isValidPassword(Context context, EditText etPassword) {
        String temp = etPassword.getText().toString();

        if (temp.length() > 0 && isEditTextEmpty(etPassword)) {
//			showMessage(context, context.getResources().getString(R.string.v_password_valid));
            return false;
        }
        return !isEditTextEmpty(etPassword);
    }


    public static boolean isValidPhoneNumber(String target) {
//
//        if (target.length() < 8) {
//            return false;
//        } else {
//            return android.util.Patterns.PHONE.matcher(target).matches();
//        }
        return target.length() >= 10 || target.length() <= 15;
    }


    public static boolean isValidSetCovers(String setCovers) {
        if (setCovers != null && setCovers.length() > 0) {
            int seats = Integer.parseInt(setCovers);
            if (seats == 0) {
                return false;
            } else return seats <= 18;
        } else {
            return false;
        }
    }

    /**
     * It will return Date string according to given timestamp and Date format
     * Inputs:
     * 1. Timestamp
     * 2. Require Date Format
     * Output: Date String
     */
    public static String getDateFromTimestamp(long timestamp, String DateFormate) {

        Locale locale = new Locale("en");
        Locale.setDefault(locale);

        if (timestamp < 1000000000000L) {
            timestamp *= 1000;
        }

        SimpleDateFormat sdf = new SimpleDateFormat(DateFormate);
        sdf.setTimeZone(TimeZone.getDefault());
        if (timestamp > 0) {
            Date milidate = new Date(timestamp);
            return sdf.format(milidate);
        } else {
            return "";
        }
    }

    public static String getDateFromTimestampUTC(long timestamp, String DateFormate) {

        if (timestamp < 1000000000000L) {
            timestamp *= 1000;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(DateFormate);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        if (timestamp > 0) {
            Date milidate = new Date(timestamp);
            return sdf.format(milidate);
        } else {
            return "";
        }
    }


    /**
     * It will return Date string according to given timestamp and Date format
     * Inputs:
     * 1. Timestamp
     * 2. Require Time Format
     * Output: Time String
     */
    public static String getTime(long timestamp, String TimeFormat) {
        String time = "";
        SimpleDateFormat formatter = new SimpleDateFormat(TimeFormat);
        time = formatter.format(new Date(timestamp));
        return time;
    }

    public static long getUTCFromTimestamp(long timestamp) {
        if (timestamp < 1000000000000L) {
            timestamp *= 1000;
        }

        Date localTime = new Date(timestamp);

        SimpleDateFormat sdfLocal = new SimpleDateFormat("yyyy/MMM/dd HH:mm:ss");
        sdfLocal.setTimeZone(TimeZone.getDefault());

        SimpleDateFormat sdfUTC = new SimpleDateFormat("yyyy/MMM/dd HH:mm:ss");
        sdfUTC.setTimeZone(TimeZone.getTimeZone("UTC"));

        // Convert Local Time to UTC
        Date utcTime = null;
        try {
            utcTime = sdfLocal.parse(sdfUTC.format(localTime));
            System.out.println("Local:" + localTime.toString() + "," + localTime.getTime() + " --> UTC time:" + utcTime.toString() + "-" + utcTime.getTime());
        } catch (ParseException | NullPointerException e) {
            e.printStackTrace();
        }


        return utcTime != null ? utcTime.getTime() : timestamp;
    }


//    public static String ddMMMyyyy(long secondsTime) {
//        TimeZone tz = TimeZone.getTimeZone(TimeZone.getDefault().getID());
//        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
//        cal.setTimeZone(tz);
//        cal.setTimeInMillis(secondsTime * 1000L);
//        return android.text.format.DateFormat.format(Date_Format, cal).toString();
//    }
//
//    public static long getTime_TimeStampFromTimeStamp(long timestamp) {
//        return getTime_TimeStampFromTimeStamp(timestamp, TimeFormat);
//    }

    public static long getTime_TimeStampFromTimeStamp(long timestamp, String format) {
        long time;
        String strtime = "";
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        strtime = formatter.format(new Date(timestamp));
        long hour = Long.parseLong(strtime.split(":")[0]);
        long min = Long.parseLong(strtime.split(":")[1]);

        time = (hour * 60 * 60) + (min * 60);
        return time;
    }

    public static long getDateFromTimeStamp(long timestamp) {

        java.text.DateFormat formatter = new SimpleDateFormat(Date_Format);
        Date mDate = null;
        try {
            mDate = formatter.parse(getDate(timestamp));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        assert mDate != null;
        return mDate.getTime();
    }

    public static String getDate(long timestamp) {
        String date = "";
        SimpleDateFormat formatter = new SimpleDateFormat(DateFormat);
        date = formatter.format(new Date(timestamp));
        return date;
    }

    public static String getUTCDate(long timestamp) {
        return getUTCDate(timestamp, "dd-MM-yyyy");
    }

    public static String getUTCDate(long timestamp, String DateFormat) {
        String date = "";
        SimpleDateFormat formatter = new SimpleDateFormat(DateFormat);
        formatter.setTimeZone(TimeZone.getTimeZone("GMT"));
        date = formatter.format(new Date(timestamp));
        return date;
    }

    public static String ddMMMyyyy(long secondsTime) {
        TimeZone tz = TimeZone.getTimeZone(TimeZone.getDefault().getID());
        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
        cal.setTimeZone(tz);
        cal.setTimeInMillis(secondsTime * 1000L);
        return android.text.format.DateFormat.format(Date_Format, cal).toString();
    }

}
