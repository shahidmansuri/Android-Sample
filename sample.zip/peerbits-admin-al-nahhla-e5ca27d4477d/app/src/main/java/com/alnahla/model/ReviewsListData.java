package com.alnahla.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Awesome Pojo Generator
 */
public class ReviewsListData {
    @SerializedName("date")
    @Expose
    private String date;
    @SerializedName("review_id")
    @Expose
    private String review_id;
    @SerializedName("rate")
    @Expose
    private String rate;
    @SerializedName("review_description")
    @Expose
    private String review_description;

    public void setDate(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }

    public void setReview_id(String review_id) {
        this.review_id = review_id;
    }

    public String getReview_id() {
        return review_id;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getRate() {
        return rate;
    }

    public void setReview_description(String review_description) {
        this.review_description = review_description;
    }

    public String getReview_description() {
        return review_description;
    }
}