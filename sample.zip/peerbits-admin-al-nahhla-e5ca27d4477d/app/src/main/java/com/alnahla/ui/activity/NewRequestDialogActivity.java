package com.alnahla.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;

import com.alnahla.AppConstants;
import com.alnahla.R;
import com.alnahla.databinding.ActivityNewRequestDialogBinding;
import com.alnahla.model.GoogleMapModel;
import com.alnahla.model.login.Order_details;
import com.alnahla.model.login.Restaurant_details;
import com.alnahla.service.RingtonePlayingService;
import com.alnahla.ui.BaseActivity;
import com.alnahla.utils.Constants;
import com.alnahla.utils.Utils;
import com.alnahla.utils.pref.IntentConstants;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.jay.googlelocation.Globle.GoogleDistanceAPI;
import com.jay.googlelocation.LocationFetcher;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class NewRequestDialogActivity extends BaseActivity implements View.OnClickListener, OnMapReadyCallback {

    private final int LOC_FETCH = 0;
    private static final int ORDER_CANCEL_CODE = 1;
    private static final String TAG = NewRequestDialogActivity.class.getSimpleName();
    private ActivityNewRequestDialogBinding mBinding;

    private double dbDriverLat = 0.0, dbDriverLng = 0.0, dbRestLat = 0.0, dbRestLng = 0.0;
    private Order_details orderDetailsCurr;
    private MarkerOptions markerOptions;
    private Marker markerMap;
    private int intProgress = 0;
    private CountDownTimer mCountDownTimer;
    private SupportMapFragment supportMapFragment;
    private GoogleMapModel googleMapModel;
    private GoogleMap googleMap;
    private Restaurant_details restaurant_details;
    private boolean isLocUpdatedInMap = false;
    private String etaFromAPI;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_new_request_dialog);

        /*
            To prevent closing activity ( dialog ) on outside press
         */
        this.setFinishOnTouchOutside(false);

        init();
        setListeners();
        setValues();
        setProgressBar();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case LOC_FETCH:
                if (resultCode == Activity.RESULT_OK) {
                    if (data.getIntExtra(com.jay.googlelocation.Globle.Constants.PERMISSION, com.jay.googlelocation.Globle.Constants.DENIED) == com.jay.googlelocation.Globle.Constants.GRANTED) {
                        dbDriverLat = data.getDoubleExtra(com.jay.googlelocation.Globle.Constants.LATITUDE, 0.0);
                        dbDriverLng = data.getDoubleExtra(com.jay.googlelocation.Globle.Constants.LONGITUDE, 0.0);
                        if (markerOptions != null) {
                            markerOptions.position(new LatLng(dbDriverLat, dbDriverLng));
                        }
                        callGoogleApi();
                    } else {
                    }
                }
                break;

            case ORDER_CANCEL_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    int resData = data.getIntExtra(IntentConstants.REQUEST_STATUS, com.alnahla.utils.Constants.DEFAULT_ORDER_STATUS);
                    int reasonID = data.getIntExtra(IntentConstants.REASON_ID, AppConstants.NO_VALUE_SET);
                    String othersComment = data.getStringExtra(IntentConstants.OTHERS_COMMENT);

                    if (resData == com.alnahla.utils.Constants.ORDER_CANCEL) {
                        /*
                            Order Rejected, call api
                         */
                        sendFeedback(Constants.ORDER_CANCEL, othersComment, reasonID);
//                        updateOrderStatus(AppConstants.REJECTED, reasonID, othersComment,AppConstants.NO_VALUE_SET_STRING);

                    } else if (resData == com.alnahla.utils.Constants.ORDER_CANCEL_REJECTED) {

                    }
                }
                break;
        }
    }


    private void setProgressBar() {
        mBinding.progressBar.setProgress(intProgress);
        mCountDownTimer = new CountDownTimer(60000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                intProgress++;
                mBinding.progressBar.setProgress(59 - (int) intProgress * 59 / (60000 / 1000));
                mBinding.tvSec.setText(hmsTimeFormatter(millisUntilFinished));
            }

            @Override
            public void onFinish() {
                 /*
                    Stopping the ringtone service
                  */
                stopService(new Intent(NewRequestDialogActivity.this, RingtonePlayingService.class));

                sendFeedback(Constants.ORDER_SKIPPED, AppConstants.NO_VALUE_SET_STRING, AppConstants.NO_VALUE_SET);
            }
        }.start();
    }

    private String hmsTimeFormatter(long millisUntilFinished) {
        String hms = String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) - TimeUnit.HOURS.toMinutes(
                TimeUnit.MILLISECONDS.toHours(millisUntilFinished)), TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished)));

        return hms;
    }

    private void setValues() {
        if (restaurant_details != null) {
            if (restaurant_details.getRestaurant_address() != null)
                mBinding.tvRestAddress.setText(restaurant_details.getRestaurant_address());
            if (restaurant_details.getRestaurant_name() != null)
                mBinding.tvRestName.setText(restaurant_details.getRestaurant_name());
            if (restaurant_details.getRestaurant_image() != null) {
                glideLoader.loadImageSimple(restaurant_details.getRestaurant_image(), mBinding.ivRest);
            }
        }

    }

    public static void launch(Activity activity, boolean isFinishActivity, double drivLat, double drivLng, Order_details orderDetailsCurr, int reqCode) {
        Intent intent = new Intent(activity, NewRequestDialogActivity.class);
        intent.putExtra(IntentConstants.DRIVER_LNG, drivLng);
        intent.putExtra(IntentConstants.DRIVER_LAT, drivLat);
        intent.putExtra(IntentConstants.ORDER_DETAILS, orderDetailsCurr);
        if (isFinishActivity) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        }
        activity.startActivityForResult(intent, reqCode);
        activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    private void init() {
        etaFromAPI = AppConstants.NO_VALUE_SET_STRING;
        supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        supportMapFragment.getMapAsync(this);

        markerOptions = new MarkerOptions();

        dbDriverLat = getIntent().getDoubleExtra(IntentConstants.DRIVER_LAT, Constants.DEFAULT_LAT);
        dbDriverLng = getIntent().getDoubleExtra(IntentConstants.DRIVER_LNG, Constants.DEFAULT_LNG);
        orderDetailsCurr = (Order_details) getIntent().getSerializableExtra(IntentConstants.ORDER_DETAILS);
        if (orderDetailsCurr != null && orderDetailsCurr.getRestaurant_details() != null) {
            restaurant_details = orderDetailsCurr.getRestaurant_details();
            dbRestLng = restaurant_details.getRestaurant_longitude();
            dbRestLat = restaurant_details.getRestaurant_latitude();
        }
        googleMapModel = new GoogleMapModel();
        if (dbDriverLng == 0.0 && dbDriverLat == 0.0) {
            getCurrentLocation();
        } else {
            callGoogleApi();
        }
    }

    private void setListeners() {
        mBinding.tvAccept.setOnClickListener(this);
        mBinding.tvHelpMe.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tvAccept:
//                OrderActivity.launch(NewRequestDialogActivity.this,false,dbDriverLat,dbDriverLng,intOrderID);
                /*
                    Stopping the ringtone service
                 */
                stopService(new Intent(this,RingtonePlayingService.class));

                sendFeedback(Constants.ORDER_ACCEPT, AppConstants.NO_VALUE_SET_STRING, AppConstants.NO_VALUE_SET);

                break;

            case R.id.tvHelpMe:
                /*
                    Stopping the ringtone service
                 */
                stopService(new Intent(this,RingtonePlayingService.class));

                OrderCancelActivity.launch(this, false, ORDER_CANCEL_CODE);

//                sendFeedback(Constants.ORDER_CANCEL);
                break;
        }
    }

    private void sendFeedback(int reqStatus, String otherComments, int reasonID) {
        Intent resultIntent = new Intent();
        resultIntent.putExtra(IntentConstants.REQUEST_STATUS, reqStatus);
        resultIntent.putExtra(IntentConstants.OTHERS_COMMENT, otherComments);
        resultIntent.putExtra(IntentConstants.REASON_ID, reasonID);
        resultIntent.putExtra(IntentConstants.ETA, etaFromAPI);
        setResult(Activity.RESULT_OK, resultIntent);
        finish();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap = googleMap;
        googleMap.getUiSettings().setZoomControlsEnabled(false);
        googleMap.setMinZoomPreference(6.0f);
        showDriverLocInMap();
    }

    private void showDriverLocInMap() {

        // googleMap.getUiSettings().setAllGesturesEnabled(false);
        if (!isLocUpdatedInMap && googleMap != null && dbDriverLng != 0.0 && dbDriverLat != 0.0) {
            LatLng latLng = new LatLng(dbDriverLat, dbDriverLng);

            // Showing the current location in Google Map
            googleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));

            // Zoom in the Google Map
            googleMap.animateCamera(CameraUpdateFactory.zoomTo(15));

            BitmapDescriptor bitmapDescriptor = BitmapDescriptorFactory.fromResource(R.drawable.ic_map_new_req);

            markerOptions.position(latLng);
            // markerOptions.title(String.valueOf(intTimer));
            markerOptions.icon(bitmapDescriptor);

            markerMap = googleMap.addMarker(markerOptions);
            markerMap.showInfoWindow();
            isLocUpdatedInMap = true;
        }
    }

    private void callGoogleApi() {
        showDriverLocInMap();
        if (dbDriverLat != 0.0 && dbDriverLng != 0.0 && dbRestLat != 0.0 && dbRestLng != 0.0) {
            String googleApiKey = getResources().getString(R.string.key_google_client);
            GoogleDistanceAPI googleDistanceAPI = new GoogleDistanceAPI();


            googleDistanceAPI.getDirectionDetails(dbDriverLat, dbDriverLng, dbRestLat, dbRestLng, googleApiKey, this, new GoogleDistanceAPI.GoogleDistance() {
                @Override
                public void onResult(String distance, String time, ArrayList<LatLng> route) {
                    // in meters
                    googleMapModel.setStrDistance(distance);
                    mBinding.tvDistance.setText(Utils.getMilesFromMeters(distance));
                    //in Seconds
                    etaFromAPI = Utils.getMinFromSec(time);
                    googleMapModel.setStrTiming(time);
                    mBinding.tvTime.setText(etaFromAPI);
                    googleMapModel.setMapRoute(route);

                }

            });
        }
    }

    private void getCurrentLocation() {
        /*
            Here we are using external library to get current location
         */

        Intent intent_location = new Intent(this, LocationFetcher.class);
        intent_location.putExtra(com.jay.googlelocation.Globle.Constants.TYPE, com.jay.googlelocation.Globle.Constants.LOCATION_FETCH);
        startActivityForResult(intent_location, LOC_FETCH);
    }

    @Override
    public void onBackPressed() {
        /*
            We have overridden this method so that we can prevent the user from pressing back button
         */
    }
}
