package com.alnahla.ui.fragments;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.databinding.DataBindingUtil;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.BottomSheetBehavior.BottomSheetCallback;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.alnahla.AppConstants;
import com.alnahla.AppStrings;
import com.alnahla.R;
import com.alnahla.databinding.FragmentEarningBinding;
import com.alnahla.interfaces.InterfaceAPI;
import com.alnahla.model.EarningData;
import com.alnahla.model.Earning_details;
import com.alnahla.network.common_api.ApisCommon;
import com.alnahla.ui.BaseFragment;
import com.alnahla.ui.adapter.EarningAdapter;
import com.alnahla.widget.RelativeRadioGroup;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class EarningFragment extends BaseFragment implements View.OnClickListener {

    private FragmentEarningBinding mBinder;
    private BottomSheetBehavior bottomSheetBehavior;
    private boolean isLoading = false;
    // private boolean isFilterData = false;

    ArrayList<Earning_details> earningArrayList = new ArrayList<>();
    EarningData earningData;
    EarningAdapter earningAdapter;

    private TextView tvCurrency;
    private EditText etFromDate, etToDate;
    private RadioGroup rgPayment;
    private RadioButton rbPaymentSelect = null;
    private RadioButton rbOrderStatusSelect = null;
    private RelativeRadioGroup rgOrderStatus;

    private android.app.DatePickerDialog DateStartPickerDialog, DateEndPickerDialog;
    private String order_status = "", payment_type = "", start_date = "", end_date = "";

    private SimpleDateFormat dateFormatter;
    private Calendar newStartDate, newEndDate;
    ApisCommon apisCommon = new ApisCommon();
    boolean isFilterd = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (mBinder == null) {
            mBinder = DataBindingUtil.inflate(inflater, R.layout.fragment_earning, container, false);
            //setHasOptionsMenu(true);
        }

        init();
        setListners();

        return mBinder.getRoot();
    }

    private void setupRecyclerView() {

        mBinder.rvEarning.setLayoutManager(new LinearLayoutManager(mActivity));
        earningAdapter = new EarningAdapter(this, earningArrayList, mBinder.rvEarning);
        mBinder.rvEarning.setAdapter(earningAdapter);
    }

    private void init() {
        mBinder.getRoot().findViewById(R.id.bottom_sheet);
        bottomSheetBehavior = BottomSheetBehavior.from(mBinder.getRoot().findViewById(R.id.bottom_sheet));

        tvCurrency = mBinder.getRoot().findViewById(R.id.tvCurrency);

       /* Typeface typeface = Typeface.createFromAsset(mActivity.getAssets(), "fonts/ClanOT-NarrowMedium.otf");
        tvCurrency.setTypeface(typeface);*/

        etFromDate = mBinder.getRoot().findViewById(R.id.etFromDate);
        etToDate = mBinder.getRoot().findViewById(R.id.etToDate);

        rgPayment = mBinder.getRoot().findViewById(R.id.rgPayment);
        rgOrderStatus = mBinder.getRoot().findViewById(R.id.rgOrderStatus);

        bottomSheetCases();
        paymentSelection();
        orderStatusSelection();
        setStartDateTimeField();
        setEndDateTimeField();

        apiEarning();
        setupRecyclerView();
    }

    private void apiEarning() {
        mBinder.rvEarning.setVisibility(View.GONE);
        int intPayType = AppConstants.NO_VALUE_SET;
        int intOrderStatus = AppConstants.NO_VALUE_SET;

        if (payment_type.equalsIgnoreCase(AppStrings.TYPE_CASH)) {
            intPayType = AppConstants.CASH;
        } else if (payment_type.equalsIgnoreCase(AppStrings.TYPE_CARD)) {
            intPayType = AppConstants.CARD;
        }

        if (order_status.equalsIgnoreCase(AppStrings.DELIVERED)) {
            intOrderStatus = AppConstants.DELIVERED;
        } else if (order_status.equalsIgnoreCase(AppStrings.CANCEL_BY_ADMIN)) {
            intOrderStatus = AppConstants.CANCEL_BY_ADMIN;
        } else if (order_status.equalsIgnoreCase(AppStrings.CANCEL_BY_RESTAURENT)) {
            intOrderStatus = AppConstants.CANCEL_BY_RESTAURENT;
        }
        apisCommon.apiEarning(mContext, intPayType, intOrderStatus, start_date, end_date, new InterfaceAPI() {
            @Override
            public void onPreExecute() {
                showProgress();
            }

            @Override
            public void apiSuccessful(int statusCode, JSONObject jsonObject, String response) {
                stopProgress();
                isLoading = false;
                mBinder.rvEarning.setVisibility(View.VISIBLE);

                GsonBuilder gsonBuilder = new GsonBuilder();
                Gson gson = gsonBuilder.create();

                earningData = gson.fromJson(jsonObject.toString(), EarningData.class);

                if (earningData.getEarning_details().size() > 0) {
                    List<Earning_details> detailsList = earningData.getEarning_details();
                    List<Earning_details> detailsListDummy = new ArrayList<>();
                    detailsListDummy.addAll(detailsList);
                    if (getStart_date().equals("") || getEnd_date().equals("")) {
                        for (Earning_details earningDetails : detailsListDummy
                                ) {
                            if (earningDetails.getType() == AppConstants.TYPE_FILTERED) {
                                detailsList.remove(earningDetails);
                            }
                        }
                    }
                    earningAdapter.addAll(detailsList);
                    populateData();
                    showToolBar();
                    showStatusBar();
                }
            }
            @Override
            public void apiFailed(int statusCode,ArrayList<String> messages) {
                stopProgress();
                errorHandleFromApi(mActivity, messages,statusCode);
            }
        });
    }

    private void populateData() {
        if (earningArrayList.size() > 0) {
            mBinder.rvEarning.setVisibility(View.VISIBLE);
            mBinder.tvNoData.setVisibility(View.GONE);
        } else {
            mBinder.tvNoData.setVisibility(View.VISIBLE);
            mBinder.rvEarning.setVisibility(View.GONE);
        }
    }

    private void bottomSheetCases() {

        bottomSheetBehavior.setBottomSheetCallback(new BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                switch (newState) {
                    case BottomSheetBehavior.STATE_HIDDEN:
                        break;
                    case BottomSheetBehavior.STATE_EXPANDED:
                        break;
                    case BottomSheetBehavior.STATE_COLLAPSED:
                        break;
                    case BottomSheetBehavior.STATE_DRAGGING:
                        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                        break;
                    case BottomSheetBehavior.STATE_SETTLING:
                        break;
                }
            }

            @Override
            public void onSlide(@NonNull View view, float v) {

            }
        });
    }

    private void setListners() {
        mBinder.getRoot().findViewById(R.id.ivFilter).setOnClickListener(this);
        mBinder.getRoot().findViewById(R.id.ivClose).setOnClickListener(this);
        mBinder.getRoot().findViewById(R.id.btnApply).setOnClickListener(this);
        mBinder.getRoot().findViewById(R.id.tvReset).setOnClickListener(this);
        mBinder.getRoot().findViewById(R.id.etFromDate).setOnClickListener(this);
        mBinder.getRoot().findViewById(R.id.etToDate).setOnClickListener(this);
    }

    @SuppressLint("ResourceType")
    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.ivFilter:
                hideStatusBar();
                hideToolBar();
                mBinder.tvNoData.setVisibility(View.GONE);
                mBinder.getRoot().findViewById(R.id.ivFilter).setVisibility(View.GONE);
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                mBinder.rvEarning.setVisibility(View.GONE);
                toggleBottomSheet();
                break;

            case R.id.ivClose:
                showStatusBar();
                showToolBar();
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                mBinder.rvEarning.setVisibility(View.VISIBLE);
              //  mBinder.tvNoData.setVisibility(View.VISIBLE);
                mBinder.getRoot().findViewById(R.id.ivFilter).setVisibility(View.VISIBLE);
                break;

            case R.id.tvReset:
                showStatusBar();
                showToolBar();
                clearFilterData();
                apiEarning();
                // mBinder.rvEarning.setVisibility(View.VISIBLE);
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                mBinder.getRoot().findViewById(R.id.ivFilter).setVisibility(View.VISIBLE);
                break;

            case R.id.etFromDate:
                DateStartPickerDialog.show();
                etToDate.setText("");
                end_date = "";
                break;

            case R.id.etToDate:
                DateEndPickerDialog.show();
                break;

            case R.id.btnApply:
                if (isValid()) {
                  /*  start_date = etFromDate.getText().toString();
                    end_date = etToDate.getText().toString();*/

                    if (rbPaymentSelect != null)
                        payment_type = rbPaymentSelect.getText().toString();
                    if (rbOrderStatusSelect != null)
                        order_status = rbOrderStatusSelect.getText().toString();

                    apiEarning();

                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                    hideToolBar();
                    hideStatusBar();
                    mBinder.rvEarning.setVisibility(View.VISIBLE);
                    mBinder.getRoot().findViewById(R.id.ivFilter).setVisibility(View.VISIBLE);
                }

                break;
        }
    }

    /*private void clearFilterData() {
        clearData();
        showStatusBar();
        showToolBar();
        apiEarning();
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        mBinder.getRoot().findViewById(R.id.ivFilter).setVisibility(View.VISIBLE);

    }*/

    private void clearFilterData() {

        etFromDate.setText("");
        etToDate.setText("");

        start_date = "";
        end_date = "";

        payment_type = "";
        order_status = "";

        rgPayment.clearCheck();
        rgOrderStatus.clearCheck();

        setRadioButtonCheckUncheck(rbPaymentSelect, false);
        setRadioButtonCheckUncheck(rbOrderStatusSelect, false);
    }

    private boolean isValid() {
        boolean isValid = true;
        if (!start_date.equalsIgnoreCase(AppConstants.NO_VALUE_SET_STRING)) {
            if (end_date.equals("")) {
                showErrorSnackBar(getString(R.string.err_to_date));
                etToDate.requestFocus();
                isValid = false;
            }
        } else if (!end_date.equalsIgnoreCase(AppConstants.NO_VALUE_SET_STRING)) {
            if (start_date.equals("")) {
                showErrorSnackBar(getString(R.string.err_from_date));
                etFromDate.requestFocus();
                isValid = false;
            }
        }
        return isValid;
    }

    private void toggleBottomSheet() {
        if (bottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED &&
                bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_HIDDEN) {

            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);

        } else {
            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        }
    }

    private void paymentSelection() {

        rgPayment.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                RadioButton rb = group.findViewById(checkedId);

                setRadioButtonCheckUncheck(rbPaymentSelect, false);
                rbPaymentSelect = setRadioButtonCheckUncheck(rb, true);
            }
        });
    }

    private void orderStatusSelection() {

        rgOrderStatus.setOnCheckedChangeListener(new RelativeRadioGroup.OnCheckedChangeListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onCheckedChanged(RelativeRadioGroup group, int checkedId) {

                RadioButton rb = group.findViewById(checkedId);

                setRadioButtonCheckUncheck(rbOrderStatusSelect, false);
                rbOrderStatusSelect = setRadioButtonCheckUncheck(rb, true);
            }
        });
    }

    private RadioButton setRadioButtonCheckUncheck(RadioButton radioButton, boolean isCheck) {
        if (null != radioButton) {
            int rbDrawable = 0, rbStyle = 0;
            String fontPath = "fonts/";
            if (isCheck) {
                rbDrawable = R.drawable.bg_select_green;
                rbStyle = R.style.Button_Filter_Selected;
                fontPath = fontPath + getResources().getString(R.string.font_notobold);
            } else {
                rbDrawable = R.drawable.bg_unselect_grey;
                rbStyle = R.style.Button_Filter_Unselected;
                fontPath = fontPath + getResources().getString(R.string.font_notoRegular);
            }
            //  radioButton.setChecked(isCheck);
            radioButton.setBackground(ContextCompat.getDrawable(mActivity, rbDrawable));
            radioButton.setTextAppearance(mActivity, rbStyle);
            Typeface type = Typeface.createFromAsset(mActivity.getAssets(), fontPath);
            radioButton.setTypeface(type);
        }
        return radioButton;
    }


    private void setStartDateTimeField() {
        dateFormatter = new SimpleDateFormat(AppConstants.DATE_FORMAT, Locale.getDefault());
        final Calendar newCalendar = Calendar.getInstance();
        DateStartPickerDialog = new android.app.DatePickerDialog(mActivity, R.style.MyDatePickerDialogTheme, new android.app.DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                newStartDate = Calendar.getInstance();
                newStartDate.set(year, monthOfYear, dayOfMonth,0,0,0);
                etFromDate.setText(dateFormatter.format(newStartDate.getTime()));
                start_date = String.valueOf(newStartDate.getTimeInMillis());
                setEndDateTimeField();
                DateEndPickerDialog.getDatePicker().setMinDate(newStartDate.getTimeInMillis());
            }

        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        DateStartPickerDialog.setButton(DialogInterface.BUTTON_POSITIVE, getResources().getString(R.string.ok), DateStartPickerDialog);
        DateStartPickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE, getResources().getString(R.string.str_cancel), DateStartPickerDialog);
    }

    private void setEndDateTimeField() {
        dateFormatter = new SimpleDateFormat(AppConstants.DATE_FORMAT, Locale.US);
        final Calendar newCalendar = Calendar.getInstance();
        DateEndPickerDialog = new android.app.DatePickerDialog(mActivity, R.style.MyDatePickerDialogTheme, new android.app.DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                newEndDate = Calendar.getInstance();
                newEndDate.set(year, monthOfYear, dayOfMonth,23,59,59);
                etToDate.setText(dateFormatter.format(newEndDate.getTime()));
                end_date = String.valueOf(newEndDate.getTimeInMillis());
            }

        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        DateEndPickerDialog.setButton(DialogInterface.BUTTON_POSITIVE, getResources().getString(R.string.ok), DateEndPickerDialog);
        DateEndPickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE, getResources().getString(R.string.str_cancel), DateEndPickerDialog);
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }
}
