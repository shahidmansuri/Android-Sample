package com.alnahla.model.newtoken;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
/**
 * Awesome Pojo Generator
 * */
public class User_info{
  @SerializedName("phone_no")
  @Expose
  private Integer phone_no;
  @SerializedName("image")
  @Expose
  private String image;
  @SerializedName("full_name")
  @Expose
  private String full_name;
  @SerializedName("mobile_verified")
  @Expose
  private Integer mobile_verified;
  @SerializedName("dial_code")
  @Expose
  private Integer dial_code;
  @SerializedName("id")
  @Expose
  private Integer id;
  @SerializedName("is_online")
  @Expose
  private Integer is_online;
  public void setPhone_no(Integer phone_no){
   this.phone_no=phone_no;
  }
  public Integer getPhone_no(){
   return phone_no;
  }
  public void setImage(String image){
   this.image=image;
  }
  public String getImage(){
   return image;
  }
  public void setFull_name(String full_name){
   this.full_name=full_name;
  }
  public String getFull_name(){
   return full_name;
  }
  public void setMobile_verified(Integer mobile_verified){
   this.mobile_verified=mobile_verified;
  }
  public Integer getMobile_verified(){
   return mobile_verified;
  }
  public void setDial_code(Integer dial_code){
   this.dial_code=dial_code;
  }
  public Integer getDial_code(){
   return dial_code;
  }
  public void setId(Integer id){
   this.id=id;
  }
  public Integer getId(){
   return id;
  }
  public void setIs_online(Integer is_online){
   this.is_online=is_online;
  }
  public Integer getIs_online(){
   return is_online;
  }
}