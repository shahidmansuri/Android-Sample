package com.alnahla.model.login;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Awesome Pojo Generator
 * */
public class Restaurant_details implements Serializable {
  @SerializedName("restaurant_image")
  @Expose
  private String restaurant_image;
  @SerializedName("restaurant_latitude")
  @Expose
  private Double restaurant_latitude;
  @SerializedName("restaurant_longitude")
  @Expose
  private Double restaurant_longitude;
  @SerializedName("restaurant_address")
  @Expose
  private String restaurant_address;
  @SerializedName("restaurant_name")
  @Expose
  private String restaurant_name;
  public void setRestaurant_image(String restaurant_image){
   this.restaurant_image=restaurant_image;
  }
  public String getRestaurant_image(){
   return restaurant_image;
  }
  public void setRestaurant_latitude(Double restaurant_latitude){
   this.restaurant_latitude=restaurant_latitude;
  }
  public Double getRestaurant_latitude(){
   return restaurant_latitude;
  }
  public void setRestaurant_longitude(Double restaurant_longitude){
   this.restaurant_longitude=restaurant_longitude;
  }
  public Double getRestaurant_longitude(){
   return restaurant_longitude;
  }
  public void setRestaurant_address(String restaurant_address){
   this.restaurant_address=restaurant_address;
  }
  public String getRestaurant_address(){
   return restaurant_address;
  }
  public void setRestaurant_name(String restaurant_name){
   this.restaurant_name=restaurant_name;
  }
  public String getRestaurant_name(){
   return restaurant_name;
  }
}