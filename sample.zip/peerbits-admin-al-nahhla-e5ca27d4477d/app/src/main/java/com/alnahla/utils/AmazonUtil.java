/*
 * Copyright 2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package com.alnahla.utils;

import android.content.Context;

import com.alnahla.AppConstants;
import com.alnahla.R;
import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferType;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.CannedAccessControlList;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
 * Handles basic helper functions used throughout the app.
 */
public class AmazonUtil {

    private TransferUtility transferUtility;
    private TransferListener transferListener;
    private ArrayList<HashMap<String, Object>> transferRecordMaps;
    private String urlS3 = "";

    public interface AWSInterface {
        public void inProgress();
        public void completed();
        public void failed();

    }
    private AWSInterface awsInterface;
    /**
     * Gets an instance of the TransferUtility which is constructed using the
     * given Context
     *
     * @param context
     * @return a TransferUtility instance
     */
    public static TransferUtility getTransferUtility(Context context) {
        if (sTransferUtility == null) {
            sTransferUtility = new TransferUtility(getS3Client(context.getApplicationContext()),
                    context.getApplicationContext());
        }

        return sTransferUtility;
    }

    // We only need one instance of the clients and credentials provider
    private static AmazonS3Client sS3Client;
    private static CognitoCachingCredentialsProvider sCredProvider;
    private static TransferUtility sTransferUtility;

    /**
     * Gets an instance of a S3 client which is constructed using the given
     * Context.
     *
     * @param context An Context instance.
     * @return A default S3 client.
     */
    public static AmazonS3Client getS3Client(Context context) {
        if (sS3Client == null) {
            sS3Client = new AmazonS3Client(getCredProvider(context.getApplicationContext()));
        }
        return sS3Client;
    }

    /**
     * Gets an instance of CognitoCachingCredentialsProvider which is
     * constructed using the given Context.
     *
     * @param context An Context instance.
     * @return A default credential provider.
     */
    private static CognitoCachingCredentialsProvider getCredProvider(Context context) {
        if (sCredProvider == null) {
            sCredProvider = new CognitoCachingCredentialsProvider(
                    context.getApplicationContext(),
                    AppConstants.COGNITO_POOL_ID,
                    Regions.AP_SOUTH_1);
        }
        return sCredProvider;
    }

    public static void fillMap(Map<String, Object> map, TransferObserver observer, boolean isChecked) {
        int progress = (int) ((double) observer.getBytesTransferred() * 100 / observer
                .getBytesTotal());
        map.put("id", observer.getId());
        map.put("checked", isChecked);
        map.put("fileName", observer.getAbsoluteFilePath());
        map.put("progress", progress);
        map.put("bytes",
                getBytesString(observer.getBytesTransferred()) + "/"
                        + getBytesString(observer.getBytesTotal()));
        map.put("state", observer.getState());
        map.put("percentage", progress + "%");
    }

    private static String getBytesString(long bytes) {
        String[] quantifiers = new String[]{
                "KB", "MB", "GB", "TB"
        };
        double speedNum = bytes;
        for (int i = 0; ; i++) {
            if (i >= quantifiers.length) {
                return "";
            }
            speedNum /= 1024;
            if (speedNum < 512) {
                return String.format("%.2f", speedNum) + " " + quantifiers[i];
            }
        }
    }

    /*

        Initially, call this method to initialize aws s3 bucket.

     */
    public void initBucket(Context context,AWSInterface aws) {
        final AWSInterface awsInterface = aws;

        transferUtility = AmazonUtil.getTransferUtility(context);
        transferRecordMaps = new ArrayList<>();
        transferListener = new TransferListener() {
            @Override
            public void onStateChanged(int id, TransferState state) {
                switch (state) {
                    case IN_PROGRESS:
                        if(awsInterface!=null){
                            awsInterface.inProgress();
                        }
                        break;
                    case COMPLETED:
                        if(awsInterface!=null){
                            awsInterface.completed();
                        }
                        break;
                    case FAILED:
                        if(awsInterface!=null){
                            awsInterface.failed();
                        }
                        break;
                }
            }

            @Override
            public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
            }

            @Override
            public void onError(int id, Exception ex) {

            }
        };
        transferRecordMaps.clear();
    }
    /*

        Whenver want tp upload any file,

     */
    public void beginUpload(String filePath) {
        File file = new File(filePath);
        transferUtility.upload(AppConstants.BUCKET_NAME, file.getName(),
                file, CannedAccessControlList.PublicRead);
        urlS3 = getAWSUrl(AppConstants.BUCKET_NAME, file.getName());
        List<TransferObserver> observersForUpload = transferUtility.getTransfersWithType(TransferType.UPLOAD);
        for (TransferObserver observer : observersForUpload) {
            HashMap<String, Object> map = new HashMap<String, Object>();
            AmazonUtil.fillMap(map, observer, false);
            transferRecordMaps.add(map);
            observer.setTransferListener(transferListener);
        }
    }

    public String getAWSUrl(String bucketName, String fileName) {
        return "https://" + bucketName + ".s3.amazonaws.com/" + fileName;
    }

}
