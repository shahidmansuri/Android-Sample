package com.alnahla.service;

import android.app.IntentService;
import android.content.Intent;

import com.alnahla.AppConstants;
import com.alnahla.AppStrings;
import com.alnahla.utils.pref.IntentConstants;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingEvent;
import com.jay.googlelocation.Globle.Constants;

import java.util.List;

public class GeofenceTransitionsIntentService extends IntentService {
    public GeofenceTransitionsIntentService(){
        super("");

    }
    public GeofenceTransitionsIntentService(String name) {
        super(name);
    }

    protected void onHandleIntent(Intent intent) {
        GeofencingEvent geofencingEvent = GeofencingEvent.fromIntent(intent);
        if (geofencingEvent.hasError()) {

            return;
        }

        // Get the transition type.
        int geofenceTransition = geofencingEvent.getGeofenceTransition();

        // Test that the reported transition was of interest.
        if (geofenceTransition == Geofence.GEOFENCE_TRANSITION_ENTER) {

            // Get the geofences that were triggered. A single event can trigger
            // multiple geofences.
            List<Geofence> triggeringGeofences = geofencingEvent.getTriggeringGeofences();
            if(triggeringGeofences!=null && triggeringGeofences.size()>0)
                sendUpdate(triggeringGeofences.get(0).getRequestId());
            // Send notification and log the transition details.

        } else {

        }
    }

    private void sendUpdate(String reqID){
        Intent intent = new Intent(AppStrings.BROADCAST_KEY_ALARM_GEOFENCING);
        intent.putExtra(IntentConstants.GEO_FENCING_REQID,reqID);
        getApplicationContext().sendBroadcast(intent);
    }
}
