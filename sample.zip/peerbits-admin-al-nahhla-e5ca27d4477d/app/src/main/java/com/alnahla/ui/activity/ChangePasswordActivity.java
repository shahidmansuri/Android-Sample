package com.alnahla.ui.activity;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;

import com.alnahla.R;
import com.alnahla.databinding.ActivityChangePasswordBinding;
import com.alnahla.network.API_CONSTANTS;
import com.alnahla.network.API_EndPoints;
import com.alnahla.network.NetworkCall;
import com.alnahla.network.listeners.RetrofitResponseListener;
import com.alnahla.ui.BaseActivity;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class ChangePasswordActivity extends BaseActivity implements View.OnClickListener {
    ActivityChangePasswordBinding mBinder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinder = DataBindingUtil.setContentView(this, R.layout.activity_change_password);
        setStatusBarColor(this, getResources().getColor(R.color.status_color_green));
        setUpToolBar();
        setOnClickListener();
    }

    private void setUpToolBar() {
        mBinder.included.title.setText(getString(R.string.change_password));
        mBinder.included.toolbar.setNavigationIcon(R.drawable.ic_back_arrow_white);
        mBinder.included.toolbar.setNavigationOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void setOnClickListener() {
        mBinder.btnSave.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnSave:
                validationForChangePasswordApi();
        }

    }

    private void validationForChangePasswordApi() {
        String oldPassword = mBinder.etOldPassword.getText().toString().trim();
        String newPassword = mBinder.etNewPassword.getText().toString().trim();
        String confirmPassword = mBinder.etConfirmPassword.getText().toString().trim();

        if (TextUtils.isEmpty(oldPassword)) {
            showErrorSnackBar(getResources().getString(R.string.err_enterOldPass));
            mBinder.etOldPassword.requestFocus();
        }else if (TextUtils.isEmpty(newPassword)) {
            showErrorSnackBar(getResources().getString(R.string.err_enterNewPass));
            mBinder.etNewPassword.requestFocus();
        }else if (TextUtils.isEmpty(confirmPassword)) {
            showErrorSnackBar(getResources().getString(R.string.err_enterConfirmPass));
            mBinder.etConfirmPassword.requestFocus();
        }else if (!newPassword.equals(confirmPassword)) {
            showErrorSnackBar(getResources().getString(R.string.err_passMisMatch));
            mBinder.etConfirmPassword.requestFocus();
        } else {
            ChangePasswordApi(oldPassword, newPassword);
        }

    }

    private void ChangePasswordApi(String oldPassword, String newPassword) {
        HashMap<String, String> params = new HashMap<>();
        params.put(API_CONSTANTS.OLD_PASS, oldPassword);
        params.put(API_CONSTANTS.NEW_PASS, newPassword);

        NetworkCall.with(this)
                .setEndPoint(API_EndPoints.CHANGE_PASSWORD)
                .setRequestParams(params)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                        showProgress();
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        stopProgress();
                        showSnackBar(jsonObject.optString(API_CONSTANTS.MESSAGE));
                        finish();
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        stopProgress();
                        errorHandleFromApi(messages,statusCode);

                    }
                }).makeCall();
    }

}
