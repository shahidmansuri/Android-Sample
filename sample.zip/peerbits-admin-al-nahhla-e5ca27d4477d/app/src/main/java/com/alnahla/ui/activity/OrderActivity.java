package com.alnahla.ui.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.databinding.DataBindingUtil;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.alnahla.AppAlarmManager;
import com.alnahla.AppConstants;
import com.alnahla.AppStrings;
import com.alnahla.R;
import com.alnahla.databinding.ActivityOrderBinding;
import com.alnahla.databinding.ItemOrderStatusBinding;
import com.alnahla.databinding.ItemOrderitemsBinding;
import com.alnahla.eventbus.MessageEvent;
import com.alnahla.interfaces.InterfaceAPI;
import com.alnahla.model.order_detais.Customer_details;
import com.alnahla.model.order_detais.Data;
import com.alnahla.model.order_detais.Order_details;
import com.alnahla.model.order_detais.Order_items;
import com.alnahla.model.order_detais.Order_status;
import com.alnahla.model.order_detais.Restaurant_details;
import com.alnahla.network.API_CONSTANTS;
import com.alnahla.network.API_EndPoints;
import com.alnahla.network.NetworkCall;
import com.alnahla.network.common_api.ApisCommon;
import com.alnahla.network.listeners.RetrofitResponseListener;
import com.alnahla.service.GeofenceTransitionsIntentService;
import com.alnahla.ui.BaseActivity;
import com.alnahla.ui.dialog.MessageDialog;
import com.alnahla.utils.Constants;
import com.alnahla.utils.Utils;
import com.alnahla.utils.pref.IntentConstants;
import com.alnahla.utils.pref.PreferenceKeys;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingClient;
import com.google.android.gms.location.GeofencingRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jay.googlelocation.Globle.GoogleDistanceAPI;
import com.jay.googlelocation.LocationService;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.alnahla.AppConstants.ARRIVED_TO_RESTAURANT;

public class OrderActivity extends BaseActivity implements OnMapReadyCallback, View.OnClickListener {
    private ActivityOrderBinding mBinding;
    private String strOrderID, contactToCall;
    private int intIsOrderRunning, intCurrentOrderStatus;

    private SupportMapFragment supportMapFragment;

    private GoogleMap googleMap;

    private final int DRIVER_REST = 0;
    private final int REST_CLIENT = 1;
    private final int CALL_SETTING = 3;
    private double dbDriverLat = 0.0, dbDriverLng = 0.0;
    private double dbClientLat = 0.0, dbClientLng = 0.0;
    private double dbRestLat = 0.0, dbRestLng = 0.0;
    private String clientName = "", clientAddress = "", clientImage = "";

    private Order_details orderDetails;
    private ArrayList<Order_status> orderStatuses;
    //Order Status Updation
    ItemOrderStatusBinding mBinderArrived = null;
    ItemOrderStatusBinding mBinderPickup = null, mBinderDelivered = null, mBinderTakePayment = null, mBinderOrderCancelled = null, mBinderLast = null, mBinderCurrent = null;

    private MyLocationReceiver myLocationReceiver;
    private MyGeoFencingDetails myGeoFencingDetails;

    private Intent intent_locationService;

    private AppAlarmManager appAlarmManager;
    private AlarmTimeNotification alarmTimeNotification;

    private boolean isLocFirstTime = false;

    private Marker markerStartingPoint, markerEndPoint;
    /*
        For GeoFencing
     */
    private GeofencingClient geofencingClient;
    private ArrayList<Geofence> mGeofenceList;
    private String REQ_ID_REST = "restGeoFencing";
    private String REQ_ID_CLIENT = "clientGeoFencing";

    private PendingIntent mGeofencePendingIntent;

    private boolean isComeFromOrderHistory = false;

    private String callPermission = Manifest.permission.CALL_PHONE;
    private static final int ORDER_CANCEL_CODE = 1;
    private ApisCommon apisCommon;
    private String etaFromAPI, estDistanceFromAPI;

    private int lastUpdatedStatus;

    public static OrderActivity orderActivity;
    /*
        If user comed from order history, we have some logic changes
     */
    private GoogleDistanceAPI googleDistanceAPI;
    private String googleApiKey;
    private String notyType;

    /*
        To tackle double click on buttons, we can define booleans
     */
    boolean isArrivedClicked = false, isPickUpClicked = false, isDeliveredClicked = false, isTakePaymentClicked = false;

    public static void launch(Activity activity, boolean isFinishActivity, double drivLat, double drivLng, int orderID, int reqCode, boolean isComeFromOrderHistory, Order_details order_details, String notificationType) {
        Intent intent = new Intent(activity, OrderActivity.class);
        intent.putExtra(IntentConstants.DRIVER_LNG, drivLng);
        intent.putExtra(IntentConstants.DRIVER_LAT, drivLat);
        intent.putExtra(IntentConstants.ORDER_ID, orderID);
        intent.putExtra(IntentConstants.FROM_ORDERHISTORY, isComeFromOrderHistory);
        intent.putExtra(IntentConstants.NOTY_TYPE, notificationType);

        if (order_details != null)
            intent.putExtra(IntentConstants.ORDER_DETAILS, order_details);

        if (isFinishActivity) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        }
        activity.startActivityForResult(intent, reqCode);
        activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /*
            Sometimes, it do happen that, on finish() call, this activity calls again. So we are checking and if so,
            calling sendFeedback() again to move to previous activity
         */
        if (session.getFlagFromKey(PreferenceKeys.KEY_SENDFEEDBACK)) {
            sendFeedback(AppConstants.COMPLETED);
        } else {
            mBinding = DataBindingUtil.setContentView(this, R.layout.activity_order);
            init();
            setClickListeners();
            setUpUi();
            checkIfCameFromOrderHistory();
            setRestToCustomerLayout();
        }
    }

    /*

        Override methods and callbacks (public or private)

     */

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap = googleMap;

        this.googleMap.getUiSettings().setZoomControlsEnabled(true);
        this.googleMap.setMinZoomPreference(Constants.MAP_ZOOM_PREF);

        // showing current location
        LatLng currLoc = new LatLng(dbDriverLat, dbDriverLng);
        this.googleMap.moveCamera(CameraUpdateFactory.newLatLng(currLoc));
//        showMarker(currLoc, null);
    }

    @Override
    protected void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        startLocationService();
        registerReceiver(myLocationReceiver, new IntentFilter(com.jay.googlelocation.Globle.Constants.LOCATION_BROADCAST_KEY));
        registerReceiver(myGeoFencingDetails, new IntentFilter(AppStrings.BROADCAST_KEY_ALARM_GEOFENCING));
        registerReceiver(alarmTimeNotification, new IntentFilter(AppStrings.BROADCAST_KEY_ALARM));
    }

    @Override
    protected void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (intent_locationService != null) {
            stopService(intent_locationService);
        }
        unregisterReceiver(myLocationReceiver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(alarmTimeNotification);
            unregisterReceiver(myGeoFencingDetails);
        } catch (Exception e) {

        }
    }

    @Override
    public void onBackPressed() {
        //if order is running, then don't press back button, else finish
        if (isComeFromOrderHistory) {
            sendFeedback(AppConstants.COMPLETED);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnHelpMe:
                OrderCancelActivity.launch(this, false, ORDER_CANCEL_CODE);
                break;
            case R.id.llCall:
                contactToCall = orderDetails.getCustomer_details().getCustomer_contactno();
                checkForPermissionAndCall();
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case ORDER_CANCEL_CODE:
                if (resultCode == Activity.RESULT_OK) {
                    int resData = data.getIntExtra(IntentConstants.REQUEST_STATUS, com.alnahla.utils.Constants.DEFAULT_ORDER_STATUS);
                    int reasonID = data.getIntExtra(IntentConstants.REASON_ID, AppConstants.NO_VALUE_SET);
                    String othersComment = data.getStringExtra(IntentConstants.OTHERS_COMMENT);

                    if (resData == com.alnahla.utils.Constants.ORDER_CANCEL) {
                        /*
                            Order Rejected, call api
                         */
                        updateOrderStatus(AppConstants.REJECTED, reasonID, othersComment);

                    } else if (resData == com.alnahla.utils.Constants.ORDER_CANCEL_REJECTED) {

                    }
                }
                break;

            case CALL_SETTING:
                checkForPermissionAndCall();
                break;

        }
    }

    /*

                Private methods

             */
    private void updateOrderStatus(final int is_accepted, final int reasonID, final String othersComment) {

        apisCommon.apiCancelAcceptOrder(getBaseContext(), strOrderID, reasonID, othersComment, is_accepted, AppConstants.NO_VALUE_SET_STRING, new InterfaceAPI() {
            @Override
            public void onPreExecute() {
                showProgress();
            }

            @Override
            public void apiSuccessful(int statusCode, JSONObject jsonObject, String response) {
                stopProgress();
                new MessageDialog(OrderActivity.this)
                        .setTitle(getString(R.string.alert_msg_title_orderCanceled))
                        .setMessage(getString(R.string.alert_msg_orderCanceled))
                        .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                session.setFlageFromKey(PreferenceKeys.KEY_ORDER_CANCEL_REQUEST_SENT, true);
                                mBinding.btnHelpMe.setVisibility(View.GONE);
                            }
                        })
                        .cancelable(false)
                        .show();
            }

            @Override
            public void apiFailed(int statusCode, ArrayList<String> messages) {
                stopProgress();
                errorHandleFromApi(messages, statusCode);
            }
        });
    }

    private void setRestToCustomerLayout() {
        if (isComeFromOrderHistory) {
            mBinding.include.rlOrderTimeStatus.setVisibility(View.VISIBLE);
            mBinding.include.tvOrderStatus.setText(orderDetails.getStatus());
            mBinding.include.tvRestaurantname.setText(orderDetails.getRestaurant_details().getRestaurant_name());
            mBinding.include.tvRestaurantAddress.setText(orderDetails.getRestaurant_details().getRestaurant_address());
            mBinding.include.tvUsername.setText(orderDetails.getCustomer_details().getCustomer_name());
            mBinding.include.tvUserAddress.setText(orderDetails.getCustomer_details().getCustomer_address());

            glideLoader.loadImageSimple(orderDetails.getRestaurant_details().getRestaurant_image(), mBinding.include.ivRestaurantImage);
            glideLoader.loadImageCircle(orderDetails.getCustomer_details().getCustomer_profile_image(), mBinding.include.ivUserImage);
        } else {
            mBinding.llInclude.setVisibility(View.GONE);
        }
    }

    private void checkIfFcmNotification() {
        /*
            Activity Started from FCM
         */
        if (getIntent().hasExtra(AppConstants.NOTIFICATION_DATA)) {

        } else {

        }
    }

    private void checkIfCameFromOrderHistory() {
        /*
            Check if this is live order or order completed
         */
        if (isComeFromOrderHistory) {
            orderDetails = (Order_details) getIntent().getSerializableExtra(IntentConstants.ORDER_DETAILS);
            if (orderDetails.getOrder_status() != null) {
                orderStatuses = (ArrayList<Order_status>) orderDetails.getOrder_status();
            }
            intIsOrderRunning = AppConstants.NO_ORDERS;
            mBinding.toolbarLayout.tvOrderStatusTitle.setText(orderDetails.getStatus());
            if (!orderDetails.getTimestamp().equalsIgnoreCase(""))
                mBinding.toolbarLayout.tvDate.setText(Utils.longToDateStringFilter(Long.parseLong(orderDetails.getTimestamp())));

            processOrderDetailsObject();
            drawRouteOnMap(dbRestLat, dbRestLng, dbClientLat, dbClientLng, REST_CLIENT, getOrderStatusObject(orderDetails.getStatus_code()));
        } else {
            apiOrderDetails();
        }
    }

    private void init() {
        googleApiKey = getResources().getString(R.string.key_google_client);
        googleDistanceAPI = new GoogleDistanceAPI();

        orderActivity = this;
        lastUpdatedStatus = AppConstants.NO_VALUE_SET;

        alarmTimeNotification = new AlarmTimeNotification();

        orderStatuses = new ArrayList<>();
        apisCommon = new ApisCommon();
        mGeofenceList = new ArrayList<>();
        geofencingClient = LocationServices.getGeofencingClient(this);
        appAlarmManager = new AppAlarmManager();

        myLocationReceiver = new MyLocationReceiver();
        myGeoFencingDetails = new MyGeoFencingDetails();

        isComeFromOrderHistory = getIntent().getBooleanExtra(IntentConstants.FROM_ORDERHISTORY, isComeFromOrderHistory);
        dbDriverLat = getIntent().getDoubleExtra(IntentConstants.DRIVER_LAT, Constants.DEFAULT_LAT);
        dbDriverLng = getIntent().getDoubleExtra(IntentConstants.DRIVER_LNG, Constants.DEFAULT_LNG);
        strOrderID = String.valueOf(getIntent().getIntExtra(IntentConstants.ORDER_ID, Constants.DEFAULT_ORDER_ID));
        if (getIntent().hasExtra(IntentConstants.NOTY_TYPE))
            notyType = getIntent().getStringExtra(IntentConstants.NOTY_TYPE);
        else {
            notyType = AppConstants.NO_VALUE_SET_STRING;
        }

        supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        supportMapFragment.getMapAsync(this);
    }

    private void setClickListeners() {
        mBinding.btnHelpMe.setOnClickListener(this);
        mBinding.toolbarLayout.ivNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contactToCall = session.getValueFromKey(PreferenceKeys.KEY_ADMIN_CONTACT, AppConstants.NO_VALUE_SET_STRING);
                checkForPermissionAndCall();
            }
        });
        mBinding.ivWaze.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (intCurrentOrderStatus == AppConstants.ACCEPTED || intCurrentOrderStatus == AppConstants.ASSIGNED || intCurrentOrderStatus == ARRIVED_TO_RESTAURANT) {
                    launchWazeApp(dbRestLat, dbRestLng);
                } else {
                    launchWazeApp(dbClientLat, dbClientLng);
                }

            }
        });

        mBinding.ivNavigation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (intCurrentOrderStatus == AppConstants.ACCEPTED || intCurrentOrderStatus == AppConstants.ASSIGNED || intCurrentOrderStatus == ARRIVED_TO_RESTAURANT) {
                    launchNavigationIntent(dbRestLat, dbRestLng);
                } else {
                    launchNavigationIntent(dbClientLat, dbClientLng);
                }
            }
        });
    }

    private void setViews() {


        if (isComeFromOrderHistory || (notyType != null && notyType.equalsIgnoreCase(API_CONSTANTS.NOTIFICATION_TYPE_ASSIGNED_ORDER)) || session.getFlagFromKey(PreferenceKeys.KEY_ORDER_CANCEL_REQUEST_SENT, false)) {
            mBinding.btnHelpMe.setVisibility(View.GONE);
        }
        if (notyType != null) {
            if (notyType.equalsIgnoreCase(API_CONSTANTS.NOTI_TYPE_CANCEL_ORDER_ADMIN) || notyType.equalsIgnoreCase(API_CONSTANTS.NOTI_TYPE_CANCEL_ORDER_REST)) {
                orderCancelDialog();
            }
        }
    }

    private void setUpUi() {

        setStatusBarColor(this, getResources().getColor(R.color.status_color_green));
        setupToolBar(getResources().getString(R.string.toolbar_orderDetails) + strOrderID);
        setViews();
    }

    /*
        Add geo fencing
     */

    private void addGeoFenceRest() {
        mGeofenceList.clear();
        if (dbRestLng != 0.0 && dbRestLat != 0.0) {
            mGeofenceList.add(new Geofence.Builder()
                    // Set the request ID of the geofence. This is a string to identify this
                    // geofence.
                    .setRequestId(REQ_ID_REST)

                    .setCircularRegion(
                            dbRestLat,
                            dbRestLng,
                            AppConstants.GEOFENCE_RADIUS_IN_METERS
                    )
                    .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER)
                    .setExpirationDuration(Geofence.NEVER_EXPIRE)
                    .build());
        }
    }

    private void addGeoFenceClient() {
        mGeofenceList.clear();
        if (dbClientLat != 0.0 && dbClientLng != 0.0) {
            mGeofenceList.add(new Geofence.Builder()
                    // Set the request ID of the geofence. This is a string to identify this
                    // geofence.
                    .setRequestId(REQ_ID_CLIENT)

                    .setCircularRegion(
                            dbClientLat,
                            dbClientLng,
                            AppConstants.GEOFENCE_RADIUS_IN_METERS
                    )
                    .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER)
                    .setExpirationDuration(Geofence.NEVER_EXPIRE)
                    .build());
        }
    }


    @SuppressLint("MissingPermission")
    private void addGeoFence() {
        geofencingClient.addGeofences(getGeofencingRequest(), getGeofencePendingIntent())
                .addOnSuccessListener(this, new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        // Geofences added
                        // ...
                    }
                })
                .addOnFailureListener(this, new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Failed to add geofences
                        // ...
                    }
                });
    }

    private void removeGeoFencing() {
        geofencingClient.removeGeofences(getGeofencePendingIntent())
                .addOnSuccessListener(this, new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        // Geofences removed
                        // ...
                    }
                })
                .addOnFailureListener(this, new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Failed to remove geofences
                        // ...
                    }
                });
    }

    private PendingIntent getGeofencePendingIntent() {
        // Reuse the PendingIntent if we already have it.
        if (mGeofencePendingIntent != null) {
            return mGeofencePendingIntent;
        }
        Intent intent = new Intent(this, GeofenceTransitionsIntentService.class);
        // We use FLAG_UPDATE_CURRENT so that we get the same pending intent back when
        // calling addGeofences() and removeGeofences().
        mGeofencePendingIntent = PendingIntent.getService(this, 0, intent, PendingIntent.
                FLAG_UPDATE_CURRENT);
        return mGeofencePendingIntent;
    }

    private GeofencingRequest getGeofencingRequest() {
        GeofencingRequest.Builder builder = new GeofencingRequest.Builder();
        builder.setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER);
        builder.addGeofences(mGeofenceList);
        return builder.build();
    }

    /*
        This method gets called, once we get order details from api
     */
    private String getPaymentTypeText(int payType) {
        String payTypeText = AppConstants.NO_VALUE_SET_STRING;
        switch (payType) {
            case AppConstants.TYPE_CASH:
                payTypeText = AppStrings.TYPE_CASH;
                break;
            case AppConstants.TYPE_CARD:
                payTypeText = AppStrings.TYPE_CARD;
                break;
        }

        return payTypeText;
    }

    private void setOrderDetails() {
        if (orderDetails != null) {
            if (orderDetails.getTotal_price() != null) {
                mBinding.tvTotalAmount.setText(String.valueOf(orderDetails.getTotal_price()));
                mBinding.incPayment.tvPaymentType.setText(getPaymentTypeText(orderDetails.getPayment_type()));
                mBinding.incPayment.tvAmount.setText(String.valueOf(orderDetails.getTotal_price()));
                mBinding.incPayment.tvCurrency.setText(orderDetails.getCurrency_symbol());
            }
            //setting customer details
            if (orderDetails.getCustomer_details() != null) {
                Customer_details customerDetails = orderDetails.getCustomer_details();
                clientName = customerDetails.getCustomer_name();
                clientAddress = customerDetails.getCustomer_address();
                clientImage = customerDetails.getCustomer_profile_image();
                dbClientLat = customerDetails.getCustomer_latitude();
                dbClientLng = customerDetails.getCustomer_longitude();

            }

            //setting restraunt details
            if (orderDetails.getRestaurant_details() != null) {
                Restaurant_details restaurantDetails = orderDetails.getRestaurant_details();
                mBinding.tvRestName.setText(restaurantDetails.getRestaurant_name());
                mBinding.tvRestAddress.setText(restaurantDetails.getRestaurant_address());

                dbRestLat = restaurantDetails.getRestaurant_latitude();
                dbRestLng = restaurantDetails.getRestaurant_longitude();

                //adding geo fencing
            }
            // Setting Order Items
            ArrayList<Order_items> orderItems = (ArrayList<Order_items>) orderDetails.getOrder_items();
            if (orderItems != null && orderItems.size() > 0) {
                for (Order_items item : orderItems
                ) {
                    final ItemOrderitemsBinding mBinderOrderItem = DataBindingUtil.inflate(LayoutInflater.from(this), R.layout.item_orderitems, mBinding.llOrderItems, false);
                    mBinding.llOrderItems.addView(mBinderOrderItem.getRoot());

                    mBinderOrderItem.tvItemName.setText(item.getItem_name());
                    mBinderOrderItem.tvItemQnty.setText(String.valueOf(item.getQuantity()));
                }
                mBinding.tvTotalOrderCount.setText("(" + orderItems.size() + ")");
            }
        }
    }

    /*method to set up toolbar*/
    private void setupToolBar(String text) {
        this.setSupportActionBar(mBinding.toolbarLayout.switchToolbar);
        ActionBar ab = this.getSupportActionBar();
        if (ab != null) {
            ab.setDisplayShowTitleEnabled(false);
            if (isComeFromOrderHistory) {
                ab.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
                ab.setDisplayHomeAsUpEnabled(true);
            }
        }
        mBinding.toolbarLayout.switchToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isComeFromOrderHistory)
                    onBackPressed();

            }
        });
        mBinding.toolbarLayout.title.setText(text);
        mBinding.toolbarLayout.switchOnOff.setVisibility(View.GONE);
        mBinding.toolbarLayout.tvClearAll.setVisibility(View.GONE);
        if (isComeFromOrderHistory) {
            mBinding.toolbarLayout.llOrderStatusTitle.setVisibility(View.VISIBLE);
            mBinding.toolbarLayout.ivNotification.setVisibility(View.GONE);
            mBinding.toolbarLayout.tvDate.setVisibility(View.VISIBLE);
            mBinding.toolbarLayout.ivNotification.setVisibility(View.GONE);
        } else {
            mBinding.toolbarLayout.ivNotification.setVisibility(View.VISIBLE);
            mBinding.toolbarLayout.llOrderStatusTitle.setVisibility(View.GONE);
            mBinding.toolbarLayout.tvDate.setVisibility(View.GONE);
            mBinding.toolbarLayout.ivNotification.setVisibility(View.VISIBLE);
        }
    }

    private void apiOrderDetails() {
        HashMap<String, String> params = new HashMap<>();
        params.put(API_CONSTANTS.ORDER_ID,strOrderID);

        NetworkCall.with(OrderActivity.this)
                .setEndPoint(API_EndPoints.ORDER_DETAILS)
                .setRequestParams(params)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                        showProgress();
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        stopProgress();
                        initOrderDetails(jsonObject);
                        processOrderDetailsObject();
                    }

                    @Override
                    public void onError(final int statusCode, ArrayList<String> messages) {
                        stopProgress();
                        errorHandleFromApi(messages, statusCode);
                        if(messages!=null && messages.size()>0){
                            new MessageDialog(OrderActivity.this)
                                    .setTitle(getString(R.string.errors))
                                    .setMessage(messages.get(0))
                                    .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            dialogInterface.cancel();
                                            sendFeedback(AppConstants.COMPLETED);
                                        }
                                    })
                                    .cancelable(false)
                                    .show();
                        }

                    }
                }).makeCall();
    }

    private void initOrderDetails(JSONObject jsonObject) {
        Data orderDetaiolsModel = gson.fromJson(jsonObject.toString(), Data.class);
        intIsOrderRunning = orderDetaiolsModel.getIs_order_running();
        if (orderDetaiolsModel != null) {
            orderDetails = orderDetaiolsModel.getOrder_details();
            intCurrentOrderStatus = orderDetails.getStatus_code();
            orderStatuses = (ArrayList<Order_status>) orderDetails.getOrder_status();

        }
    }

    private void processOrderDetailsObject() {
        lastUpdatedStatus = orderDetails.getStatus_code();
        strOrderID = String.valueOf(orderDetails.getOrder_id());

        setOrderDetails();
        updateOrderStatusView();
        if (!isComeFromOrderHistory)
            whenToDrawMap();

    }

    private void drawPolyLine(ArrayList<LatLng> route, int isLate, double srcLat, double srcLng, double destLat, double destLng, String timeStamp) {
        if (route.size() > 0) {

            PolylineOptions polylineOptions = new PolylineOptions();
            polylineOptions.width(10.0f).color(ContextCompat.getColor(OrderActivity.this, R.color.background_pending)).addAll(route);
            if (googleMap != null) {
                Polyline polyLine = googleMap.addPolyline(polylineOptions);
                polyLine.setPoints(route);
            }
            if (markerStartingPoint != null) {
                markerStartingPoint.remove();
            }
            if (markerEndPoint != null) {
                markerEndPoint.remove();
            }
            //Adding pick up pin
            markerStartingPoint = addMarker(srcLat, srcLng, getString(R.string.msg_driver_position), R.drawable.ic_map_start);
                    /*
                        Adding destination pin
                     */
            if (isLate == AppConstants.IS_LATE)
                markerEndPoint = addMarker(destLat, destLng, getString(R.string.msg_driver_destination), R.drawable.ic_red_flag);
            else
                markerEndPoint = addMarker(destLat, destLng, getString(R.string.msg_driver_destination), R.drawable.ic_map_dest_gray);

            moveCameraToCurrentLocation(srcLat, srcLng, destLat, destLng);

            if (isLate == AppConstants.IS_NOT_LATE && !isComeFromOrderHistory) {
                if (!isComeFromOrderHistory && !etaFromAPI.equals("")) {
                    appAlarmManager.setAlarm(OrderActivity.this, strOrderID, timeStamp, etaFromAPI);
                }
            }
        }
    }

    private void drawRouteOnMap(final double srcLat, final double srcLng,
                                final double destLat, final double destLng, final int locDetailsForRoute,
                                final Order_status orderStatusObject) {
        showProgress();
        googleDistanceAPI.getDirectionDetails(srcLat, srcLng, destLat, destLng, googleApiKey, this, new GoogleDistanceAPI.GoogleDistance() {
            @Override
            public void onResult(String distance, String time, ArrayList<LatLng> route) {
                // in meters
                estDistanceFromAPI = distance;

                //in minites
                etaFromAPI = Utils.getMinFromSec(time);
                mBinding.tvArriveTime.setText(Utils.getMinFromSec(time));
                mBinding.tvTimeType.setVisibility(View.VISIBLE);

                stopProgress();
                drawPolyLine(route, orderStatusObject.getIs_late(), srcLat, srcLng, destLat, destLng, orderStatusObject.getTimestamp());
            }
        });

    }

    private void moveCameraToCurrentLocation(double lat, double lng, double restLat,
                                             double restLong) {
        LatLngBounds.Builder builder = new LatLngBounds.Builder();
        builder.include(new LatLng(lat, lng));
        builder.include(new LatLng(restLat, restLong));
        int padding = 40; // offset from edges of the map 12% of screen
        googleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(builder.build(),
                padding));
    }

    private void updateOrderStatusView() {

        for (Order_status orderStatus : orderStatuses
        ) {

            switch (orderStatus.getStatus_code()) {
                case AppConstants.ASSIGNED:
                    orderAccepted(orderStatus);
                    break;
                case AppConstants.ACCEPTED:
                    orderAccepted(orderStatus);
                    break;
                case ARRIVED_TO_RESTAURANT:
                    driverArrivedRest(orderStatus);
                    break;
                case AppConstants.PICKED_UP:
                    orderPickedUp(orderStatus);
                    break;
                case AppConstants.DELIVERED:
                    orderDelivered(orderStatus);
                    break;
                case AppConstants.COMPLETED:
                    orderCompleted(orderStatus);
                    break;
                case AppConstants.CANCEL_BY_RESTAURENT:
                    orderCancelledByAdmin(orderStatus);
                    break;
                case AppConstants.CANCEL_BY_ADMIN:
                    orderCancelledByAdmin(orderStatus);
                    break;

            }
        }
    }

    private void whenToDrawMap() {
        if (orderDetails.getStatus_code() == AppConstants.ASSIGNED || orderDetails.getStatus_code() == AppConstants.ACCEPTED || orderDetails.getStatus_code() == AppConstants.ARRIVED_TO_RESTAURANT) {
            drawRouteOnMap(dbDriverLat, dbDriverLng, dbRestLat, dbRestLng, DRIVER_REST, getOrderStatusObject(orderDetails.getStatus_code()));
        } else if (orderDetails.getStatus_code() == AppConstants.PICKED_UP || orderDetails.getStatus_code() == AppConstants.DELIVERED || orderDetails.getStatus_code() == AppConstants.COMPLETED) {
            drawRouteOnMap(dbDriverLat, dbDriverLng, dbClientLat, dbClientLng, REST_CLIENT, getOrderStatusObject(orderDetails.getStatus_code()));
        }
    }

    private void orderAccepted(final Order_status orderStatus) {
        setDriverStatus(getResources().getString(R.string.msg_ontheway), getResources().getColor(R.color.color_ontheway));

        mBinderArrived = DataBindingUtil.inflate(LayoutInflater.from(this), R.layout.item_order_status, mBinding.llOrderStatusItems, false);
        mBinding.llOrderStatusItems.addView(mBinderArrived.getRoot());
//        mBinderArrived.btnOrderStatus.setEnabled(false);
        mBinderArrived.btnOrderStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isArrivedClicked) {
                    isArrivedClicked = true;
                    if (meterDistanceBetweenPoints(dbDriverLat, dbDriverLng, dbRestLat, dbRestLng) <= AppConstants.DEFAULT_DIS_METERS) {

                        apiOrderStatusUpdate(ARRIVED_TO_RESTAURANT, AppConstants.NO_VALUE_SET_STRING, new InterfaceAPI() {
                            @Override
                            public void onPreExecute() {

                            }

                            @Override
                            public void apiSuccessful(int statusCode, JSONObject jsonObject, String response) {
                                initOrderDetails(jsonObject);
                                orderStatus.setTimestamp(String.valueOf(System.currentTimeMillis()));
                                googleMap.clear();
                                driverArrivedRest(orderStatus);
                            }

                            @Override
                            public void apiFailed(int statusCode, ArrayList<String> messages) {
                                errorHandleFromApi(messages, statusCode);
                                isArrivedClicked = false;
                            }
                        });
                    } else {
                        isArrivedClicked = false;
                        new MessageDialog(OrderActivity.this)
                                .setTitle(getString(R.string.alert_title_alert))
                                .setMessage(getString(R.string.alert_msg_notReached))
                                .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {

                                    }
                                })
                                .cancelable(false)
                                .show();
                    }
                }
            }
        });
        mBinderLast = mBinderArrived;
        mBinderCurrent = mBinderArrived;
    }

    private void driverArrivedRest(final Order_status orderStatus) {
        mBinding.tvArriveTime.setText(String.valueOf(AppConstants.DEFAULT_TIME));
        setDriverStatus(getResources().getString(R.string.msg_arrivedAtRest), getResources().getColor(R.color.color_arrivedatrest));

        if (mBinderArrived != null) {
            mBinderArrived.btnOrderStatus.setVisibility(View.GONE);
            mBinderArrived.llOrderStatus.setVisibility(View.VISIBLE);
            mBinderArrived.viewLine.setVisibility(View.VISIBLE);

            mBinderArrived.tvOrderStatus.setText(AppStrings.ARRIVED_tO_RESTAURANT);
            mBinderArrived.tvTime.setText(Utils.getTimeFromLong(Double.valueOf(orderStatus.getTimestamp()).longValue()));
        }

        mBinderPickup = DataBindingUtil.inflate(LayoutInflater.from(getBaseContext()), R.layout.item_order_status, mBinding.llOrderStatusItems, false);
        mBinding.llOrderStatusItems.addView(mBinderPickup.getRoot());
        mBinderPickup.btnOrderStatus.setText(getResources().getString(R.string.btn_pickUp));
        mBinderPickup.viewLineUpper.setVisibility(View.VISIBLE);
        if (isComeFromOrderHistory)
            mBinderPickup.btnOrderStatus.setEnabled(false);
        mBinderPickup.btnOrderStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isPickUpClicked) {
                    isPickUpClicked = true;
                    googleDistanceAPI.getDirectionDetails(dbDriverLat, dbDriverLng, dbClientLat, dbClientLng, googleApiKey, getApplicationContext(), new GoogleDistanceAPI.GoogleDistance() {

                        @Override
                        public void onResult(String distance, String time, final ArrayList<LatLng> route) {
                            estDistanceFromAPI = distance;
                            etaFromAPI = Utils.getMinFromSec(time);
                            mBinding.tvArriveTime.setText(Utils.getMinFromSec(time));
                            mBinding.tvTimeType.setVisibility(View.VISIBLE);
                        /*
                            Here, we have to also pass the estimated time, so called api after getting location details
                         */
                            apiOrderStatusUpdate(AppConstants.PICKED_UP, etaFromAPI, new InterfaceAPI() {
                                @Override
                                public void onPreExecute() {

                                }

                                @Override
                                public void apiSuccessful(int statusCode, JSONObject jsonObject, String response) {
                                    initOrderDetails(jsonObject);
                                    orderStatus.setTimestamp(String.valueOf(System.currentTimeMillis()));
                                    drawPolyLine(route, AppConstants.IS_NOT_LATE, dbDriverLat, dbDriverLng, dbClientLat, dbClientLng, orderStatus.getTimestamp());
                                    orderPickedUp(orderStatus);
                                }

                                @Override
                                public void apiFailed(int statusCode, ArrayList<String> messages) {
                                    errorHandleFromApi(messages, statusCode);
                                    isPickUpClicked = false;
                                }
                            });
                        }
                    });
                }
            }
        });

        mBinderLast = mBinderCurrent;
        mBinderCurrent = mBinderPickup;

    }

    private void orderPickedUp(final Order_status orderStatus) {
        setCustomerDetails();

        // calculate the distance again with delivery details
        mBinding.tvTimeTitle.setText(getResources().getString(R.string.msg_reachTime));
        setDriverStatus(getResources().getString(R.string.msg_wayToDelivery), getResources().getColor(R.color.color_ondelivery));

        if (mBinderArrived != null) {
            mBinderArrived.tvOrderStatus.setText(AppStrings.PICKED_UP_FROM_REST);
            mBinderArrived.viewLine.setBackgroundColor(getResources().getColor(R.color.color_app_green));
            mBinderArrived.ivCircle.setImageDrawable(getResources().getDrawable(R.drawable.ic_green_circle));
        }
        if (mBinderPickup != null) {
            mBinderPickup.viewLine.setVisibility(View.VISIBLE);
            mBinderPickup.viewLineUpper.setBackgroundColor(getResources().getColor(R.color.color_app_green));
            mBinderPickup.btnOrderStatus.setVisibility(View.GONE);
            mBinderPickup.llOrderStatus.setVisibility(View.VISIBLE);
            mBinderPickup.tvTime.setText(Utils.getTimeFromLong(Double.valueOf(orderStatus.getTimestamp()).longValue()));
            mBinderPickup.ivOrderStatusLogo.setImageDrawable(getResources().getDrawable(R.drawable.ic_pickup));
        }

        mBinderDelivered = DataBindingUtil.inflate(LayoutInflater.from(getBaseContext()), R.layout.item_order_status, mBinding.llOrderStatusItems, false);
        mBinderDelivered.btnOrderStatus.setText(getResources().getString(R.string.btn_delivered));
//        mBinderDelivered.btnOrderStatus.setEnabled(false);
        /*
            Call To Customer
         */
        mBinderDelivered.llCall.setVisibility(View.VISIBLE);
        mBinderDelivered.llCall.setOnClickListener(this);

        mBinderDelivered.viewLineUpper.setVisibility(View.VISIBLE);
        mBinding.llOrderStatusItems.addView(mBinderDelivered.getRoot());
        mBinderDelivered.btnOrderStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isDeliveredClicked) {
                    isDeliveredClicked = true;
                    if (meterDistanceBetweenPoints(dbDriverLat, dbDriverLng, dbClientLat, dbClientLng) <= AppConstants.DEFAULT_DIS_METERS) {

                        apiOrderStatusUpdate(AppConstants.DELIVERED, AppConstants.NO_VALUE_SET_STRING, new InterfaceAPI() {
                            @Override
                            public void onPreExecute() {

                            }

                            @Override
                            public void apiSuccessful(int statusCode, JSONObject jsonObject, String response) {
                                initOrderDetails(jsonObject);
                                orderStatus.setTimestamp(String.valueOf(System.currentTimeMillis()));
                                orderDelivered(orderStatus);
                            }

                            @Override
                            public void apiFailed(int statusCode, ArrayList<String> messages) {
                                errorHandleFromApi(messages, statusCode);
                                isDeliveredClicked = false;
                            }
                        });
                    } else {
                        isDeliveredClicked = false;
                        new MessageDialog(OrderActivity.this)
                                .setTitle(getString(R.string.alert_title_alert))
                                .setMessage(getString(R.string.alert_msg_notReached))
                                .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {

                                    }
                                })
                                .cancelable(false)
                                .show();
                    }
                }
            }
        });

        mBinderLast = mBinderCurrent;
        mBinderCurrent = mBinderDelivered;
    }

    private String getDeliveryTime() {
        String totalDuration = "";
        String tSAccepted = "", tsArrived = "", tsOrderPicked = "", tsOrderDelivered = "";
        if (orderStatuses != null && orderStatuses.size() > 0) {
            for (Order_status item : orderStatuses
            ) {
                switch (item.getStatus_code()) {
                    case AppConstants.ASSIGNED:
                        tSAccepted = String.valueOf(item.getTimestamp());
                        break;
                    case AppConstants.ACCEPTED:
                        tSAccepted = String.valueOf(item.getTimestamp());
                        break;
                    case ARRIVED_TO_RESTAURANT:
                        tsArrived = String.valueOf(item.getTimestamp());
                        break;
                    case AppConstants.PICKED_UP:
                        tsOrderPicked = String.valueOf(item.getTimestamp());
                        break;
                    case AppConstants.DELIVERED:
                        tsOrderDelivered = String.valueOf(item.getTimestamp());
                        break;
                }
            }
        }
        int durationReachRest = Utils.durationBetweenTwoTimes(tSAccepted, tsArrived);
        int durationReachCustomer = Utils.durationBetweenTwoTimes(tsOrderPicked, tsOrderDelivered);
        totalDuration = String.valueOf(durationReachRest + durationReachCustomer);
        return totalDuration;
    }

    private void orderDelivered(final Order_status orderStatus) {


        mBinding.btnHelpMe.setVisibility(View.GONE);

        mBinding.tvArriveTime.setText(String.valueOf(AppConstants.DEFAULT_TIME));
        setDriverStatus(getResources().getString(R.string.msg_itemsDelivered), getResources().getColor(R.color.color_delivered));
        if (mBinderPickup != null) {
            mBinderPickup.viewLine.setBackgroundColor(getResources().getColor(R.color.color_app_green));
            mBinderPickup.ivCircle.setImageDrawable(getResources().getDrawable(R.drawable.ic_green_circle));
        }
        if (mBinderDelivered != null) {
            mBinderDelivered.viewLineUpper.setBackgroundColor(getResources().getColor(R.color.color_app_green));
            mBinderDelivered.viewLine.setVisibility(View.VISIBLE);
            mBinderDelivered.btnOrderStatus.setVisibility(View.GONE);
            mBinderDelivered.llOrderStatus.setVisibility(View.VISIBLE);

            mBinderDelivered.llCall.setVisibility(View.VISIBLE);
            mBinderDelivered.llCall.setOnClickListener(this);

            mBinderDelivered.tvOrderStatus.setText(AppStrings.DELIVER_TO_CUSTOMER);
            mBinderDelivered.tvTime.setText(Utils.getTimeFromLong(Double.valueOf(orderStatus.getTimestamp()).longValue()));

            mBinderDelivered.ivOrderStatusLogo.setImageDrawable(getResources().getDrawable(R.drawable.ic_delivered));
        }


        mBinderTakePayment = DataBindingUtil.inflate(LayoutInflater.from(getBaseContext()), R.layout.item_order_status, mBinding.llOrderStatusItems, false);
        mBinderTakePayment.btnOrderStatus.setText(getResources().getString(R.string.btn_takePayment));
        if (isComeFromOrderHistory)
            mBinderTakePayment.btnOrderStatus.setEnabled(false);
        mBinderTakePayment.viewLineUpper.setVisibility(View.VISIBLE);
        mBinding.llOrderStatusItems.addView(mBinderTakePayment.getRoot());
        mBinderTakePayment.btnOrderStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isTakePaymentClicked) {
                    isTakePaymentClicked = true;
                    apiOrderStatusUpdate(AppConstants.COMPLETED, AppConstants.NO_VALUE_SET_STRING, new InterfaceAPI() {
                        @Override
                        public void onPreExecute() {
                            showProgress();
                        }

                        @Override
                        public void apiSuccessful(int statusCode, JSONObject jsonObject, String response) {
                            stopProgress();
                        /*
                            Calculate total delivery time
                         */

                            initOrderDetails(jsonObject);
                            mBinding.tvArriveTime.setText(getDeliveryTime());
                            orderStatus.setTimestamp(String.valueOf(System.currentTimeMillis()));
                            orderCompleted(orderStatus);
                        }

                        @Override
                        public void apiFailed(int statusCode, ArrayList<String> messages) {
                            stopProgress();
                            errorHandleFromApi(messages, statusCode);
                            isTakePaymentClicked = false;
                        }
                    });
                }

            }
        });

        mBinderLast = mBinderCurrent;
        mBinderCurrent = mBinderTakePayment;
        if (isComeFromOrderHistory) {
            mBinding.tvArriveTime.setText(getDeliveryTime());
        }

        mBinderLast = mBinderCurrent;
        mBinderCurrent = mBinderPickup;
    }

    private void orderCompleted(Order_status orderStatus) {

        mBinding.tvTimeTitle.setText(getResources().getString(R.string.msg_deliveryTime));

        mBinding.btnHelpMe.setVisibility(View.GONE);
        if (mBinderDelivered != null) {
            mBinderDelivered.llCall.setVisibility(View.GONE);
            mBinderDelivered.ivCircle.setImageDrawable(getResources().getDrawable(R.drawable.ic_green_circle));
        }

        setDriverStatus(getResources().getString(R.string.msg_orderCompleted), getResources().getColor(R.color.color_ordercompleted));
        if (mBinderTakePayment != null) {
            mBinderTakePayment.ivOrderStatusLogo.setImageDrawable(getResources().getDrawable(R.drawable.ic_paymentdone));
            mBinderTakePayment.ivCircle.setImageDrawable(getResources().getDrawable(R.drawable.ic_green_circle));
            mBinderTakePayment.llOrderStatus.setVisibility(View.VISIBLE);
            mBinderDelivered.tvOrderStatus.setText(AppStrings.PAYMENT_SUCCESSFUL);
            mBinderTakePayment.tvTime.setText(Utils.getTimeFromLong(Double.valueOf(orderStatus.getTimestamp()).longValue()));
            mBinderTakePayment.btnOrderStatus.setVisibility(View.GONE);
        }
        intIsOrderRunning = AppConstants.NO_ORDERS;
        mBinding.btnHelpMe.setVisibility(View.GONE);
        if (!isComeFromOrderHistory) {
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close);
            new MessageDialog(OrderActivity.this)
                    .setTitle(getString(R.string.msg_orderCompleted))
                    .setMessage(getString(R.string.alert_msg_orderComplt) + " " + orderDetails.getCurrency_symbol() + orderDetails.getTotal_price() + " in " + getPaymentTypeText(orderDetails.getPayment_type()))
                    .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            sendFeedback(AppConstants.COMPLETED);
                        }
                    })
                    .cancelable(false)
                    .show();
        }

        mBinderLast = mBinderCurrent;
        mBinderCurrent = mBinderPickup;
    }

    private void orderCancelledByAdmin(Order_status orderStatus) {


        setDriverStatus(getResources().getString(R.string.msg_orderCancelledRest), getResources().getColor(R.color.color_ordercompleted));


        mBinderOrderCancelled = DataBindingUtil.inflate(LayoutInflater.from(getBaseContext()), R.layout.item_order_status, mBinding.llOrderStatusItems, false);

        if (mBinderLast == mBinderCurrent) {
            // Driver is still to arrive
            mBinding.llDriverStatus.removeView(mBinderLast.getRoot());
            mBinderOrderCancelled.btnOrderStatus.setVisibility(View.GONE);
            mBinderOrderCancelled.llOrderStatus.setVisibility(View.VISIBLE);
            mBinderOrderCancelled.viewLineUpper.setVisibility(View.GONE);
            mBinderOrderCancelled.viewLine.setVisibility(View.GONE);

        } else {
            mBinding.llDriverStatus.removeView(mBinderLast.getRoot());
            mBinderOrderCancelled.btnOrderStatus.setVisibility(View.GONE);
            mBinderOrderCancelled.llOrderStatus.setVisibility(View.VISIBLE);
            mBinderOrderCancelled.viewLineUpper.setVisibility(View.VISIBLE);
            mBinderOrderCancelled.viewLine.setVisibility(View.GONE);
            mBinderLast.viewLine.setBackgroundColor(getResources().getColor(R.color.colorBtnRed));
            mBinderLast.ivCircle.setImageDrawable(getResources().getDrawable(R.drawable.ic_green_circle));
            mBinderOrderCancelled.viewLineUpper.setBackgroundColor(getResources().getColor(R.color.colorBtnRed));
        }
        mBinding.llOrderStatusItems.removeView(mBinderCurrent.getRoot());
        mBinderOrderCancelled.tvOrderStatus.setText(AppStrings.CANCEL_BY_ADMIN);
        mBinderOrderCancelled.tvTime.setText(Utils.getTimeFromLong(Double.valueOf(orderStatus.getTimestamp()).longValue()));

        mBinderOrderCancelled.ivOrderStatusLogo.setImageDrawable(getResources().getDrawable(R.drawable.ic_ordercalcelled));
        mBinderOrderCancelled.ivCircle.setImageDrawable(getResources().getDrawable(R.drawable.ic_red_circle));
        mBinding.llOrderStatusItems.addView(mBinderOrderCancelled.getRoot());
        if (!isComeFromOrderHistory)
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close);

    }

    private void apiOrderStatusUpdate(int orderStatus, String etaFromAPI, InterfaceAPI orderStatusUpdation) {
        /*
            To prevent from updating same status multiple times, we have put this condition
         */
        if (lastUpdatedStatus != orderStatus) {
            final InterfaceAPI updation = orderStatusUpdation;
            HashMap params = new HashMap<>();
            params.put(API_CONSTANTS.ORDER_ID, strOrderID);
            params.put(API_CONSTANTS.ORDER_STATUS, String.valueOf(orderStatus));
            params.put(API_CONSTANTS.DRIVER_LATITUDE, String.valueOf(dbDriverLat));
            params.put(API_CONSTANTS.DRIVER_LONGITUDE, String.valueOf(dbDriverLng));
            if (!etaFromAPI.equalsIgnoreCase(AppConstants.NO_VALUE_SET_STRING)) {
                params.put(API_CONSTANTS.ETA, etaFromAPI);
            }
            NetworkCall.with(this)
                    .setEndPoint(API_EndPoints.UPDATE_ORDER_STATUS)
                    .setRequestParams(params)
                    .setResponseListener(new RetrofitResponseListener() {
                        @Override
                        public void onPreExecute() {
                            showProgress(getString(R.string.txt_pls_wait));
                        }

                        @Override
                        public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                            stopProgress();

                            GsonBuilder gsonBuilder = new GsonBuilder();
                            Gson gson = gsonBuilder.create();
                            Data orderDetaiolsModel = gson.fromJson(jsonObject.toString(), Data.class);
                            intIsOrderRunning = orderDetaiolsModel.getIs_order_running();
                            if (orderDetaiolsModel != null) {

                                orderDetails = orderDetaiolsModel.getOrder_details();
                                orderStatuses = (ArrayList<Order_status>) orderDetails.getOrder_status();
                                lastUpdatedStatus = orderDetails.getStatus_code();
                            }
                            updation.apiSuccessful(statusCode, jsonObject, response);
                        }

                        @Override
                        public void onError(int statusCode, ArrayList<String> messages) {
                            errorHandleFromApi(messages, statusCode);
                            stopProgress();
                            updation.apiFailed(statusCode, messages);
                        }

                    }).makeCall();
        }
    }

    private void setDriverStatus(String message, int color) {
        if (isComeFromOrderHistory) {
            mBinding.tvDriverStatus.setVisibility(View.GONE);
        } else {
            mBinding.tvDriverStatus.setVisibility(View.VISIBLE);
            mBinding.tvDriverStatus.setText(message);
            mBinding.llDriverStatus.setBackgroundColor(color);
        }
    }

    public void moveMarkerOnPath() {
        if (markerStartingPoint != null && googleMap != null) {
            LatLng latLng = new LatLng(dbDriverLat, dbDriverLng);
            markerStartingPoint.setPosition(latLng);
//            googleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        }
    }

    private void startLocationService() {
        intent_locationService = new Intent(this, LocationService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent_locationService);
        } else {
            startService(intent_locationService);
        }
    }

    public void orderCancelEvent() {
        Order_status orderStatus = new Order_status();
        orderStatus.setTimestamp(String.valueOf(System.currentTimeMillis()));
        orderCancelledByAdmin(orderStatus);

        orderCancelDialog();

        mBinding.btnHelpMe.setVisibility(View.GONE);
        intIsOrderRunning = AppConstants.NO_ORDERS;
    }

    private void orderCancelDialog() {
        new MessageDialog(this)
                .setTitle(getResources().getString(R.string.alert_msg_title_orderCanceled))
                .setMessage(getResources().getString(R.string.alert_msg_body_orderCanceled))
                .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        sendFeedback(AppConstants.COMPLETED);
                    }
                })
                .cancelable(false)
                .show();
    }

    /*

        Broadcast receiver to get location updates from service defined in googlelocation api

     */
    public class MyLocationReceiver extends BroadcastReceiver {
        public MyLocationReceiver() {
        }

        @Override
        public void onReceive(Context context, Intent intent) {


            dbDriverLat = intent.getDoubleExtra(com.jay.googlelocation.Globle.Constants.LATITUDE, dbDriverLat);
            dbDriverLng = intent.getDoubleExtra(com.jay.googlelocation.Globle.Constants.LONGITUDE, dbDriverLng);
            if (isLocFirstTime) {
                isLocFirstTime = true;
                session.setValueFromKey(PreferenceKeys.KEY_DRIVER_START_LATITUDE, String.valueOf(dbDriverLat));
                session.setValueFromKey(PreferenceKeys.KEY_DRIVER_START_LONGITUDE, String.valueOf(dbDriverLng));
            }
            moveMarkerOnPath();

        }
    }

    /*
        Broadcast receiver to get geo fencing details

     */
    public class MyGeoFencingDetails extends BroadcastReceiver {
        public MyGeoFencingDetails() {

        }

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.hasExtra(IntentConstants.GEO_FENCING_REQID)) {
                if (intent.getStringExtra(IntentConstants.GEO_FENCING_REQID).equalsIgnoreCase(REQ_ID_REST)) {
                    if (mBinderArrived != null && mBinderArrived.btnOrderStatus != null) {
                        mBinderArrived.btnOrderStatus.setEnabled(true);
                    }
                    showSimpleMessageDialog(getString(R.string.alert_msg_title_arrived), getString(R.string.alert_msg_body_arrRest));
                    if (!isComeFromOrderHistory) {
                        googleMap.clear();
                        removeGeoFencing();
                        addGeoFenceClient();
                        addGeoFence();
                    }
                } else if (intent.getStringExtra(IntentConstants.GEO_FENCING_REQID).equalsIgnoreCase(REQ_ID_CLIENT)) {
                    showSimpleMessageDialog(getString(R.string.alert_msg_title_arrived), getString(R.string.alert_msg_body_arrCustomer));
                    if (mBinderDelivered != null && mBinderDelivered.btnOrderStatus != null) {
                        mBinderDelivered.btnOrderStatus.setEnabled(true);
                    }
                    removeGeoFencing();
                }
            }

        }
    }

    /*

        Broadcast receiver to get notification after alaram finishes

     */

    public class AlarmTimeNotification extends BroadcastReceiver {

        //the method will be fired when the alarm is triggerred

        public AlarmTimeNotification() {
            super();
        }

        @Override
        public void onReceive(Context context, Intent intent) {

            //you can check the log that it is fired
            //Here we are actually not doing anything
            //but you can do any task here that you want to be done at a specific time everyday

            // Calculating distance to check if the user got late or not
            if (intCurrentOrderStatus == AppConstants.ACCEPTED || intCurrentOrderStatus == AppConstants.ASSIGNED || intCurrentOrderStatus == ARRIVED_TO_RESTAURANT) {
                if (markerEndPoint != null && meterDistanceBetweenPoints(dbDriverLat, dbDriverLng, dbRestLat, dbRestLng) >= AppConstants.DEFAULT_DIS_METERS) {
                    markerEndPoint.setIcon(BitmapDescriptorFactory.fromResource(R.drawable.ic_red_flag));
                }
            } else {
                if (markerEndPoint != null && meterDistanceBetweenPoints(dbDriverLat, dbDriverLng, dbClientLat, dbClientLng) >= AppConstants.DEFAULT_DIS_METERS) {
                    markerEndPoint.setIcon(BitmapDescriptorFactory.fromResource(R.drawable.ic_red_flag));
                }
            }
        }

    }

    //adding marker
    private Marker addMarker(double latitude, double longitude, String title, int icon) {
        LatLng latLng = new LatLng(latitude, longitude);
        Marker marker = googleMap.addMarker(new MarkerOptions()
                .position(latLng)
                .title(title)
                .icon(BitmapDescriptorFactory.fromResource(icon)));

        return marker;

    }

    private void setCustomerDetails() {
        // hide rest details
        mBinding.llRestaurantDetails.setVisibility(View.GONE);
        //show customer details
        if (!isComeFromOrderHistory)
            mBinding.llCustomerDetails.setVisibility(View.VISIBLE);
        //setting customer details
        mBinding.tvCustName.setText(clientName);
        mBinding.tvCustAddress.setText(clientAddress);
//        glideLoader.loadImageCircle(clientImage, mBinding.ivCustomerPic);
    }

    private void sendFeedback(int orderStatus) {
        /*
            We set this flag true at the time of canceling order in between,
            User can not send same request twise
            So at the time of starting activity we will check if the order cancel request sent or not,
            according will set Help Me button visibility
         */
        if (!isComeFromOrderHistory) {
            session.setFlageFromKey(PreferenceKeys.KEY_ORDER_CANCEL_REQUEST_SENT, false);
            session.setFlageFromKey(PreferenceKeys.KEY_SENDFEEDBACK, true);
        }

        Intent resultIntent = new Intent();
        resultIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        resultIntent.putExtra(IntentConstants.ORDER_COMPLETED, orderStatus);
        setResult(Activity.RESULT_OK, resultIntent);
        finish();
    }

    private void checkForPermissionAndCall() {
        try {
            Dexter.withActivity(this).withPermissions(callPermission).withListener(new MultiplePermissionsListener() {
                @Override
                public void onPermissionsChecked(MultiplePermissionsReport report) {
                    if (report.areAllPermissionsGranted())
                        if (contactToCall != null && !contactToCall.equalsIgnoreCase("")) {
                            callPhone(contactToCall);
                        } else {
                            showSnackBar(getResources().getString(R.string.msg_noContactDetails));
                        }
                    else {
                        openCallDialog();
                    }

                }

                @Override
                public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                    token.continuePermissionRequest();
                }

            })
                    .onSameThread()
                    .check();
        } catch (Exception e) {

        }
    }

    public void openCallDialog() {
        new MessageDialog(this)
                .setTitle(getString(R.string.alert_message_title_perReq))
                .setMessage(getString(R.string.alert_message_msg_perReqCall))
                .setPositiveButton(getString(R.string.alert_msg_openSetting), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        openApplicationSettingScreen(OrderActivity.this, CALL_SETTING);
                        dialogInterface.dismiss();
                    }
                })
                .cancelable(false)
                .show();
    }

    private Order_status getOrderStatusObject(int orderStatusCode) {
        Order_status statusObject = new Order_status();
        String timeStamp = String.valueOf(System.currentTimeMillis());
        statusObject.setTimestamp(timeStamp);
        statusObject.setIs_late(0);
        for (Order_status status : orderStatuses
        ) {

            if (status.getStatus_code() == orderStatusCode) {
                timeStamp = status.getTimestamp();
                statusObject = status;
            }
        }

        return statusObject;
    }

    /*
        If we get fcm notification for canceling order, that time we are calling EventBus service to listen to the broadcast
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(MessageEvent event) {
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).cancelAll();
        orderCancelEvent();
    }

}