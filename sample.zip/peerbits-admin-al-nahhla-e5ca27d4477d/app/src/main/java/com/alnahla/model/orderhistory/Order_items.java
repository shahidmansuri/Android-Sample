package com.alnahla.model.orderhistory;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
/**
 * Awesome Pojo Generator
 * */
public class Order_items{
  @SerializedName("quantity")
  @Expose
  private Integer quantity;
  @SerializedName("price")
  @Expose
  private Integer price;
  @SerializedName("item_name")
  @Expose
  private String item_name;
  public void setQuantity(Integer quantity){
   this.quantity=quantity;
  }
  public Integer getQuantity(){
   return quantity;
  }
  public void setPrice(Integer price){
   this.price=price;
  }
  public Integer getPrice(){
   return price;
  }
  public void setItem_name(String item_name){
   this.item_name=item_name;
  }
  public String getItem_name(){
   return item_name;
  }
}