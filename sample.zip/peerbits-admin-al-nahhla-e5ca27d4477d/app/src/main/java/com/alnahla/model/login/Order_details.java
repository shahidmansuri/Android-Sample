package com.alnahla.model.login;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Awesome Pojo Generator
 * */
public class Order_details implements Serializable {
  @SerializedName("payment_type")
  @Expose
  private Integer payment_type;
  @SerializedName("status_code")
  @Expose
  private Integer status_code;
  @SerializedName("restaurant_details")
  @Expose
  private Restaurant_details restaurant_details;
  @SerializedName("order_id")
  @Expose
  private Integer order_id;
  @SerializedName("timestamp")
  @Expose
  private String timestamp;
  @SerializedName("status")
  @Expose
  private String status;
  public void setPayment_type(Integer payment_type){
   this.payment_type=payment_type;
  }
  public Integer getPayment_type(){
   return payment_type;
  }
  public void setStatus_code(Integer status_code){
   this.status_code=status_code;
  }
  public Integer getStatus_code(){
   return status_code;
  }
  public void setRestaurant_details(Restaurant_details restaurant_details){
   this.restaurant_details=restaurant_details;
  }
  public Restaurant_details getRestaurant_details(){
   return restaurant_details;
  }
  public void setOrder_id(Integer order_id){
   this.order_id=order_id;
  }
  public Integer getOrder_id(){
   return order_id;
  }
  public void setTimestamp(String timestamp){
   this.timestamp=timestamp;
  }
  public String getTimestamp(){
   return timestamp;
  }
  public void setStatus(String status){
   this.status=status;
  }
  public String getStatus(){
   return status;
  }
}