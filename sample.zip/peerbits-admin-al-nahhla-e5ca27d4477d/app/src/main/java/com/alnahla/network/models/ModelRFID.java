package com.alnahla.network.models;

public class ModelRFID {

    private String tagUii;
    private String tagRssi;

    public ModelRFID(String tagUii, String tagRssi) {
        this.tagUii = tagUii;
        this.tagRssi = tagRssi;
    }

    public String getTagUii() {
        return tagUii;
    }

    public void setTagUii(String tagUii) {
        this.tagUii = tagUii;
    }

    public String getTagRssi() {
        return tagRssi;
    }

    public void setTagRssi(String tagRssi) {
        this.tagRssi = tagRssi;
    }
}
