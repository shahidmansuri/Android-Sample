package com.alnahla.model.token;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.alnahla.model.Token;

/**
 * Awesome Pojo Generator
 * */
public class Data{
  @SerializedName("token")
  @Expose
  private Token token;
  public void setToken(Token token){
   this.token=token;
  }
  public Token getToken(){
   return token;
  }
}