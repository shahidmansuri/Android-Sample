package com.alnahla.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Awesome Pojo Generator
 */
public class NewNotifiactionData {
    @SerializedName("notification_details")
    @Expose
    private List<Notification_details> notification_details;
    @SerializedName("is_last")
    @Expose
    private Integer is_last;
    @SerializedName("message")
    @Expose
    private String message;

    public void setNotification_details(List<Notification_details> notification_details) {
        this.notification_details = notification_details;
    }

    public List<Notification_details> getNotification_details() {
        return notification_details;
    }

    public void setIs_last(Integer is_last) {
        this.is_last = is_last;
    }

    public Integer getIs_last() {
        return is_last;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}