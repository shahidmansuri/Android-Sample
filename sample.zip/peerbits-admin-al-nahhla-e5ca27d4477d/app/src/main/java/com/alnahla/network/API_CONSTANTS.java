package com.alnahla.network;

public class API_CONSTANTS {
    public static final String IMAGE = "image";
    public static final String FULL_NAME = "full_name";
    public static final String MESSAGE = "message";
    public static final String ORDER_ID = "order_id";
    public static final String OLD_PASS = "old_password";
    public static final String NEW_PASS = "new_password";

    public static final String REASON_ID = "reason_id";
    public static final String OTHERS_COMMENT = "comment";

    public static final String ETA = "eta";
    public static final String IS_ACCEPTED = "is_accepted";
    public static final String SUBJECT = "subject";
    public static final String ORDER_STATUS = "order_status";
    public static final String DRIVER_LATITUDE = "driver_latitude";
    public static final String DRIVER_LONGITUDE = "driver_longitude";
    public static final String REST_DETAILS = "restaurant_details";
    public static final String DATA = "data";
    public static final String ORDER_DETAILS = "order_details";
    public static final String NOTIFICATION_TYPE = "notification_type";
    public static final String NOTI_TYPE_CANCEL_ORDER_ADMIN = "cancel_order_by_admin";
    public static final String NOTI_TYPE_CANCEL_ORDER_REST = "cancel_order_by_restaurant";
    public static final String NOTIFICATION_TYPE_NEW_ORDER = "new_order";
    public static final String NOTIFICATION_TYPE_ASSIGNED_ORDER = "assign_order";

    public static final String START = "start";
    public static final String LIMIT = "limit";
    public static final String FROM_DATE = "from_date";
    public static final String TO_DATE = "to_date";
    public static final String PAYMENT_TYPE = "payment_type";

    public static final String DEVICE_ID = "device_id";
    public static final String DEVICE_TYPE = "device_type";

    public static final String PHONE_NO = "phone_no";
    public static final String DIAL_CODE = "dial_code";
    public static final String IS_FOR_REQ = "is_for_request";


//    public static final int CANCELED = 3;
//    public static final int ACCEPTED = 2;

    public static final int REASON_ID_OTHERS = 0; // this value is from backend fixed

    public static final String OTP = "otp";
}
