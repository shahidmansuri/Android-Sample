package com.alnahla.service;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.IBinder;

public class RingtonePlayingService extends Service {

    private MediaPlayer player;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            //  Uri notification = Uri.parse("android.resource://com.alnahla/" + R.raw.notification);
            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            player = MediaPlayer.create(getApplicationContext(), notification);
            player.setLooping(true);
            player.start();

        } catch (Exception e) {
            e.printStackTrace();
        }


        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        player.stop();
    }
}