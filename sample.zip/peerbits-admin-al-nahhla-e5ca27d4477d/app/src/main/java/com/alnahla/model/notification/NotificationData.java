package com.alnahla.model.notification;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

/**
 * Awesome Pojo Generator
 */
public class NotificationData implements Serializable {
    @SerializedName("order_id")
    @Expose
    private String order_id;

    @SerializedName("payment_type")
    @Expose
    private String payment_type;

    @SerializedName("status")
    @Expose
    private String status;

    @SerializedName("product_type")
    @Expose
    private String product_type;

    @SerializedName("order_price")
    @Expose
    private String order_price;

    @SerializedName("order_time")
    @Expose
    private String order_time; @SerializedName("time")
    @Expose
    private String time;

    @SerializedName("user_info")
    @Expose
    private UserInfoFromNotification user_info;

    @SerializedName("order_type_compelete")
    @Expose
    private List<OrderTypeCompelete> order_type_compelete;

    @SerializedName("order_type_refilling")
    @Expose
    private List<OrderTypeCompelete> order_type_refilling;

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getPayment_type() {
        return payment_type;
    }

    public void setPayment_type(String payment_type) {
        this.payment_type = payment_type;
    }

    public String getOrder_price() {
        return order_price;
    }

    public void setOrder_price(String order_price) {
        this.order_price = order_price;
    }

    public String getOrder_time() {
        return order_time;
    }

    public void setOrder_time(String order_time) {
        this.order_time = order_time;
    }

    public UserInfoFromNotification getUser_info() {
        return user_info;
    }

    public void setUser_info(UserInfoFromNotification user_info) {
        this.user_info = user_info;
    }

    public List<OrderTypeCompelete> getOrder_type_compelete() {
        return order_type_compelete;
    }

    public void setOrder_type_compelete(List<OrderTypeCompelete> order_type_compelete) {
        this.order_type_compelete = order_type_compelete;
    }

    public List<OrderTypeCompelete> getOrder_type_refilling() {
        return order_type_refilling;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setOrder_type_refilling(List<OrderTypeCompelete> order_type_refilling) {
        this.order_type_refilling = order_type_refilling;

    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getProduct_type() {
        return product_type;
    }

    public void setProduct_type(String product_type) {
        this.product_type = product_type;
    }
}