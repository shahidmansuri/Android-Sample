package com.alnahla.model.orderhistory;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
/**
 * Awesome Pojo Generator
 * */
public class Customer_details{
  @SerializedName("customer_address")
  @Expose
  private String customer_address;
  @SerializedName("customer_contactno")
  @Expose
  private Integer customer_contactno;
  @SerializedName("customer_latitude")
  @Expose
  private Double customer_latitude;
  @SerializedName("customer_dialcode")
  @Expose
  private Integer customer_dialcode;
  @SerializedName("customer_profile_image")
  @Expose
  private String customer_profile_image;
  @SerializedName("customer_name")
  @Expose
  private String customer_name;
  @SerializedName("customer_longitude")
  @Expose
  private Double customer_longitude;
  @SerializedName("customer_id")
  @Expose
  private Integer customer_id;
  public void setCustomer_address(String customer_address){
   this.customer_address=customer_address;
  }
  public String getCustomer_address(){
   return customer_address;
  }
  public void setCustomer_contactno(Integer customer_contactno){
   this.customer_contactno=customer_contactno;
  }
  public Integer getCustomer_contactno(){
   return customer_contactno;
  }
  public void setCustomer_latitude(Double customer_latitude){
   this.customer_latitude=customer_latitude;
  }
  public Double getCustomer_latitude(){
   return customer_latitude;
  }
  public void setCustomer_dialcode(Integer customer_dialcode){
   this.customer_dialcode=customer_dialcode;
  }
  public Integer getCustomer_dialcode(){
   return customer_dialcode;
  }
  public void setCustomer_profile_image(String customer_profile_image){
   this.customer_profile_image=customer_profile_image;
  }
  public String getCustomer_profile_image(){
   return customer_profile_image;
  }
  public void setCustomer_name(String customer_name){
   this.customer_name=customer_name;
  }
  public String getCustomer_name(){
   return customer_name;
  }
  public void setCustomer_longitude(Double customer_longitude){
   this.customer_longitude=customer_longitude;
  }
  public Double getCustomer_longitude(){
   return customer_longitude;
  }
  public void setCustomer_id(Integer customer_id){
   this.customer_id=customer_id;
  }
  public Integer getCustomer_id(){
   return customer_id;
  }
}