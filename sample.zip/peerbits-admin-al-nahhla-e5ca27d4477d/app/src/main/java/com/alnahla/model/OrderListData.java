package com.alnahla.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Awesome Pojo Generator
 */
public class OrderListData {
    @SerializedName("order_date")
    @Expose
    private String order_date;
    @SerializedName("order_status")
    @Expose
    private String order_status;
    @SerializedName("quantity")
    @Expose
    private String quantity;
    @SerializedName("total_price")
    @Expose
    private String total_price;
    @SerializedName("user_image")
    @Expose
    private String user_image;
    @SerializedName("Payment_mode")
    @Expose
    private String Payment_mode;
    @SerializedName("user_name")
    @Expose
    private String user_name;
    @SerializedName("price")
    @Expose
    private String price;
    @SerializedName("user_address")
    @Expose
    private String user_address;
    @SerializedName("order_id")
    @Expose
    private int order_id;

    public void setOrder_date(String order_date) {
        this.order_date = order_date;
    }

    public String getOrder_date() {
        return order_date;
    }

    public void setOrder_status(String order_status) {
        this.order_status = order_status;
    }

    public String getOrder_status() {
        return order_status;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setTotal_price(String total_price) {
        this.total_price = total_price;
    }

    public String getTotal_price() {
        return total_price;
    }

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }

    public String getUser_image() {
        return user_image;
    }

    public void setPayment_mode(String Payment_mode) {
        this.Payment_mode = Payment_mode;
    }

    public String getPayment_mode() {
        return Payment_mode;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPrice() {
        return price;
    }

    public void setUser_address(String user_address) {
        this.user_address = user_address;
    }

    public String getUser_address() {
        return user_address;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public int getOrder_id() {
        return order_id;
    }
}