package com.alnahla.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.customtabs.CustomTabsIntent;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import com.alnahla.AppConstants;
import com.alnahla.R;
import com.alnahla.service.PingService;
import com.alnahla.ui.activity.OrderActivity;
import com.alnahla.ui.activity.SignInActivity;
import com.alnahla.ui.activity.WelcomeActivity;
import com.alnahla.ui.dialog.MessageDialog;
import com.alnahla.utils.CommonDialogs;
import com.alnahla.utils.CustomProgressDialog;
import com.alnahla.utils.Utils;
import com.alnahla.utils.glideUtils.GlideLoader;
import com.alnahla.utils.pref.PreferenceKeys;
import com.alnahla.utils.pref.SessionManager;
import com.google.gson.Gson;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.util.ArrayList;
import java.util.List;


/**
 * Each Activity must extends BaseActivity.
 * It is having some common implementation that each Application is having
 */
public abstract class BaseActivity extends AppCompatActivity {
    protected boolean shouldPerformDispatchTouch = true;
    protected SessionManager session;
    protected GlideLoader glideLoader;
    //public TTextView title;
    public Toolbar toolbar;
    public Gson gson;

    static {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }

    // Progress
    private CustomProgressDialog progressDialog;

    // CommonDialogs
    protected CommonDialogs mDialogs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        session = new SessionManager(getApplicationContext());
        mDialogs = new CommonDialogs(this);
        glideLoader = new GlideLoader(this);
        gson = new Gson();
    }

    public void showSnackBar(String message) {
        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_LONG);
        View snackBarView = snackbar.getView();
        snackBarView.setBackgroundColor(ContextCompat.getColor(findViewById(android.R.id.content).getContext(), R.color.colorBtnRed));
        snackbar.show();
    }

    public void showSnackBar(String message, Snackbar.Callback callback) {
        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_LONG);
        View snackBarView = snackbar.getView();
        snackBarView.setBackgroundColor(ContextCompat.getColor(findViewById(android.R.id.content).getContext(), R.color.colorPrimary));

        if (callback != null) {
            snackbar.addCallback(callback);
        }
        snackbar.show();
    }


    public void setUpToolbarWithBackArrow(String strTitle) {
        setUpToolbarWithBackArrow(strTitle, true);
    }

    public void setUpToolbarWithBackArrow(String strTitle, boolean isBackArrow) {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.setDisplayHomeAsUpEnabled(isBackArrow);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back_arrow_green);
           /* title = (TTextView) toolbar.findViewById(R.id.title);
            title.setText(strTitle);*/
        }
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    public void showToastShort(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    public void showToastLong(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }


    // For Load more ProfileModel
    public boolean isLastItemDisplaying(RecyclerView recyclerView) {
        if (recyclerView.getAdapter().getItemCount() != 0) {
            int lastVisibleItemPosition = ((LinearLayoutManager) recyclerView.getLayoutManager()).findLastCompletelyVisibleItemPosition();
            return lastVisibleItemPosition != RecyclerView.NO_POSITION && lastVisibleItemPosition == recyclerView.getAdapter().getItemCount() - 1;
        }
        return false;
    }

    public void showErrorSnackBar(String message) {
        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_LONG);
        View snackBarView = snackbar.getView();
        snackBarView.setBackgroundColor(ContextCompat.getColor(findViewById(android.R.id.content).getContext(), R.color.colorBtnRed));
        snackbar.show();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        View view = getCurrentFocus();
        boolean ret = super.dispatchTouchEvent(event);
        if (shouldPerformDispatchTouch) {
            if (view instanceof EditText) {
                try {
                    View w = getCurrentFocus();
                    int[] scrcords = new int[2];
                    w.getLocationOnScreen(scrcords);
                    float x = event.getRawX() + w.getLeft() - scrcords[0];
                    float y = event.getRawY() + w.getTop() - scrcords[1];

                    if (event.getAction() == MotionEvent.ACTION_UP && (x < w.getLeft() || x >= w.getRight() || y < w.getTop() || y > w.getBottom())) {
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        if (getWindow() != null && getWindow().getCurrentFocus() != null) {
                            imm.hideSoftInputFromWindow(getWindow().getCurrentFocus().getWindowToken(), 0);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return ret;
    }


    /**
     * Show Progress Dailog without any message
     */
    public void showProgress() {
        showProgress(null);
    }

    /**
     * Show Progress dialog with Message
     *
     * @param message Message to show under Progress
     */
    public void showProgress(String message) {
        if (progressDialog != null) {
            progressDialog.show(message);
        } else {
            progressDialog = new CustomProgressDialog(this, message);
            progressDialog.show();
        }
    }


    /**
     * Stop Progress if running and dismiss progress Dialog
     */
    public void stopProgress() {
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }

    /**
     * To check weather the progress is running
     *
     * @return True if Progress is running false else.
     */
    protected boolean isProgressShowing() {
        return progressDialog != null && progressDialog.isShowing();
    }
    public void unBindPingService() {
        stopService(new Intent(this, PingService.class));
    }
    public void errorHandleFromApi(ArrayList<String> messages, final int statusCode) {
//        if (messages.size() == 1) {
//            showErrorSnackBar(messages.get(0));
//            if(statusCode == AppConstants.UNAUTHORIZED){
//                SignInActivity.launch(BaseActivity.this,true);
//            }
//        } else {
//            AlertDialog.Builder builder = new AlertDialog.Builder(this);
//            builder.setTitle(R.string.str_errors);
//            String[] items = messages.toArray(new String[0]);
//            builder.setItems(items, null);
//            builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
//                @Override
//                public void onClick(DialogInterface dialogInterface, int i) {
//
//                    dialogInterface.dismiss();
//                    if(statusCode == AppConstants.UNAUTHORIZED){
//
//                        session.clearSession();
//                        unBindPingService();
//                        SignInActivity.launch(BaseActivity.this,true);
//                    }
//                }
//            });
//            AlertDialog alert = builder.create();
//            alert.show();
//        }

        if (messages.size() > 0) {
            new MessageDialog(BaseActivity.this)
                    .setTitle(getString(R.string.errors))
                    .setMessage(messages.get(0))
                    .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();
                            if (statusCode == AppConstants.UNAUTHORIZED) {
                                session.clearSession();
                                unBindPingService();

                                SignInActivity.launch(BaseActivity.this, true);
                            }
                        }
                    })
                    .cancelable(false)
                    .show();
        }

    }

    public void openActivity(Class<?> aClass) {
        startActivity(new Intent(this, aClass));
    }

    public void showPermissionSettingDialog(String message) {
        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
        builder.setTitle("Need Permission");
        builder.setMessage(message);
        builder.setPositiveButton(R.string.app_settings, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.addCategory(Intent.CATEGORY_DEFAULT);
                intent.setData(Uri.parse("package:" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                intent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                startActivity(intent);
                dialog.dismiss();
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();
    }

    private void openCustomTabs(Uri uri) {
        CustomTabsIntent.Builder intentBuilder = new CustomTabsIntent.Builder();
        intentBuilder.setToolbarColor(ContextCompat.getColor(this, R.color.colorPrimary));
        intentBuilder.setSecondaryToolbarColor(ContextCompat.getColor(this, R.color.colorPrimaryDark));
        intentBuilder.setStartAnimations(this, R.anim.slide_in_right, R.anim.slide_out_left);
        intentBuilder.setExitAnimations(this, android.R.anim.slide_in_left,
                android.R.anim.slide_out_right);
        CustomTabsIntent customTabsIntent = intentBuilder.build();
        customTabsIntent.launchUrl(this, uri);
    }

    public String getRealPathFromURI(Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
        int column_index;
        if (cursor != null) {
            column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        }
        return null;
    }

    public static String getAWSUrl(String bucketName, String fileName) {
        return "https://" + bucketName + ".s3.amazonaws.com/" + fileName;
    }

    public void callPhone(String number) {
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:" + number));
        startActivity(callIntent);
    }

    public void setStatusBarColor(Activity activity, int colorCode) {
        Window window = activity.getWindow();

// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

// finally change the color
        window.setStatusBarColor(colorCode);
    }


    public String findString(int strID) {
        return getResources().getString(strID);
    }

    @Override
    protected void onResume() {
        super.onResume();
        //when user switch from background to foreground, this method gets call
        Utils.setIsAppInForeground(true);
        /*
            Check Internet Connectivity
         */

    }

    @Override
    protected void onPause() {
        super.onPause();
        //when user switch from foreground to background, this method gets call
        Utils.setIsAppInForeground(false);
    }

    public void hideStatusBar() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    public void showStatusBar() {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    public void hideToolBar() {
        getSupportActionBar().hide();
    }

    public void showToolBar() {
        getSupportActionBar().show();
    }

    /*
        Currently not working, need some R&D here
     */
    public void setDialogActivityCancelable(boolean isCancelable,Activity activity){
        activity.setFinishOnTouchOutside(!isCancelable);
    }

    public void showSimpleMessageDialog(String title,String body){
        new MessageDialog(this)
                .setTitle(title)
                .setMessage(body)
                .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                })
                .cancelable(false)
                .show();
    }

    public void launchWazeApp(double lat, double lng) {
        try {
            // Launch Waze to look for lat&lng:
            String url = AppConstants.LINK_WAZE+String.valueOf(lat)+","+String.valueOf(lng)+"&navigate=yes&zoom=17";
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (ActivityNotFoundException ex) {
            // If Waze is not installed, open it in Google Play:
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(AppConstants.LINK_WAZE_GPLAY));
            startActivity(intent);
        }
    }

    public void launchNavigationIntent(double dstLat, double dstLng) {
        try {
            // Launch directions for lat&lng
            Intent intent = new Intent(android.content.Intent.ACTION_VIEW,
                    Uri.parse(AppConstants.MAP_NAVIGATION+dstLat+","+dstLng));
            startActivity(intent);
        } catch (ActivityNotFoundException ex) {
            // If Waze is not installed, open it in Google Play:

        }
    }
    public double meterDistanceBetweenPoints(double lat_a, double lng_a, double lat_b, double lng_b) {
        float pk = (float) (180.f / Math.PI);

        float a1 = (float) (lat_a / pk);
        float a2 = (float) (lng_a / pk);
        float b1 = (float) (lat_b / pk);
        float b2 = (float) (lng_b / pk);

        double t1 = Math.cos(a1) * Math.cos(a2) * Math.cos(b1) * Math.cos(b2);
        double t2 = Math.cos(a1) * Math.sin(a2) * Math.cos(b1) * Math.sin(b2);
        double t3 = Math.sin(a1) * Math.sin(b1);
        double tt = Math.acos(t1 + t2 + t3);

        return 6366000 * tt;
    }

    public void openApplicationSettingScreen(Activity activity, int reqCode) {
//        Intent viewIntent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
//        activity.startActivityForResult(viewIntent,reqCode);

        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", activity.getPackageName(), null);
        intent.setData(uri);
        activity.startActivityForResult(intent, reqCode);
    }
    /*
        When you get FCM notification, and your application
     */
    public void openAppLock() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
    }
}
