package com.alnahla.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Awesome Pojo Generator
 */
public class IsOnlineData {
    @SerializedName("data")
    @Expose
    private OnlineData data;

    public void setData(OnlineData data) {
        this.data = data;
    }

    public OnlineData getData() {
        return data;
    }
}