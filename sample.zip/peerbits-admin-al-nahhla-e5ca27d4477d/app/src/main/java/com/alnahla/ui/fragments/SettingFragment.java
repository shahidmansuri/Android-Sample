package com.alnahla.ui.fragments;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.alnahla.R;
import com.alnahla.databinding.FragmentSettingBinding;
import com.alnahla.model.cms.CmsModel;
import com.alnahla.network.API_EndPoints;
import com.alnahla.network.NetworkCall;
import com.alnahla.network.listeners.RetrofitResponseListener;
import com.alnahla.ui.BaseFragment;
import com.alnahla.ui.activity.ChangePasswordActivity;
import com.alnahla.ui.activity.ContactUsActivity;
import com.alnahla.ui.activity.EditProfileActivity;
import com.alnahla.ui.activity.FAQActivity;
import com.alnahla.utils.pref.PreferenceKeys;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class SettingFragment extends BaseFragment implements View.OnClickListener {
    private FragmentSettingBinding mBinder;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (mBinder == null) {
            mBinder = DataBindingUtil.inflate(inflater, R.layout.fragment_setting, container, false);
        }
        setOnListner();
        getCMSLinks();

        return mBinder.getRoot();

    }

    private void setOnListner() {
        mBinder.tvEditProfile.setOnClickListener(this);
        mBinder.tvChangePassword.setOnClickListener(this);
        mBinder.tvContactUs.setOnClickListener(this);

        mBinder.tvAboutUs.setOnClickListener(this);
        mBinder.tvTermConditions.setOnClickListener(this);
        mBinder.tvPrivacyPolicy.setOnClickListener(this);

        mBinder.tvFAQ.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.tvChangePassword:
                intent = new Intent(getActivity(), ChangePasswordActivity.class);
                startActivity(intent);
                break;
            case R.id.tvEditProfile:
                intent = new Intent(getActivity(), EditProfileActivity.class);
                startActivity(intent);
                break;
            case R.id.tvContactUs:
                intent = new Intent(getActivity(), ContactUsActivity.class);
                startActivity(intent);
                break;
            case R.id.tvAboutUs:
                openCustomTabs(Uri.parse(session.getValueFromKey(PreferenceKeys.KEY_CMS_ABOUTUS, "")));
                break;
            case R.id.tvTermConditions:
                openCustomTabs(Uri.parse(session.getValueFromKey(PreferenceKeys.KEY_CMS_TANDC, "")));
                break;
            case R.id.tvPrivacyPolicy:
                openCustomTabs(Uri.parse(session.getValueFromKey(PreferenceKeys.KEY_CMS_PRIVACY, "")));
                break;

            case R.id.tvFAQ:
                intent = new Intent(getActivity(), FAQActivity.class);
                startActivity(intent);
                break;
        }
    }

    private void getCMSLinks() {
        HashMap<String, String> params = new HashMap<>();

        NetworkCall.with(getActivity())
                .setEndPoint(API_EndPoints.GET_CMS)
                .setRequestParams(params)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        GsonBuilder gsonBuilder = new GsonBuilder();
                        Gson gson = gsonBuilder.create();
                        CmsModel cmsModel = gson.fromJson(response, CmsModel.class);
                        session.setValueFromKey(PreferenceKeys.KEY_CMS_ABOUTUS, cmsModel.getData().getAbout_us());
                        session.setValueFromKey(PreferenceKeys.KEY_CMS_PRIVACY, cmsModel.getData().getPrivacy_policy());
                        session.setValueFromKey(PreferenceKeys.KEY_CMS_TANDC, cmsModel.getData().getTerms_and_conditions());
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        errorHandleFromApi(getActivity(), messages,statusCode);
                    }
                }).makeCall();
    }
}
