package com.alnahla.ui.fragments;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.databinding.DataBindingUtil;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetBehavior;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.OnScrollListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.alnahla.AppConstants;
import com.alnahla.AppStrings;
import com.alnahla.R;
import com.alnahla.databinding.FragmentHistoryBinding;
import com.alnahla.interfaces.InterfaceAPI;
import com.alnahla.model.OrderHistoryData;
import com.alnahla.model.order_detais.Order_details;
import com.alnahla.network.common_api.ApisCommon;
import com.alnahla.ui.BaseFragment;
import com.alnahla.ui.activity.OrderActivity;
import com.alnahla.ui.adapter.OrderHistoryAdapter;
import com.alnahla.widget.RelativeRadioGroup;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;


public class HistoryFragment extends BaseFragment implements View.OnClickListener {

    private FragmentHistoryBinding mBinder;

    private BottomSheetBehavior bottomSheetBehavior;
    OrderHistoryData orderHistoryData;
    OrderHistoryAdapter orderHistoryAdapter;
    private List<Order_details> mOrderHistoryList = new ArrayList<>();
    private int start = 0;
    private int limit = 10;
    private boolean isLoading = false;
    private int isLast = 1;
    private String order_status = "", payment_type = "";

    private EditText etFromDate, etToDate;
    private RadioGroup rgPayment;
    private RadioButton rbPaymentSelect = null;
    private RadioButton rbOrderStatusSelect = null;
    private RelativeRadioGroup rgOrderStatus;

    private android.app.DatePickerDialog dateStartPickerDialog, dateEndPickerDialog;
    private String start_date = "";
    private String end_date = "";
    private SimpleDateFormat dateFormatter;
    private Calendar newStartDate, newEndDate;
    private ApisCommon apisCommon = new ApisCommon();
    private final int ORDER_DETAILS = 1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (mBinder == null) {
            mBinder = DataBindingUtil.inflate(inflater, R.layout.fragment_history, container, false);
        }

        init();
        setListners();

        return mBinder.getRoot();
    }

    private void init() {

        mBinder.getRoot().findViewById(R.id.bottom_sheet);
        bottomSheetBehavior = BottomSheetBehavior.from(mBinder.getRoot().findViewById(R.id.bottom_sheet));

        etFromDate = mBinder.getRoot().findViewById(R.id.etFromDate);
        etToDate = mBinder.getRoot().findViewById(R.id.etToDate);

        rgPayment = mBinder.getRoot().findViewById(R.id.rgPayment);
        rgOrderStatus = mBinder.getRoot().findViewById(R.id.rgOrderStatus);

        bottomSheetCases();
        paymentSelection();
        orderStatusSelection();
        setStartDateTimeField();
        setEndDateTimeField();
        apiOrderHistory();
    }

    private void apiOrderHistory() {

        int intPayType = AppConstants.NO_VALUE_SET;
        int intOrderStatus = AppConstants.NO_VALUE_SET;

        if (payment_type.equalsIgnoreCase(AppStrings.TYPE_CASH)) {
            intPayType = AppConstants.CASH;
        } else if (payment_type.equalsIgnoreCase(AppStrings.TYPE_CARD)) {
            intPayType = AppConstants.CARD;
        }

        if (order_status.equalsIgnoreCase(AppStrings.COMPLETED)) {
            intOrderStatus = AppConstants.COMPLETED;
        } else if (order_status.equalsIgnoreCase(AppStrings.CANCEL_BY_ADMIN)) {
            intOrderStatus = AppConstants.CANCEL_BY_ADMIN;
        } else if (order_status.equalsIgnoreCase(AppStrings.CANCEL_BY_RESTAURENT)) {
            intOrderStatus = AppConstants.CANCEL_BY_RESTAURENT;
        }

        apisCommon.apiOrderHistoryList(mContext, start, limit, intPayType, intOrderStatus, start_date, end_date, new InterfaceAPI() {
            @Override
            public void onPreExecute() {
                showProgress();
            }

            @Override
            public void apiSuccessful(int statusCode, JSONObject jsonObject, String response) {
                stopProgress();
                isLoading = false;
                if (start == 0) {
                    mOrderHistoryList.clear();
                    GsonBuilder gsonBuilder = new GsonBuilder();
                    Gson gson = gsonBuilder.create();
                    orderHistoryData = gson.fromJson(jsonObject.toString(), OrderHistoryData.class);
                    isLast = orderHistoryData.getIs_last();
                    mOrderHistoryList.addAll(orderHistoryData.getOrder_history());
                    setRecycleView(mOrderHistoryList);
                    populateData();
                    showStatusBar();
                    showToolBar();
                }

            }

            @Override
            public void apiFailed(int statusCode,ArrayList<String> messages) {
                stopProgress();
                errorHandleFromApi(mActivity, messages,statusCode);
            }
        });
    }

    private void populateData() {
        if (mOrderHistoryList.size() > 0) {
            mBinder.rvOrderHistory.setVisibility(View.VISIBLE);
            mBinder.tvNoData.setVisibility(View.GONE);
        } else {
            mBinder.tvNoData.setVisibility(View.VISIBLE);
            mBinder.rvOrderHistory.setVisibility(View.GONE);
        }
    }

    private void setRecycleView(List<Order_details> list) {
        orderHistoryAdapter = new OrderHistoryAdapter(this, list, glideLoader);
        mBinder.rvOrderHistory.setLayoutManager(new LinearLayoutManager(mContext));
        mBinder.rvOrderHistory.setAdapter(orderHistoryAdapter);
        orderHistoryAdapter.notifyDataSetChanged();

        mBinder.rvOrderHistory.addOnScrollListener(new OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (isLastItemDisplaying(mBinder.rvOrderHistory)) {
                    if (isLast == 1) {
                    } else {
                        if (!isLoading) {
                            isLoading = true;
                            start = start + limit;
                            apiOrderHistory();
                        }
                    }
                }
            }
        });

    }

    private void paymentSelection() {

        rgPayment.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                RadioButton rb = group.findViewById(checkedId);

                setRadioButtonCheckUncheck(rbPaymentSelect, false);
                rbPaymentSelect = setRadioButtonCheckUncheck(rb, true);
            }
        });
    }

    private void orderStatusSelection() {

        rgOrderStatus.setOnCheckedChangeListener(new RelativeRadioGroup.OnCheckedChangeListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onCheckedChanged(RelativeRadioGroup group, int checkedId) {

                RadioButton rb = group.findViewById(checkedId);

                setRadioButtonCheckUncheck(rbOrderStatusSelect, false);
                rbOrderStatusSelect = setRadioButtonCheckUncheck(rb, true);

            }
        });
    }

    private void bottomSheetCases() {

        bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                switch (newState) {

                    case BottomSheetBehavior.STATE_HIDDEN:
                        break;

                    case BottomSheetBehavior.STATE_EXPANDED:
                        break;

                    case BottomSheetBehavior.STATE_COLLAPSED:
                        break;

                    case BottomSheetBehavior.STATE_DRAGGING:
                        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                        break;

                    case BottomSheetBehavior.STATE_SETTLING:
                        break;
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
            }
        });
    }

    private void setListners() {

        mBinder.getRoot().findViewById(R.id.ivFilter).setOnClickListener(this);
        mBinder.getRoot().findViewById(R.id.ivClose).setOnClickListener(this);
        mBinder.getRoot().findViewById(R.id.btnApply).setOnClickListener(this);
        mBinder.getRoot().findViewById(R.id.tvReset).setOnClickListener(this);
        mBinder.getRoot().findViewById(R.id.etFromDate).setOnClickListener(this);
        mBinder.getRoot().findViewById(R.id.etToDate).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.ivFilter:
                // Hide status bar
                hideStatusBar();

                // Hide tool bar
                hideToolBar();

                mBinder.getRoot().findViewById(R.id.ivFilter).setVisibility(View.GONE);
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                mBinder.rvOrderHistory.setVisibility(View.GONE);
                mBinder.tvNoData.setVisibility(View.GONE);
                toggleBottomSheet();
                break;

            case R.id.ivClose:
                // Show status bar
                showStatusBar();

                // show tool bar
                showToolBar();

                mBinder.getRoot().findViewById(R.id.ivClose).setVisibility(View.VISIBLE);
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                mBinder.rvOrderHistory.setVisibility(View.VISIBLE);
               // mBinder.tvNoData.setVisibility(View.VISIBLE);
                mBinder.getRoot().findViewById(R.id.ivFilter).setVisibility(View.VISIBLE);
                break;

            case R.id.btnApply:

                if (isValid()) {
//                    start_date = etFromDate.getText().toString();
//                    end_date = etToDate.getText().toString();
                    if (rbPaymentSelect != null)
                        payment_type = rbPaymentSelect.getText().toString();
                    if (rbOrderStatusSelect != null)
                        order_status = rbOrderStatusSelect.getText().toString();

                    apiOrderHistory();
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
//                    mBinder.rvOrderHistory.setVisibility(View.VISIBLE);
                    mBinder.getRoot().findViewById(R.id.ivFilter).setVisibility(View.VISIBLE);
                }
                break;

            case R.id.tvReset:
                showStatusBar();
                showToolBar();
                clearFilterData();
                apiOrderHistory();
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                mBinder.getRoot().findViewById(R.id.ivFilter).setVisibility(View.VISIBLE);
                break;

            case R.id.etFromDate:
                dateStartPickerDialog.show();
                etToDate.setText("");
                end_date = "";
                break;

            case R.id.etToDate:
                dateEndPickerDialog.show();
                break;
        }

    }

    private RadioButton setRadioButtonCheckUncheck(RadioButton radioButton, boolean isCheck) {
        if (null != radioButton) {
            int rbDrawable = 0, rbStyle = 0;
            String fontPath = "fonts/";
            if (isCheck) {
                rbDrawable = R.drawable.bg_select_green;
                rbStyle = R.style.Button_Filter_Selected;
                fontPath = fontPath + getResources().getString(R.string.font_notobold);
            } else {
                rbDrawable = R.drawable.bg_unselect_grey;
                rbStyle = R.style.Button_Filter_Unselected;
                fontPath = fontPath + getResources().getString(R.string.font_notoRegular);
            }
            radioButton.setBackground(ContextCompat.getDrawable(mActivity, rbDrawable));
            radioButton.setTextAppearance(mActivity, rbStyle);
            Typeface type = Typeface.createFromAsset(mActivity.getAssets(), fontPath);
            radioButton.setTypeface(type);
        }
        return radioButton;

    }

//    private int checkOrderStatus() {
//        int orderStatus;
//        if (order_status.equalsIgnoreCase(getResources().getString(R.string.delivered))) {
//            orderStatus = AppConstants.DELIVERED;
//        } else if (order_status.equalsIgnoreCase(getResources().getString(R.string.cancelled_by_restaurant))) {
//            orderStatus = AppConstants.CANCEL_BY_RESTAURENT;
//        } else if (order_status.equalsIgnoreCase(getResources().getString(R.string.cancelled_by_admin))) {
//            orderStatus = AppConstants.CANCEL_BY_ADMIN;
//        } else {
//            orderStatus = -1;
//        }
//        return orderStatus;
//    }

//    private int checkPaymentType() {
//        int paymentType;
//        if (payment_type.equalsIgnoreCase(getResources().getString(R.string.cash))) {
//            paymentType = AppConstants.CASH;
//        } else if (payment_type.equalsIgnoreCase(getResources().getString(R.string.card))) {
//            paymentType = AppConstants.CARD;
//        } else {
//            paymentType = -1;
//        }
//        return paymentType;
//    }

    private boolean isValid() {
        boolean isValid = true;
        if (!start_date.equalsIgnoreCase(AppConstants.NO_VALUE_SET_STRING)) {
            if (end_date.equals("")) {
                showErrorSnackBar(getString(R.string.err_to_date));
                etToDate.requestFocus();
                isValid = false;
            }
        } else if (!end_date.equalsIgnoreCase(AppConstants.NO_VALUE_SET_STRING)) {
            if (start_date.equals("")) {
                showErrorSnackBar(getString(R.string.err_from_date));
                etFromDate.requestFocus();
                isValid = false;
            }
        }
//        if (start_date.equals("")) {
//            showErrorSnackBar(getString(R.string.err_from_date));
//            etFromDate.requestFocus();
//        } else if (end_date.equals("")) {
//            showErrorSnackBar(getString(R.string.err_to_date));
//            etToDate.requestFocus();
//        } else if (rgPayment.getCheckedRadioButtonId() == -1) {
//            showErrorSnackBar(getString(R.string.err_payment_type));
//        } else if (rgOrderStatus.getCheckedRadioButtonId() == -1) {
//            showErrorSnackBar(getString(R.string.err_order_status));
//        } else {
//            isValid = true;
//        }
        return isValid;
    }

    private void clearFilterData() {

        etFromDate.setText("");
        etToDate.setText("");

        start_date = "";
        end_date = "";

        payment_type = "";
        order_status = "";

        rgPayment.clearCheck();
        rgOrderStatus.clearCheck();

        setRadioButtonCheckUncheck(rbPaymentSelect, false);
        setRadioButtonCheckUncheck(rbOrderStatusSelect, false);
    }

    private void toggleBottomSheet() {
        if (bottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED &&
                bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_HIDDEN) {

            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);

        } else {
            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        }
    }

    private void setStartDateTimeField() {
        dateFormatter = new SimpleDateFormat(AppConstants.DATE_FORMAT, Locale.getDefault());
        final Calendar newCalendar = Calendar.getInstance();

        dateStartPickerDialog = new android.app.DatePickerDialog(mActivity, R.style.MyDatePickerDialogTheme, new android.app.DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                newStartDate = Calendar.getInstance();

               /* newStartDate.set(Calendar.HOUR_OF_DAY, 0);
                newStartDate.set(Calendar.MINUTE, 0);
                newStartDate.set(Calendar.SECOND, 0);
                newStartDate.set(Calendar.MILLISECOND, 0);*/

                newStartDate.set(year, monthOfYear, dayOfMonth,0,0,0);
                etFromDate.setText(dateFormatter.format(newStartDate.getTime()));
                start_date = String.valueOf(newStartDate.getTimeInMillis());
                setEndDateTimeField();

                /*
                    Setting Date according to starting date
                 */

                Calendar calendar = Calendar.getInstance();
                calendar.set(year, monthOfYear, dayOfMonth);
                dateEndPickerDialog.getDatePicker().setMinDate(calendar.getTimeInMillis());
            }

        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        dateStartPickerDialog.setButton(DialogInterface.BUTTON_POSITIVE, getResources().getString(R.string.ok), dateStartPickerDialog);
        dateStartPickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE, getResources().getString(R.string.str_cancel), dateStartPickerDialog);
    }

    private void setEndDateTimeField() {
        dateFormatter = new SimpleDateFormat(AppConstants.DATE_FORMAT, Locale.US);
        final Calendar newCalendar = Calendar.getInstance();
        dateEndPickerDialog = new android.app.DatePickerDialog(mActivity, R.style.MyDatePickerDialogTheme, new android.app.DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                newEndDate = Calendar.getInstance();

               /* newEndDate.set(Calendar.HOUR_OF_DAY, 23);
                newEndDate.set(Calendar.MINUTE, 59);
                newEndDate.set(Calendar.SECOND, 59);
                newEndDate.set(Calendar.MILLISECOND, 999);*/

                newEndDate.set(year, monthOfYear, dayOfMonth,23,59,59);
                etToDate.setText(dateFormatter.format(newEndDate.getTime()));
                end_date = String.valueOf(newEndDate.getTimeInMillis());
            }

        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        dateEndPickerDialog.setButton(DialogInterface.BUTTON_POSITIVE, getResources().getString(R.string.ok), dateEndPickerDialog);
        dateEndPickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE, getResources().getString(R.string.str_cancel), dateEndPickerDialog);
    }

    public void onOrderItemClick(Order_details orderDetails) {
        OrderActivity.launch(getActivity(), false, 0.0, 0.0, orderDetails.getOrder_id(), ORDER_DETAILS, true, orderDetails,AppConstants.NO_VALUE_SET_STRING);
    }
}