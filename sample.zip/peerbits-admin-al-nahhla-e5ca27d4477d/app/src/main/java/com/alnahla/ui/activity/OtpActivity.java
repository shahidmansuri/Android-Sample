package com.alnahla.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;

import com.alnahla.AppConstants;
import com.alnahla.R;
import com.alnahla.databinding.ActivityOtpBinding;
import com.alnahla.network.API_CONSTANTS;
import com.alnahla.network.API_EndPoints;
import com.alnahla.network.NetworkCall;
import com.alnahla.network.listeners.RetrofitResponseListener;
import com.alnahla.ui.BaseActivity;
import com.alnahla.utils.Validations;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class OtpActivity extends BaseActivity implements View.OnClickListener {
    ActivityOtpBinding mBinding;
    CountDownTimer countDownTimer = null;
    String dialCode, phoneNumber;

    public static void launch(Activity activity, boolean isFinishActivity, String dialCode, String phoneNumber) {
        if (isFinishActivity) {
            Intent intent = new Intent(activity, OtpActivity.class);
            intent.putExtra(AppConstants.DIALCODE, dialCode);
            intent.putExtra(AppConstants.PHONENUMBER, phoneNumber);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        } else {
            Intent intent = new Intent(activity, OtpActivity.class);
            intent.putExtra(AppConstants.DIALCODE, dialCode);
            intent.putExtra(AppConstants.PHONENUMBER, phoneNumber);
            activity.startActivity(intent);
            activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_otp);
        setStatusBarColor(this, getResources().getColor(R.color.status_color_gray));
        setUpToolBar();
        setOnClickListner();
        setUpUi();
    }

    private void setUpUi() {
        startTimer();
        dialCode = getIntent().getStringExtra(AppConstants.DIALCODE);
        phoneNumber = getIntent().getStringExtra(AppConstants.PHONENUMBER);
        mBinding.tvOtpPhoneNumber.setText(dialCode + " " + phoneNumber);
    }

    private void setOnClickListner() {
        mBinding.ivEditPhoneNumber.setOnClickListener(this);
        mBinding.btnVerify.setOnClickListener(this);
    }

    private void setUpToolBar() {
        mBinding.included.whiteToolbar.setNavigationIcon(R.drawable.ic_back_arrow_green);
        mBinding.included.whiteToolbar.setNavigationOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivEditPhoneNumber:
                Intent intent = new Intent(this, ForgetPasswordActivity.class);
                intent.putExtra(AppConstants.PHONENUMBER, phoneNumber);
                startActivity(intent);
                break;
            case R.id.btnVerify:
                if (isValid()) {
                    dialCode = getIntent().getStringExtra(AppConstants.DIALCODE);
                    phoneNumber = getIntent().getStringExtra(AppConstants.PHONENUMBER);
                    String otp = mBinding.etotpView.getOTP();
                    getOtpApi(dialCode, phoneNumber, otp);
                }
               /* Intent intent1 = new Intent(this, ResetPasswordActivity.class);
                startActivity(intent1);*/
        }

    }

    private void getOtpApi(final String dialCode, final String phoneNumber, String otp) {
        HashMap<String, String> params = new HashMap<>();
        params.put(API_CONSTANTS.DIAL_CODE, dialCode);
        params.put(API_CONSTANTS.PHONE_NO, phoneNumber);
        params.put(API_CONSTANTS.OTP, otp);

        NetworkCall.with(this)
                .setEndPoint(API_EndPoints.OTP)
                .setRequestParams(params)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                        showProgress(getResources().getString(R.string.txt_pls_wait));
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        stopProgress();
                        if (countDownTimer != null) {
                            countDownTimer.cancel();
                        }
                        showToastShort(jsonObject.optString(API_CONSTANTS.MESSAGE));
                        ResetPasswordActivity.launch(OtpActivity.this, false, dialCode, phoneNumber);
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        stopProgress();
                        errorHandleFromApi(messages,statusCode);

                    }
                }).makeCall();
    }

    private boolean isValid() {
        boolean isValid = false;
        if (Validations.isEditTextEmpty(mBinding.etotpView.getOTP())) {
            showToastShort(getApplicationContext().getResources().getString(R.string.v_otp));
        } else if (mBinding.etotpView.getOTP().length() != 4) {
            showToastShort(getResources().getString(R.string.invalid_otp));
        } else {
            isValid = true;
        }
        return isValid;
    }

    private void startTimer() {
        countDownTimer = new CountDownTimer(60000, 1000) {
            public void onTick(long millisUntilFinished) {
                long millis = millisUntilFinished;
                //Convert milliseconds into hour,minute and seconds
                String hms = String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(
                        TimeUnit.MILLISECONDS.toHours(millis)), TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
                mBinding.tvOtpTimer.setText(hms);
            }

            public void onFinish() {
                // Log.e("Finish();", "TIME'S UP!!");
                finish();
            }
        }.start();
    }
}
