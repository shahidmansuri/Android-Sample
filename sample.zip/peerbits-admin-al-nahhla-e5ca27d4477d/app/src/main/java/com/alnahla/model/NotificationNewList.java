package com.alnahla.model;

public class NotificationNewList {
    private String message;
    private String timestamp;
    // private String type;

    public NotificationNewList(String message, String timestamp) {
        this.message = message;
        this.timestamp = timestamp;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getTimestamp() {
        return timestamp;
    }

   /* public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }*/
}

