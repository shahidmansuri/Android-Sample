package com.alnahla.ui.adapter;

import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.alnahla.R;
import com.alnahla.databinding.RawOrderHistoryBinding;
import com.alnahla.model.order_detais.Order_details;
import com.alnahla.ui.fragments.HistoryFragment;
import com.alnahla.utils.Utils;
import com.alnahla.utils.glideUtils.GlideLoader;

import java.util.List;

import static com.alnahla.AppConstants.ACCEPTED;
import static com.alnahla.AppConstants.ARRIVED_TO_RESTAURANT;
import static com.alnahla.AppConstants.ASSIGNED;
import static com.alnahla.AppConstants.CANCEL_BY_ADMIN;
import static com.alnahla.AppConstants.CANCEL_BY_RESTAURENT;
import static com.alnahla.AppConstants.COMPLETED;
import static com.alnahla.AppConstants.DELIVERED;
import static com.alnahla.AppConstants.ON_THE_WAY;
import static com.alnahla.AppConstants.PICKED_UP;
import static com.alnahla.AppConstants.REJECTED;
import static com.alnahla.AppConstants.REQUESTED;

public class OrderHistoryAdapter extends RecyclerView.Adapter<OrderHistoryAdapter.MyViewHolder> {
    public HistoryFragment context;
    private List<Order_details> orderHistotyList;
    private GlideLoader glideLoader;

    public OrderHistoryAdapter(HistoryFragment context, List<Order_details> orderHistotyList, GlideLoader glideLoader) {
        this.context = context;
        this.orderHistotyList = orderHistotyList;
        this.glideLoader = glideLoader;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        RawOrderHistoryBinding mBinding = DataBindingUtil.inflate(LayoutInflater
                .from(viewGroup.getContext()), R.layout.raw_order_history, viewGroup, false);
        return new MyViewHolder(mBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder viewHolder, int position) {
        final Order_details data = orderHistotyList.get(position);
        viewHolder.mBinding.tvOrderId.setText(String.format("#%d", data.getOrder_id()));
        viewHolder.mBinding.tvOrderDate.setText(Utils.longToDateStringFilter(Long.parseLong(data.getTimestamp())));

        switch (data.getStatus_code()) {
            case REQUESTED:
                viewHolder.mBinding.tvOrderStatus.setText(data.getStatus());
                viewHolder.mBinding.tvOrderStatus.setBackgroundResource(R.drawable.shape_my_status_red);
                break;
            case ACCEPTED:
                viewHolder.mBinding.tvOrderStatus.setText(data.getStatus());
                viewHolder.mBinding.tvOrderStatus.setBackgroundResource(R.drawable.shape_my_status_green);
                break;
            case REJECTED:
                viewHolder.mBinding.tvOrderStatus.setText(data.getStatus());
                viewHolder.mBinding.tvOrderStatus.setBackgroundResource(R.drawable.shape_my_status_green);
                break;
            case ASSIGNED:
                viewHolder.mBinding.tvOrderStatus.setText(data.getStatus());
                viewHolder.mBinding.tvOrderStatus.setBackgroundResource(R.drawable.shape_my_status_green);
                break;
            case ON_THE_WAY:
                viewHolder.mBinding.tvOrderStatus.setText(data.getStatus());
                viewHolder.mBinding.tvOrderStatus.setBackgroundResource(R.drawable.shape_my_status_green);
                break;
            case ARRIVED_TO_RESTAURANT:
                viewHolder.mBinding.tvOrderStatus.setText(data.getStatus());
                viewHolder.mBinding.tvOrderStatus.setBackgroundResource(R.drawable.shape_my_status_green);
                break;
            case PICKED_UP:
                viewHolder.mBinding.tvOrderStatus.setText(data.getStatus());
                viewHolder.mBinding.tvOrderStatus.setBackgroundResource(R.drawable.shape_my_status_green);
                break;
            case DELIVERED:
                viewHolder.mBinding.tvOrderStatus.setText(data.getStatus());
                viewHolder.mBinding.tvOrderStatus.setBackgroundResource(R.drawable.shape_my_status_green);
                break;
            case COMPLETED:
                viewHolder.mBinding.tvOrderStatus.setText(data.getStatus());
                viewHolder.mBinding.tvOrderStatus.setBackgroundResource(R.drawable.shape_my_status_green);
                break;
            case CANCEL_BY_RESTAURENT:
                viewHolder.mBinding.tvOrderStatus.setText(data.getStatus());
                viewHolder.mBinding.tvOrderStatus.setBackgroundResource(R.drawable.shape_my_status_red);
                break;
            case CANCEL_BY_ADMIN:
                viewHolder.mBinding.tvOrderStatus.setText(data.getStatus());
                viewHolder.mBinding.tvOrderStatus.setBackgroundResource(R.drawable.shape_my_status_red);
                break;
        }
        viewHolder.mBinding.tvOrderStatus.setText(data.getStatus());
        viewHolder.mBinding.tvRestaurantname.setText(data.getRestaurant_details().getRestaurant_name());
        viewHolder.mBinding.tvRestaurantAddress.setText(data.getRestaurant_details().getRestaurant_address());
        viewHolder.mBinding.tvUsername.setText(data.getCustomer_details().getCustomer_name());
        viewHolder.mBinding.tvUserAddress.setText(data.getCustomer_details().getCustomer_address());

        glideLoader.loadImageSimple(data.getRestaurant_details().getRestaurant_image(), viewHolder.mBinding.ivRestaurantImage);
        glideLoader.loadImageCircle(data.getCustomer_details().getCustomer_profile_image(), viewHolder.mBinding.ivUserImage);
        viewHolder.mBinding.llOrderItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.onOrderItemClick(data);
            }
        });
    }

    @Override
    public int getItemCount() {
        return orderHistotyList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        RawOrderHistoryBinding mBinding;

        public MyViewHolder(RawOrderHistoryBinding mBinding) {
            super(mBinding.getRoot());
            this.mBinding = mBinding;
        }
    }
}
