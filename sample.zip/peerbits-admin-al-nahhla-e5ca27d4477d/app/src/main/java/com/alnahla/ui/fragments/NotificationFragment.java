package com.alnahla.ui.fragments;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.alnahla.R;
import com.alnahla.databinding.FragmentNotificationBinding;
import com.alnahla.model.NewNotifiactionData;
import com.alnahla.model.Notification_details;
import com.alnahla.network.API_CONSTANTS;
import com.alnahla.network.API_EndPoints;
import com.alnahla.network.NetworkCall;
import com.alnahla.network.listeners.RetrofitResponseListener;
import com.alnahla.ui.BaseFragment;
import com.alnahla.ui.activity.MainActivity;
import com.alnahla.ui.adapter.NotificationListAdapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class NotificationFragment extends BaseFragment {

    private FragmentNotificationBinding mBinder;

    private ArrayList<Notification_details> notificationListArrayList = new ArrayList<Notification_details>();
    NotificationListAdapter notificationListAdapter;

    //for the load more
    private int start = 0;
    private int limit = 10;
    private boolean isLoading;
    private int isLast = 1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (mBinder == null) {
            mBinder = DataBindingUtil.inflate(inflater, R.layout.fragment_notification, container, false);
        }

        setUpUi();
        // setHasOptionsMenu(true);
        return mBinder.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    private void setUpUi() {

//        clearAll();
        apiNotificationList();
    }

    public void clearAll() {
        apiClearNotification();
    }

    private void apiNotificationList() {
        HashMap<String, String> params = new HashMap<>();
        params.put(API_CONSTANTS.START, String.valueOf(start));
        params.put(API_CONSTANTS.LIMIT, String.valueOf(limit));

        NetworkCall.with(mContext)
                .setEndPoint(API_EndPoints.NOTIFICATION_LIST)
                .setRequestParams(params)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                        /*if (start == 0) {
                            showProgress(getResources().getString(R.string.txt_loading));
                        } else {
                            mBinder.pbNewProgress.setVisibility(View.VISIBLE);
                        }
                        isLoading = true;*/
                        showProgress();
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        stopProgress();
                        mBinder.pbNewProgress.setVisibility(View.GONE);
                        isLoading = false;
                        mBinder.tvNodata.setVisibility(View.GONE);
                        GsonBuilder gsonBuilder = new GsonBuilder();
                        Gson gson = gsonBuilder.create();
                        NewNotifiactionData model = gson.fromJson(String.valueOf(jsonObject), NewNotifiactionData.class);
                        if (model.getNotification_details().size() > 0) {
                            isLast = model.getIs_last();
                            start = start + limit;
                            notificationListArrayList.addAll(model.getNotification_details());
                            setUpRecyclerView(notificationListArrayList);

                            ((MainActivity)getActivity()).setVisibilityClearAllBt(View.VISIBLE);

                        } else {
//                            setUpRecyclerView(notificationListArrayList);
                            mBinder.pbNewProgress.setVisibility(View.GONE);
                            mBinder.rvNotificationList.setVisibility(View.GONE);
                            mBinder.tvNodata.setVisibility(View.VISIBLE);

                            ((MainActivity)getActivity()).setVisibilityClearAllBt(View.GONE);
                        }
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        stopProgress();
                        isLoading = false;
                        mBinder.pbNewProgress.setVisibility(View.GONE);
                        mBinder.tvNodata.setVisibility(View.VISIBLE);
                        errorHandleFromApi(mContext, messages,statusCode);
                    }
                }).makeCall();
    }

    /**
     * method to set up recycler view
     */
    private void setUpRecyclerView(ArrayList<Notification_details> List) {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);
        if (notificationListAdapter == null) {
            notificationListAdapter = new NotificationListAdapter(mContext, List);
            mBinder.rvNotificationList.setLayoutManager(linearLayoutManager);
            mBinder.rvNotificationList.setAdapter(notificationListAdapter);

        } else {
            notificationListAdapter.setDataList(notificationListArrayList);
        }

        mBinder.rvNotificationList.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int totalItemCount = recyclerView.getLayoutManager().getItemCount();
                int lastVisibleItem = ((LinearLayoutManager) recyclerView.getLayoutManager()).findLastVisibleItemPosition();
                if (!isLoading && totalItemCount <= (lastVisibleItem + 2)) {
                    if (isLast == 1) {
                        apiNotificationList();
                    }
                }
            }
        });
    }

    private void apiClearNotification() {
        HashMap<String, String> params = new HashMap<>();
//        params.put("start", String.valueOf(start));
//        params.put("limit", String.valueOf(limit));

        NetworkCall.with(mContext)
                .setEndPoint(API_EndPoints.CLEAR_NOTIFICATION_LIST)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                        showProgress();
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        stopProgress();
                        mBinder.tvNodata.setVisibility(View.VISIBLE);
                        notificationListArrayList.clear();
                        notificationListAdapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        stopProgress();
                        mBinder.tvNodata.setVisibility(View.VISIBLE);
                        errorHandleFromApi(mContext, messages,statusCode);
                    }
                }).makeCall();
    }
}
