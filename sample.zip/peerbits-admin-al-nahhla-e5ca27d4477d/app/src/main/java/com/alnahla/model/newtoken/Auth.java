package com.alnahla.model.newtoken;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
/**
 * Awesome Pojo Generator
 * */
public class Auth{
  @SerializedName("type")
  @Expose
  private String type;
  @SerializedName("message")
  @Expose
  private String message;
  @SerializedName("token")
  @Expose
  private String token;
  public void setType(String type){
   this.type=type;
  }
  public String getType(){
   return type;
  }
  public void setMessage(String message){
   this.message=message;
  }
  public String getMessage(){
   return message;
  }
  public void setToken(String token){
   this.token=token;
  }
  public String getToken(){
   return token;
  }
}