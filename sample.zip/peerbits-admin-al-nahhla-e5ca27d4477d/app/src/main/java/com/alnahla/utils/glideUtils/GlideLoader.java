package com.alnahla.utils.glideUtils;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import com.alnahla.R;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;

import java.io.File;

/**
 * Created by Deep Patel
 * (Sr. Android Developer)
 * on 1/23/2018
 */
public class GlideLoader {
    private Context context;

    public GlideLoader(Context context) {
        this.context = context;
    }

    private RequestOptions simpleOptions = new RequestOptions()
            .centerCrop()
            .placeholder(R.color.color_gray)
            .error(R.color.color_gray)
            .diskCacheStrategy(DiskCacheStrategy.RESOURCE);

    private RequestOptions circleOptions = new RequestOptions()
            .centerCrop()
            .circleCrop()
            .placeholder(R.drawable.ic_user_place_holder)
            .error(R.drawable.ic_user_place_holder)
            .diskCacheStrategy(DiskCacheStrategy.RESOURCE);

    private RequestOptions circleUserOptions = new RequestOptions()
            .centerCrop()
            .circleCrop()
            .placeholder(R.drawable.ic_user_place_holder)
            .error(R.drawable.ic_user_place_holder)
            .diskCacheStrategy(DiskCacheStrategy.RESOURCE);

    public void loadImageSimple(String url, ImageView view) {
        Glide.with(context)
                .load(url)
                .apply(simpleOptions)
                .into(view);
    }

    public void loadImageDrawable(Drawable drawable, ImageView view) {
        Glide.with(context)
                .load(drawable)
                .apply(simpleOptions)
                .into(view);
    }


    public void loadImageCircle(String url, ImageView view) {
        Glide.with(context)
                .load(url)
                .apply(circleOptions)
                .into(view);
    }

    public void loadImageForUser(String url, ImageView view) {
        Glide.with(context)
                .load(url)
                .apply(circleUserOptions)
                .into(view);
    }

    public void loadImageFromFile(File file, ImageView view) {
        Glide.with(context)
                .load(file)
                .apply(simpleOptions)
                .into(view);
    }

    public void loadCircleImageFromFile(File file, ImageView view) {
        Glide.with(context)
                .load(file)
                .apply(circleOptions)
                .into(view);
    }

    public void loadCircleUserImageFromFile(File file, ImageView view) {
        Glide.with(context)
                .load(file)
                .apply(circleUserOptions)
                .into(view);
    }
}
