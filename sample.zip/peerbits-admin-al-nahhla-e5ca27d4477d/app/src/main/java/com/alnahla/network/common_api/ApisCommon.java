package com.alnahla.network.common_api;

import android.content.Context;

import com.alnahla.AppConstants;
import com.alnahla.interfaces.InterfaceAPI;
import com.alnahla.network.API_CONSTANTS;
import com.alnahla.network.API_EndPoints;
import com.alnahla.network.NetworkCall;
import com.alnahla.network.listeners.RetrofitResponseListener;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class ApisCommon {

//    public void apiOrderStatusUpdate(Context context, String strOrderID, double dbDriverLat, double dbDriverLng, int reasonID,String othersComment,int orderStatus, InterfaceAPI orderStatusUpdation) {
//        final InterfaceAPI updation = orderStatusUpdation;
//        HashMap params = new HashMap<>();
//        params.put(API_CONSTANTS.ORDER_ID, strOrderID);
//        params.put(API_CONSTANTS.ORDER_STATUS, String.valueOf(orderStatus));
//        if(dbDriverLat!=0.0 && dbDriverLng!=0.0){
//            params.put(API_CONSTANTS.DRIVER_LATITUDE, String.valueOf(dbDriverLat));
//            params.put(API_CONSTANTS.DRIVER_LONGITUDE, String.valueOf(dbDriverLng));
//        }
//        if(reasonID != AppConstants.NO_VALUE_SET){
//            params.put(API_CONSTANTS.REASON_ID, String.valueOf(reasonID));
//        }
//        if(!othersComment.equals(AppConstants.NO_VALUE_SET_STRING)){
//            params.put(API_CONSTANTS.OTHERS_COMMENT,othersComment);
//        }
//        NetworkCall.with(context)
//                .setEndPoint(API_EndPoints.UPDATE_ORDER_STATUS)
//                .setRequestParams(params)
//                .setResponseListener(new RetrofitResponseListener() {
//                    @Override
//                    public void onPreExecute() {
//                    }
//
//                    @Override
//                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
//
//                        GsonBuilder gsonBuilder = new GsonBuilder();
//                        Gson gson = gsonBuilder.create();
//
//                        updation.apiSuccessful(statusCode, jsonObject, response);
//                    }
//
//                    @Override
//                    public void onError(int statusCode, ArrayList<String> messages) {
//                        updation.apiFailed(messages);
//                    }
//
//                }).makeCall();
//    }

    public void apiCancelAcceptOrder(Context context, String strOrderID, int reasonID, String othersComment, int is_accepted, String eta, InterfaceAPI orderStatusUpdation) {
        final InterfaceAPI updation = orderStatusUpdation;
        HashMap params = new HashMap<>();
        params.put(API_CONSTANTS.ORDER_ID, strOrderID);
        if (reasonID != AppConstants.NO_VALUE_SET) {
            params.put(API_CONSTANTS.REASON_ID, String.valueOf(reasonID));
        }
        if (!othersComment.equals(AppConstants.NO_VALUE_SET_STRING)) {
            params.put(API_CONSTANTS.OTHERS_COMMENT, othersComment);
        }
        if (!eta.equalsIgnoreCase(AppConstants.NO_VALUE_SET_STRING)) {
            params.put(API_CONSTANTS.ETA, eta);
        }
        params.put(API_CONSTANTS.IS_ACCEPTED, String.valueOf(is_accepted));
        NetworkCall.with(context)
                .setEndPoint(API_EndPoints.ACCEPT_CANCEL)
                .setRequestParams(params)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {

                        GsonBuilder gsonBuilder = new GsonBuilder();
                        Gson gson = gsonBuilder.create();

                        updation.apiSuccessful(statusCode, jsonObject, response);
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        updation.apiFailed(statusCode,messages);
                    }

                }).makeCall();
    }

    public void apiOrderHistoryList(Context context, int start, int limit, int paymentType, int orderStatus, String fromDate, String toDate, InterfaceAPI orderHistoryList) {
        final InterfaceAPI orderHistory = orderHistoryList;
        HashMap<String, String> params = new HashMap<>();
        params.put(API_CONSTANTS.START, String.valueOf(start));
        params.put(API_CONSTANTS.LIMIT, String.valueOf(limit));

        //  Log.e("API_CONSTANTS.START", "" + start);
        //Log.e("API_CONSTANTS.LIMIT", "" + limit);
        if (!fromDate.equalsIgnoreCase(AppConstants.NO_VALUE_SET_STRING)) {
//            params.put(API_CONSTANTS.FROM_DATE, String.valueOf(Utils.dateToTimeStamp(fromDate)));
//            params.put(API_CONSTANTS.TO_DATE, String.valueOf(Utils.dateToTimeStamp(toDate)));

            params.put(API_CONSTANTS.FROM_DATE, fromDate);
            params.put(API_CONSTANTS.TO_DATE, toDate);

            //  Log.e("API_CONSTANTS.FROM_DATE", "" + fromDate);
            //Log.e("API_CONSTANTS.TO_DATE", "" + toDate);
        }
        if (orderStatus != AppConstants.NO_VALUE_SET) {
            params.put(API_CONSTANTS.ORDER_STATUS, String.valueOf(orderStatus));
            //Log.e("API_CONSTANTS.O_STATUS", "" + orderStatus);
        }
        if (paymentType != AppConstants.NO_VALUE_SET) {
            params.put(API_CONSTANTS.PAYMENT_TYPE, String.valueOf(paymentType));
            //Log.e("API_CONSTANTS.PAY_TYPE", "" + paymentType);
        }

        NetworkCall.with(context)
                .setEndPoint(API_EndPoints.MY_ORDER_LIST)
                .setRequestParams(params)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                        //showProgress(getResources().getString(R.string.txt_loading));
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {
                        orderHistory.apiSuccessful(statusCode, jsonObject, response);
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        orderHistory.apiFailed(statusCode,messages);

                    }
                }).makeCall();
    }

    public void apiEarning(Context context, int paymentType, int orderStatus, String fromDate, String toDate, InterfaceAPI orderStatusUpdation) {
        final InterfaceAPI earning = orderStatusUpdation;

        HashMap<String, String> params = new HashMap<>();
        if (!fromDate.equalsIgnoreCase(AppConstants.NO_VALUE_SET_STRING)) {
            params.put(API_CONSTANTS.FROM_DATE, fromDate);
            params.put(API_CONSTANTS.TO_DATE, toDate);
        }
        if (orderStatus != AppConstants.NO_VALUE_SET) {
            params.put(API_CONSTANTS.ORDER_STATUS, String.valueOf(orderStatus));
        }
        if (paymentType != AppConstants.NO_VALUE_SET) {
            params.put(API_CONSTANTS.PAYMENT_TYPE, String.valueOf(paymentType));
        }

        NetworkCall.with(context)
                .setEndPoint(API_EndPoints.EARNING_LIST)
                .setRequestParams(params)
                .setResponseListener(new RetrofitResponseListener() {
                    @Override
                    public void onPreExecute() {
                        earning.onPreExecute();
                    }

                    @Override
                    public void onSuccess(int statusCode, JSONObject jsonObject, String response) {

                        earning.apiSuccessful(statusCode, jsonObject, response);
                    }

                    @Override
                    public void onError(int statusCode, ArrayList<String> messages) {
                        earning.apiFailed(statusCode,messages);
                    }

                }).makeCall();
    }
}
