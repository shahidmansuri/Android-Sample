package com.alnahla;

/**
 * Created by Mushahid on 1/8/2018.
 * This class includes the Key and Base Urls to be used in the App for Network call
 */

public class AppConstants {

    public static final String BUCKET_NAME = "pbalnahhala";
    public static final String COGNITO_POOL_ID = "ap-south-1:3c420fd5-8cea-47a4-bc66-e06bb249116d";
    public static final String API_DIRECTIONS = "https://maps.googleapis.com/maps/api/directions/";
    public static final float GEOFENCE_RADIUS_IN_METERS = 100;


    public static String BASE_URL = "";
    public static final String MAIN_STACK = "main_stack";
    public static final String ORDER_ID = "order_id";
    public static final String ORDER_STATUS = "order_status";
    public static final String NOTIFICATION_DATA = "NotificationData";

    public static final String STARTDATE = "start_date";
    public static final String PHONENUMBER = "phone_no";
    public static final String PASSWORD = "password";
    public static final String DIALCODE = "dial_code";
    public static final String ENDDATE = "end_date";
    public static final String ORDERFILTERSTATUS = "order_filter_status";
    public static final String PAYMENTMODE = "payment_mode";
    public static final String FROM = "from";

    public static final Integer ORDER_RUNNING = 1;
    public static final Integer NO_ORDERS = 0;

    public static final Integer DEFAULT_DECIMAL_POINTS = 1;

    public static final String DIALCODE_VALUE = "+974";

    //Earning Filter
    public static final Integer TYPE_FILTERED = 0;
    public static final Integer TYPE_TODAY = 1;
    public static final Integer TYPE_TOTAL = 2;


    /*
        Order Status Constants
     */
    public static final int REQUESTED = 1;
    public static final int ACCEPTED= 2;
    public static final int REJECTED = 3;
    public static final int ASSIGNED = 4;
    public static final int ON_THE_WAY = 5;
    public static final int ARRIVED_TO_RESTAURANT = 6;
    public static final int PICKED_UP = 7;
    public static final int DELIVERED = 8;
    public static final int COMPLETED = 9;
    public static final int CANCEL_BY_RESTAURENT = 10;
    public static final int CANCEL_BY_ADMIN = 11;

    public static final int TYPE_CASH = 1;
    public static final int TYPE_CARD = 2;
    public static final int CASH = 1;
    public static final int CARD = 2;


    /*
        Order History
     */
    public static final String PAYMENT_TYPE = "payment_type";
    public static final String FROM_DATE = "from";
    public static final String TO_DATE = "from";

    /*
        HomeFragment

     */
    public static final int DRIVER_ONLINE = 1;
    public static final int DRIVER_OFFLINE = 0;

    /*
        Order Details

     */

    public static final int EXTRA_MIN = 3;
    public static final int DEFAULT_TIME = 00;
    public static final String DEFAULT_DISTANCE = "00";
    public static final int DEFAULT_DIS_METERS = 50;

    /*
        Whenever, we do not want to pass any int to api, can set it to -1, and put condition in api calling
     */
    public static final int NO_VALUE_SET = -1;
    public static final String NO_VALUE_SET_STRING = "";

    public static final String GEOFENCING_UPDATED="com.alnahla.geofencing";

    public static final int IS_LATE = 1;
    public static final int IS_NOT_LATE = 0;

    public static final String DATE_FORMAT = "dd/MM/yyyy";


    public static final int MOBILE_REQ_LENGTH = 8;

    public static final String MAP_NAVIGATION = "http://maps.google.com/maps?daddr=";
    public static final String LINK_WAZE = "https://www.waze.com/ul?ll=";
    public static final String LINK_WAZE_GPLAY ="market://details?id=com.waze" ;

    public static final int UNAUTHORIZED = 401;

    public static final String DEVICE_TYPE = "A";

    public static final int MIN_PASS_LENGTH = 6;
    public static final int MAX_PASS_LENGTH = 15;
}
