package com.alnahla.interfaces;

import org.json.JSONObject;

import java.util.ArrayList;

public interface InterfaceAPI {
    public void onPreExecute();
    void apiSuccessful(int statusCode, JSONObject jsonObject, String response);
    void apiFailed(int statisCode,ArrayList<String> messages);
}
