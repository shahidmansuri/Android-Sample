package com.alnahla.listener;

import android.content.Context;

/**
 * Created by AnkitKumar on 06-09-2018.
 */

public interface ContextProvider {
    Context getActivityContext();
}
