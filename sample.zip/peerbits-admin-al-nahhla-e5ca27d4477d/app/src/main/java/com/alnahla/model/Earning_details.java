package com.alnahla.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Awesome Pojo Generator
 */
public class Earning_details {
    @SerializedName("earnings")
    @Expose
    private Integer earnings;
    @SerializedName("journey_time")
    @Expose
    private String journey_time;
    @SerializedName("orders")
    @Expose
    private Integer orders;
    @SerializedName("type")
    @Expose
    private Integer type;


    public void setEarnings(Integer earnings) {
        this.earnings = earnings;
    }

    public Integer getEarnings() {
        return earnings;
    }

    public void setJourney_time(String journey_time) {
        this.journey_time = journey_time;
    }

    public String getJourney_time() {
        return journey_time;
    }

    public void setOrders(Integer orders) {
        this.orders = orders;
    }

    public Integer getOrders() {
        return orders;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getType() {
        return type;
    }
}